賣貨便 k6 正式機壓測 — 部署包（2026-10-08）
============================================

內容
----
  MANUAL.docx / MANUAL.md   同仁操作手冊（兩份內容相同；要複製指令時用 .md）
  k6/                       壓測程式（直接在這個資料夾裡執行）
    kp.sh                   載入指令：source kp.sh，之後用 ka 一次跑完 7 支
    settings.json           正式環境設定（API 10.135.50.243）
    config.js helpers.js load.js smoke.js README.md
    data/                   會員、關鍵字、s1 建單模板（s1_template.json）
    scenarios/              7 支單獨腳本
    SHA256SUMS              檢查檔案有沒有傳壞：sha256sum -c SHA256SUMS

快速流程（細節看 MANUAL）
------------------------
  1. 把 maihuobian-k6-deploy-20261008.tar.gz 傳到壓測機（傳檔案，不要貼上）
  2. tar xzf maihuobian-k6-deploy-20261008.tar.gz
  3. cd ~/maihuobian-k6-deploy-20261008/k6
  4. sha256sum -c SHA256SUMS        每一行都要 OK
  5. cat settings.json              網址 10.135.50.243、es 必須是空的
  6. source kp.sh
  7. 試跑：export S5SEED=20 → ka 10 2026-10-08 1 1m → 結果給負責人 → unset S5SEED
  8. 正式：ka full 2026-10-08 1

注意
----
  - s1、s5 會寫入正式資料（客戶已同意）
  - 會解出新的資料夾，不會動到壓測機上原本的 k6 資料夾
