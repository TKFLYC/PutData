// ============================================================
//  賣貨便 k6 壓測 — 共用函式
//  責任:資料母體、唯一單號、payload builder、HTTP 包裝、寫入落地 verify。
// ============================================================
import http from 'k6/http';
import { sleep } from 'k6';
import { SharedArray } from 'k6/data';
import { Counter, Rate, Trend } from 'k6/metrics';
import exec from 'k6/execution';
import {
  APP_SALES_DATE_RANGE_TYPE,
  CREATE_ORDER_DEFAULTS,
  ES_INDEX,
  ES_URL,
  FRESHNESS_SLA_MS,
  INSTANCE_ID,
  MEMBER_DEFAULT,
  ORDER_CHILD_NO_PREFIX,
  ORDER_NO_PREFIX,
  ORDER_RUN_ID,
  QUERY_DATE,
  QUERY_DAYS,
  REQUEST_TIMEOUT,
  S1_ORDER_DATE_MODE,
  S5_USE_ORDERS_JSON,
  SCENARIOS,
  SELLER_SEARCH_PAGE_SIZE,
  VERIFY_MODE,
  VERIFY_POLL_INTERVAL_MS,
  VERIFY_SAMPLE_RATE,
  VERIFY_TIMEOUT_BUFFER_MS,
  effectiveVerifyMode,
  isDockerMode,
  scenarioFullUrl,
  scenarioPath,
  scenarioUrl,
} from './config.js';

function loadJsonArray(path, fallback) {
  const value = JSON.parse(open(path));
  if (!Array.isArray(value)) return fallback;
  return value;
}

function valueOf(row, keys, fallback) {
  if (row === null || row === undefined) return fallback;
  if (typeof row !== 'object') return fallback;
  for (const key of keys) {
    if (row[key] !== undefined && row[key] !== null && row[key] !== '') return row[key];
  }
  return fallback;
}

function normalizeMember(row) {
  if (typeof row === 'number') return { cuamCid: row };
  if (typeof row === 'string' && row.trim() !== '') return { cuamCid: Number(row) };
  const cuamCid = Number(valueOf(row, ['cuamCid', 'CuamCid', 'CUAMCID', 'memberId', 'id'], MEMBER_DEFAULT));
  return {
    cuamCid: Number.isFinite(cuamCid) ? cuamCid : MEMBER_DEFAULT,
    label: valueOf(row, ['label', 'name', 'note'], ''),
  };
}

function normalizeKeyword(row) {
  if (typeof row === 'string') return row;
  return String(valueOf(row, ['keyword', 'CoodName', 'coodName', 'name'], '測試'));
}

function normalizeDateRange(row) {
  return {
    label: valueOf(row, ['label', 'name'], ''),
    start: valueOf(row, ['start', 'searchStartDate', 'OrderDateStart'], null),
    end: valueOf(row, ['end', 'searchEndDate', 'OrderDateEnd'], null),
    startDaysAgo: Number(valueOf(row, ['startDaysAgo'], 90)),
    endDaysAgo: Number(valueOf(row, ['endDaysAgo'], 0)),
  };
}

function normalizeMemoOrder(row) {
  if (typeof row === 'string' && row.trim() !== '') {
    return { coomNo: row.trim(), cuamCid: MEMBER_DEFAULT };
  }
  const coomNo = String(valueOf(row, ['coomNo', 'CoomNo', 'COOMNO'], '')).trim();
  if (!coomNo) return null;
  const cuamCid = Number(valueOf(row, ['cuamCid', 'CuamCid', 'CUAMCID', 'memberId'], MEMBER_DEFAULT));
  return {
    coomNo,
    cuamCid: Number.isFinite(cuamCid) ? cuamCid : MEMBER_DEFAULT,
    label: valueOf(row, ['label', 'name', 'note'], ''),
  };
}

export const members = new SharedArray('members', () => {
  const rows = loadJsonArray('./data/members.json', [MEMBER_DEFAULT]);
  return rows
    .filter((row) => !(typeof row === 'object' && row !== null && row.enabled === false))
    .map(normalizeMember);
});

export const keywords = new SharedArray('keywords', () => {
  const rows = loadJsonArray('./data/keywords.json', ['測試']);
  return rows
    .filter((row) => !(typeof row === 'object' && row !== null && row.enabled === false))
    .map(normalizeKeyword)
    .filter(Boolean);
});

export const dateRanges = new SharedArray('dateRanges', () => {
  const rows = loadJsonArray('./data/dateRanges.json', [{ startDaysAgo: 90, endDaysAgo: 0 }]);
  return rows
    .filter((row) => !(typeof row === 'object' && row !== null && row.enabled === false))
    .map(normalizeDateRange);
});

export const memoOrders = new SharedArray('memoOrders', () => {
  const rows = loadJsonArray('./data/orders.json', []);
  return rows
    .filter((row) => !(typeof row === 'object' && row !== null && row.enabled === false))
    .map(normalizeMemoOrder)
    .filter(Boolean);
});

export function pick(rows) {
  return rows[Math.floor(Math.random() * rows.length)];
}

export function pickMember() {
  return members.length > 0 ? pick(members) : { cuamCid: MEMBER_DEFAULT };
}

export function pickKeyword() {
  return keywords.length > 0 ? pick(keywords) : '測試';
}

function isoDaysFromNow(daysFromNow) {
  const date = new Date();
  date.setDate(date.getDate() + daysFromNow);
  return date.toISOString();
}

// ------------------------------------------------------------
// 查詢區間（s2／s4／s6／s7 共用；s3 沒有日期欄位）
//   QUERYDATE（基準日）：
//     2026-10-07              → 台灣 10/07 23:59:59.999（含整天）
//     2026-10-07 12:00        → 台灣時間 12:00（沒寫時區＝台灣時間）
//     2026-10-07T04:00:00Z    → 照寫的時區
//   QUERYDAYS（往前幾天）：預設取 data/dateRanges.json（90）
//   區間＝基準時間往前 QUERYDAYS×24 小時 ～ 基準時間
//   兩個都沒設 → 維持原本：現在往前 N 天 ～ 現在
//   格式看不懂 → 啟動時直接報錯
// ------------------------------------------------------------
const DAY_MS = 24 * 3600 * 1000;

function parseQueryBase(raw) {
  const text = String(raw).trim();
  let m = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], 23, 59, 59, 999) - 8 * 3600 * 1000;
  m = text.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)) - 8 * 3600 * 1000;
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})$/.test(text)) {
    const parsed = Date.parse(text);
    if (Number.isFinite(parsed)) return parsed;
  }
  throw new Error(`QUERYDATE 格式看不懂:${text}(請用 2026-10-07、2026-10-07 12:00 或 2026-10-07T12:00:00+08:00)`);
}

const QUERY_END_MS = QUERY_DATE ? parseQueryBase(QUERY_DATE) : null;

export function pickRange() {
  const row = dateRanges.length > 0 ? pick(dateRanges) : normalizeDateRange({ startDaysAgo: 90, endDaysAgo: 0 });
  if (QUERY_END_MS === null && !QUERY_DAYS && row.start && row.end) {
    return { label: row.label, start: row.start, end: row.end };
  }
  const days = QUERY_DAYS || (row.startDaysAgo - row.endDaysAgo) || 90;
  const endMs = QUERY_END_MS !== null ? QUERY_END_MS : Date.now() - row.endDaysAgo * DAY_MS;
  return {
    label: row.label,
    start: new Date(endMs - days * DAY_MS).toISOString(),
    end: new Date(endMs).toISOString(),
  };
}

export function describeQueryRange() {
  const range = pickRange();
  const tw = (iso) => new Date(Date.parse(iso) + 8 * 3600 * 1000).toISOString().slice(0, 19).replace('T', ' ');
  const source = QUERY_DATE || QUERY_DAYS ? `QUERYDATE=${QUERY_DATE || '(現在)'} QUERYDAYS=${QUERY_DAYS || '(dateRanges.json)'}` : 'data/dateRanges.json';
  return `${range.start} ～ ${range.end}(台灣 ${tw(range.start)} ～ ${tw(range.end)};依 ${source})`;
}

export function verifyRangeCoveringNow() {
  return {
    label: 'verify固定窗_前2天到後1天',
    start: isoDaysFromNow(-2),
    end: isoDaysFromNow(1),
  };
}

export function hasMemoOrderData() {
  return memoOrders.length > 0;
}

export function pickMemoOrder(runtimeSeedOrders) {
  const runtimeRows = Array.isArray(runtimeSeedOrders) ? runtimeSeedOrders : [];
  const pool = S5_USE_ORDERS_JSON && memoOrders.length > 0 ? memoOrders : runtimeRows;
  if (pool.length === 0) return null;
  return pick(pool);
}

// ------------------------------------------------------------
// 單號產生器
// ------------------------------------------------------------
let fallbackCounter = 0;

function pad(value, width) {
  return String(value).padStart(width, '0');
}

// 台灣時間（UTC+8）：用 getUTC* 讀出來就是台灣的年月日，不受壓測機時區影響
function taiwanNow() {
  return new Date(Date.now() + 8 * 3600 * 1000);
}

function compactDate() {
  const t = taiwanNow();
  return `${String(t.getUTCFullYear()).slice(2)}${pad(t.getUTCMonth() + 1, 2)}${pad(t.getUTCDate(), 2)}`;
}

function sourceSalt(source) {
  if (SCENARIOS[source] && Number.isFinite(SCENARIOS[source].sourceSalt)) return SCENARIOS[source].sourceSalt;
  if (source === 'setup') return 2;
  if (source === 'smoke') return 3;
  return 4;
}

function iterationSequence() {
  try {
    if (exec && exec.scenario && Number.isFinite(exec.scenario.iterationInInstance)) {
      return exec.scenario.iterationInInstance;
    }
  } catch (error) {
    // setup 階段沒有 scenario iteration,改用本地流水。
  }
  fallbackCounter += 1;
  return fallbackCounter;
}

// 單號 7 位流水：同一輪保證不重複，外觀打散成亂數
//   x    = (機器編號 × 5 + 來源) × 100,000 + 序號(0～99,999)：每台機器、每個來源各占一段，不會重疊
//   base = (x + 本輪隨機起點 runSalt) mod 10^7
//   流水 = (a × base + b) mod 10^7；a 與 10^7 互質 → 一對一，不同 base 一定得到不同流水
//   coom 與 cooc 用不同的 a、b，兩個單號的數字也不同
//   限制：同一台、同一來源一輪超過 100,000 筆才會重複（每分鐘 1,500 筆約 66 分鐘）
const SERIAL_SPACE = 10000000;

function scramble(base, a, b) {
  return (a * base + b) % SERIAL_SPACE;
}

export function newRunSalt() {
  return Math.floor(Math.random() * SERIAL_SPACE);
}

function serialBase(source, runSalt) {
  const sequence = iterationSequence() % 100000;
  const x = (INSTANCE_ID * 5 + sourceSalt(source)) * 100000 + sequence;
  return (x + (Number(runSalt) || 0)) % SERIAL_SPACE;
}

export function nextOrderIds(source = 's1', runSalt = 0) {
  const datePart = compactDate();
  const base = serialBase(source, runSalt);
  const serial = pad(scramble(base, 7654321, 1234567), 7);
  const childSerial = pad(scramble(base, 3141593, 7777777), 7);
  return {
    coomNo: `${ORDER_NO_PREFIX}${datePart}${serial}`,
    coocNo: `${ORDER_CHILD_NO_PREFIX}${datePart}${childSerial}`,
    serial,
  };
}

export function buildMemoText(coomNo) {
  return `k6 memo ${coomNo} i${INSTANCE_ID} r${ORDER_RUN_ID} ${Date.now()}`;
}

// ------------------------------------------------------------
// HTTP 包裝與成功判斷（支援客戶 + Docker 雙格式）
// ------------------------------------------------------------
export const apiOkRate = new Rate('api_ok_rate');

export function postJson(fullUrl, body, tags) {
  const requestTags = Object.assign({ endpoint: fullUrl, operation: 'utility' }, tags || {});
  return http.post(fullUrl, JSON.stringify(body), {
    headers: { 'Content-Type': 'application/json' },
    timeout: REQUEST_TIMEOUT,
    tags: requestTags,
  });
}

function safeJson(res) {
  try {
    return res.json();
  } catch (error) {
    return null;
  }
}

function responseCode(res) {
  const body = safeJson(res);
  if (!body) return undefined;

  // 客戶格式: {code: "00"}
  if (body.code !== undefined) return body.code;

  // Docker 格式: {response: {Code: 0}} 或 {response: {code: 0}}
  if (body.response) {
    if (body.response.Code !== undefined) return body.response.Code;
    if (body.response.code !== undefined) return body.response.code;
  }

  // Docker 格式(無 wrapper): {Code: 0}
  if (body.Code !== undefined) return body.Code;

  return undefined;
}

export function isOk(res) {
  return res && res.status === 200;
}

export function extractDockerCoomNo(res) {
  const body = safeJson(res);
  if (!body) return null;
  return body.coomNo || null;
}

export function sendScenarioRequest(scenarioKey, body, operation = 'primary') {
  const scenario = SCENARIOS[scenarioKey];
  const fullUrl = scenarioFullUrl(scenarioKey);
  const tags = {
    scenario_id: scenarioKey,
    scenario_name: scenario.name,
    scenario_type: scenario.type,
    endpoint: scenarioPath(scenarioKey),
    operation,
  };
  const res = postJson(fullUrl, body, tags);
  apiOkRate.add(isOk(res), tags);
  return res;
}

export function recordSyntheticApiFailure(scenarioKey, operation = 'primary') {
  const scenario = SCENARIOS[scenarioKey];
  apiOkRate.add(false, {
    scenario_id: scenarioKey,
    scenario_name: scenario.name,
    scenario_type: scenario.type,
    operation,
  });
}

// ------------------------------------------------------------
// payload builder
// ------------------------------------------------------------
function memberId(memberOrId) {
  if (typeof memberOrId === 'object' && memberOrId !== null) return memberOrId.cuamCid;
  return Number(memberOrId || MEMBER_DEFAULT);
}

export function buildCreateOrder(memberOrId, ids) {
  const cuamCid = memberId(memberOrId);
  const now = new Date().toISOString();

  return {
    Sender: {
      System: CREATE_ORDER_DEFAULTS.senderSystem,
      Module: CREATE_ORDER_DEFAULTS.createModule,
      UserId: String(cuamCid),
    },
    List: [
      {
        coom: {
          CoomNo: ids.coomNo,
          CoomOrderDate: now,
          CoomName: CREATE_ORDER_DEFAULTS.orderName,
          CoomStatus: CREATE_ORDER_DEFAULTS.orderStatus,
          CoomTempType: CREATE_ORDER_DEFAULTS.tempType,
          CoomCreateDatetime: now,
          CoomCuamCid: cuamCid,
          CoomSellerGoodsTotalAmt: CREATE_ORDER_DEFAULTS.sellerGoodsTotalAmt,
          CoomGoodsItemNum: 1,
          CoomGoodsTotalNum: 1,
          CoomRcvTotalAmt: CREATE_ORDER_DEFAULTS.receiveTotalAmt,
          CoomCgdmId: CREATE_ORDER_DEFAULTS.cgdmId,
          CoomMergeListCoomNo: null,
        },
        cooc: {
          CoocNo: ids.coocNo,
          CoocPaymentType: CREATE_ORDER_DEFAULTS.paymentType,
          CoocDeliverMethod: CREATE_ORDER_DEFAULTS.deliverMethod,
          CoocOrdChannelKind: CREATE_ORDER_DEFAULTS.orderChannelKind,
          CoocMemSid: cuamCid,
          CoocCreateDatetime: now,
          CoocOrdNameEnc: '9mGOVIAvjlA=',
          CoocRcvNameEnc: '1P9BqbGAeqs=',
          CoocRcvMobileEnc: 'RqoEfNAfHAsC67TumJ+FQQ==',
          CoocPaymentDueday: null,
          CoocPaymentPayDatetime: null,
        },
        cood: [
          {
            CgddId: CREATE_ORDER_DEFAULTS.cgddId,
            CoodCgdsId: CREATE_ORDER_DEFAULTS.cgdsId,
            CoodName: CREATE_ORDER_DEFAULTS.productName,
            CoodQty: 1,
            CoodOriginalPrice: CREATE_ORDER_DEFAULTS.itemPrice,
            CoodDiscountPrice: CREATE_ORDER_DEFAULTS.itemPrice,
            CoodReceivePrice: CREATE_ORDER_DEFAULTS.itemPrice,
            CoodImagePath: CREATE_ORDER_DEFAULTS.productImagePath,
          },
        ],
        cgdi: {
          CgdiNumberColumn1: CREATE_ORDER_DEFAULTS.freightAmount,
        },
      },
    ],
  };
}

// ------------------------------------------------------------
// s1 客戶模板（data/s1_template.json）
//   模板裡 ${CoomNo}、${CoocNo}、${CreateDatetime} 每筆換值，其他欄位照模板原樣送出
//   名稱以 OrderDate 結尾的欄位（CoomOrderDate）改成今天：
//     預設 = 台灣今天 00:00，以 UTC 表示（與模板範例 2026-04-15T16:00:00Z 同格式）
//     S1_ORDER_DATE_MODE=now 時改成現在時間
//   模板出現其他 ${...} 參數 → 啟動時直接報錯，避免把 ${...} 原字送出去
// ------------------------------------------------------------
const S1_TEMPLATE_KEYS = ['CoomNo', 'CoocNo', 'CreateDatetime'];
const S1_TEMPLATE_RAW = (() => {
  try {
    return open('./data/s1_template.json');
  } catch (error) {
    return '';
  }
})();

if (S1_TEMPLATE_RAW) {
  const found = (S1_TEMPLATE_RAW.match(/\$\{[^}]*\}/g) || []).map((s) => s.slice(2, -1));
  const unknown = [...new Set(found.filter((key) => !S1_TEMPLATE_KEYS.includes(key)))];
  if (unknown.length > 0) {
    throw new Error(`data/s1_template.json 有不認得的參數:${unknown.join(', ')}。可用:${S1_TEMPLATE_KEYS.join(', ')}`);
  }
  JSON.parse(S1_TEMPLATE_RAW);
}

export function hasS1Template() {
  return S1_TEMPLATE_RAW !== '';
}

function isoNoMillis(date) {
  return date.toISOString().replace(/\.\d{3}Z$/, 'Z');
}

export function taiwanTodayMidnightIso() {
  const t = taiwanNow();
  const midnightUtc = Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate()) - 8 * 3600 * 1000;
  return isoNoMillis(new Date(midnightUtc));
}

function setOrderDates(node, value) {
  if (Array.isArray(node)) {
    node.forEach((item) => setOrderDates(item, value));
    return;
  }
  if (node && typeof node === 'object') {
    Object.keys(node).forEach((key) => {
      if (/OrderDate$/i.test(key) && typeof node[key] === 'string') node[key] = value;
      else setOrderDates(node[key], value);
    });
  }
}

export function buildCreateOrderFromTemplate(ids) {
  const values = { CoomNo: ids.coomNo, CoocNo: ids.coocNo, CreateDatetime: isoNoMillis(new Date()) };
  const body = JSON.parse(S1_TEMPLATE_RAW.replace(/\$\{(CoomNo|CoocNo|CreateDatetime)\}/g, (_, key) => values[key]));
  setOrderDates(body, S1_ORDER_DATE_MODE === 'now' ? values.CreateDatetime : taiwanTodayMidnightIso());
  return body;
}

export function templateMemberId(body) {
  try {
    return Number(body.List[0].coom.CoomCuamCid);
  } catch (error) {
    return MEMBER_DEFAULT;
  }
}

export function buildUpdateMemo(memberOrId, coomNo, memo) {
  const cuamCid = memberId(memberOrId);

  if (isDockerMode()) {
    return { CoomNo: coomNo };
  }

  return {
    Sender: {
      System: CREATE_ORDER_DEFAULTS.senderSystem,
      Module: CREATE_ORDER_DEFAULTS.memoModule,
      UserId: String(cuamCid),
    },
    Data: {
      CoomNo: coomNo,
      CoomSellerMemo: memo,
    },
  };
}

export function buildHomeOverview(memberOrId, range) {
  return {
    cuamCid: memberId(memberOrId),
    searchStartDate: range.start,
    searchEndDate: range.end,
  };
}

export function buildAppDashboard(memberOrId) {
  return { cuamCid: memberId(memberOrId) };
}

export function buildSellerSearch(memberOrId, options) {
  const opts = options || {};
  const range = opts.range || pickRange();

  return {
    PageIndex: opts.pageIndex === undefined ? 0 : opts.pageIndex,
    PageSize: opts.pageSize || SELLER_SEARCH_PAGE_SIZE,
    CuamCid: memberId(memberOrId),
    OrderDateStart: range.start,
    OrderDateEnd: range.end,
    DeliverMethodSearchKind: opts.deliverMethodSearchKind || null,
    OrdChannelKindSearchKind: opts.ordChannelKindSearchKind || null,
    TempTypeSearchKind: opts.tempTypeSearchKind || null,
    CoomNo: opts.coomNo || null,
    CoomName: opts.coomName || null,
    EsmmShipNo: opts.esmmShipNo || null,
    CoodName: opts.coodName === undefined ? null : opts.coodName,
    CoocNo: opts.coocNo || null,
    OrderState: opts.orderState || null,
    OrderSorts: opts.orderSorts || [1, 3],
    IsQaList: opts.isQaList || false,
  };
}

export function buildAppSales(memberOrId, range) {
  return {
    cuamCid: memberId(memberOrId),
    searchStartDate: range.start,
    searchEndDate: range.end,
    startDatePoP: range.start,
    endDatePoP: range.end,
    dateRangeType: APP_SALES_DATE_RANGE_TYPE,
  };
}

// ------------------------------------------------------------
// 寫入落地 verify（支援 ES 直查 + 查詢 API 兩種模式）
// ------------------------------------------------------------
export const writeFreshness = new Trend('write_freshness_ms', true);
export const writeVerifySuccessRate = new Rate('write_verify_success_rate');
export const writeVerifyAttempts = new Counter('write_verify_attempts');
export const writeVerifyMisses = new Counter('write_verify_misses');

export function shouldVerifyWrite(scenarioKey) {
  const mode = effectiveVerifyMode(scenarioKey);
  if (mode === 'off') return false;
  if (mode === 'all') return true;
  if (mode === 'sample') return Math.random() < VERIFY_SAMPLE_RATE;
  return VERIFY_MODE !== 'off' && Math.random() < VERIFY_SAMPLE_RATE;
}

function directOrderNo(row) {
  return valueOf(row, ['coomNo', 'CoomNo', 'COOMNO', 'coom_no'], undefined);
}

function nestedOrderCandidate(row, coomNo) {
  if (!row || typeof row !== 'object') return null;
  const direct = directOrderNo(row);
  if (String(direct) === coomNo) return row;

  const orderMaster = valueOf(row, ['c_Order_M', 'C_Order_M', 'orderMaster', 'coom', '_source'], null);
  if (orderMaster && String(directOrderNo(orderMaster)) === coomNo) return row;

  return null;
}

function findOrderNode(value, coomNo, depth) {
  if (depth > 10 || value === null || value === undefined) return null;

  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findOrderNode(item, coomNo, depth + 1);
      if (found) return found;
    }
    return null;
  }

  if (typeof value !== 'object') return null;

  const candidate = nestedOrderCandidate(value, coomNo);
  if (candidate) return candidate;

  for (const key of Object.keys(value)) {
    const found = findOrderNode(value[key], coomNo, depth + 1);
    if (found) return found;
  }

  return null;
}

function containsText(value, text, depth) {
  if (depth > 10 || value === null || value === undefined) return false;
  if (typeof value === 'string') return value.includes(text);
  if (typeof value !== 'object') return false;
  if (Array.isArray(value)) return value.some((item) => containsText(item, text, depth + 1));
  return Object.keys(value).some((key) => containsText(value[key], text, depth + 1));
}

function findOrderInResponse(res, coomNo) {
  const body = safeJson(res);
  if (!body) return null;

  const roots = [
    valueOf(body, ['data', 'Data', 'result', 'Result', 'items', 'Items', 'rows', 'Rows'], null),
    body,
  ];

  // Docker search 格式: {response: {Data: ...}}
  if (body.response) {
    roots.unshift(valueOf(body.response, ['Data', 'data'], null));
  }

  for (const root of roots) {
    const found = findOrderNode(root, coomNo, 0);
    if (found) return found;
  }

  return null;
}

// ES 直查（Docker 模式 verify 用）
function queryEsDirect(coomNo, scenarioKey) {
  const tags = {
    scenario_id: scenarioKey,
    operation: 'verify',
    verify_endpoint: 'es_direct',
  };

  const searchBody = JSON.stringify({
    query: { term: { coom_no: coomNo } },
  });

  const res = http.post(`${ES_URL}/${ES_INDEX}/_search`, searchBody, {
    headers: { 'Content-Type': 'application/json' },
    timeout: REQUEST_TIMEOUT,
    tags,
  });

  if (res.status !== 200) return null;

  const body = safeJson(res);
  if (!body || !body.hits || !Array.isArray(body.hits.hits)) return null;
  if (body.hits.hits.length === 0) return null;

  return body.hits.hits[0];
}

function verifyViaSearchApi(coomNo, cuamCid, scenarioKey) {
  const payload = buildSellerSearch(cuamCid, {
    coomNo,
    range: verifyRangeCoveringNow(),
    pageSize: SELLER_SEARCH_PAGE_SIZE,
  });

  const tags = {
    scenario_id: scenarioKey,
    scenario_name: SCENARIOS[scenarioKey].name,
    scenario_type: SCENARIOS[scenarioKey].type,
    operation: 'verify',
    verify_endpoint: scenarioPath('s6'),
  };

  const fullUrl = scenarioFullUrl('s6');
  const res = postJson(fullUrl, payload, tags);
  apiOkRate.add(isOk(res), tags);
  return res;
}

function verifyLoop(scenarioKey, cuamCid, coomNo, matcher) {
  const start = Date.now();
  const deadline = start + FRESHNESS_SLA_MS + VERIFY_TIMEOUT_BUFFER_MS;
  const tags = {
    scenario_id: scenarioKey,
    scenario_name: SCENARIOS[scenarioKey].name,
    scenario_type: SCENARIOS[scenarioKey].type,
  };

  writeVerifyAttempts.add(1, tags);

  while (Date.now() <= deadline) {
    if (isDockerMode()) {
      const hit = queryEsDirect(coomNo, scenarioKey);
      if (hit && matcher(hit)) {
        const elapsed = Date.now() - start;
        writeFreshness.add(elapsed, tags);
        writeVerifySuccessRate.add(elapsed <= FRESHNESS_SLA_MS, tags);
        if (elapsed > FRESHNESS_SLA_MS) writeVerifyMisses.add(1, tags);
        return elapsed;
      }
    } else {
      const res = verifyViaSearchApi(coomNo, cuamCid, scenarioKey);
      if (res.status === 200) {
        const orderNode = findOrderInResponse(res, coomNo);
        if (orderNode && matcher(orderNode)) {
          const elapsed = Date.now() - start;
          writeFreshness.add(elapsed, tags);
          writeVerifySuccessRate.add(elapsed <= FRESHNESS_SLA_MS, tags);
          if (elapsed > FRESHNESS_SLA_MS) writeVerifyMisses.add(1, tags);
          return elapsed;
        }
      }
    }
    sleep(VERIFY_POLL_INTERVAL_MS / 1000);
  }

  writeVerifyMisses.add(1, tags);
  writeVerifySuccessRate.add(false, tags);
  return -1;
}

export function verifyOrderVisible(coomNo, cuamCid, scenarioKey = 's1') {
  return verifyLoop(scenarioKey, cuamCid, coomNo, () => true);
}

export function verifySellerMemoVisible(coomNo, cuamCid, memo, scenarioKey = 's5') {
  return verifyLoop(scenarioKey, cuamCid, coomNo, (orderNode) => containsText(orderNode, memo, 0));
}
