// ============================================================
//  情境 3:APP 首頁訂單數據(固定條件)  [查詢/聚合]
//  端點:POST /search/GetAppDashboardOverview   目標:1000/分
//  本檔「完全自包含」:只用 k6 內建模組,單檔即可交付/執行。
//
//  跑法:
//    k6 run scenarios/s3_app_home_dashboard.js
//    k6 run -e RATE_FACTOR=0.1 -e DURATION=5m scenarios/s3_app_home_dashboard.js
//
//  要換的真資料:旁邊放 data/members.json 會自動讀;沒有就用內建小樣本。
//  注意:此端點只吃 cuamCid,聚合查詢對 cluster 抖動較敏感,留意 p99。
// ============================================================
import http from 'k6/http';
import { check } from 'k6';
import { Rate } from 'k6/metrics';
import { SharedArray } from 'k6/data';

function num(name, def) { const v = Number(__ENV[name]); return Number.isFinite(v) ? v : def; }

const _settings = JSON.parse(open('../settings.json'));
const SCENARIO_URL = (__ENV.S3_URL || (_settings.s3 && _settings.s3.url) || 'http://10.175.50.243').replace(/\/+$/, '');
const SCENARIO_PATH = (_settings.s3 && _settings.s3.path) || '/search/GetAppDashboardOverview';
const RATE_FACTOR = num('RATE_FACTOR', 1);
const RPM = Math.max(1, Math.round(num('RPM', 1000) * RATE_FACTOR));
const DURATION = __ENV.DURATION || '10m';
const RESP_P95 = num('RESP_P95_SLA_MS', 3000);
const RESP_P99 = num('RESP_P99_SLA_MS', 5000);
const REQUEST_TIMEOUT = __ENV.REQUEST_TIMEOUT || '30s';
const RPS = RPM / 60;
const PRE_VUS = Math.max(5, Math.ceil(RPS * 4));
const MAX_VUS = Math.max(50, PRE_VUS * 2);

function loadPool(paths, fallback) {
  for (const p of paths) {
    try { const a = JSON.parse(open(p)); if (Array.isArray(a) && a.length) return a; } catch (e) { /* try next */ }
  }
  return fallback;
}
const members = new SharedArray('members', () =>
  loadPool(['../data/members.json', './data/members.json'], [528672, 528673, 528674])
    .map((r) => (typeof r === 'object' && r !== null) ? { cuamCid: Number(r.cuamCid || r.CuamCid || r.CUAMCID || r.memberId || r.id) } : { cuamCid: Number(r) })
    .filter((m) => Number.isFinite(m.cuamCid)));

function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
function pickMember() { return members.length ? pick(members) : { cuamCid: 528672 }; }

const apiOk = new Rate('api_ok_rate');
function postJson(body) {
  return http.post(`${SCENARIO_URL}${SCENARIO_PATH}`, JSON.stringify(body), {
    headers: { 'Content-Type': 'application/json' }, timeout: REQUEST_TIMEOUT,
    tags: { endpoint: SCENARIO_PATH, operation: 'primary' },
  });
}
function isOk(res) {
  return res && res.status === 200;
}

export const options = {
  scenarios: {
    s3: { executor: 'constant-arrival-rate', rate: RPM, timeUnit: '1m', duration: DURATION, preAllocatedVUs: PRE_VUS, maxVUs: MAX_VUS },
  },
  thresholds: {
    'http_req_failed{operation:primary}': ['rate<0.01'],
    'api_ok_rate{operation:primary}': ['rate>=0.99'],
    'http_req_duration{operation:primary}': [`p(95)<${RESP_P95}`, `p(99)<${RESP_P99}`],
    'dropped_iterations': ['count==0'],
  },
};

export default function () {
  const m = pickMember();
  const res = postJson({ cuamCid: m.cuamCid });
  const ok = isOk(res);
  apiOk.add(ok, { operation: 'primary' });
  check(res, { 'HTTP 200': () => ok }, { operation: 'primary' });
}
