// ============================================================
//  情境 6:賣家訂單查詢(90天,全部)  [查詢]
//  端點:POST /search/order/seller(CoodName=null)   目標:2000/分
//  本檔「完全自包含」:只用 k6 內建模組,單檔即可交付/執行。
//  與情境4同端點,差別在不帶商品名(查全部)。
//
//  跑法:
//    k6 run scenarios/s6_seller_search_all.js
//    k6 run -e RATE_FACTOR=0.1 -e DURATION=5m scenarios/s6_seller_search_all.js
//
//  要換的真資料:旁邊放 data/members.json、data/dateRanges.json 會自動讀。
// ============================================================
import http from 'k6/http';
import { check } from 'k6';
import { Rate } from 'k6/metrics';
import { SharedArray } from 'k6/data';

function num(name, def) { const v = Number(__ENV[name]); return Number.isFinite(v) ? v : def; }

const _settings = JSON.parse(open('../settings.json'));
const SCENARIO_URL = (__ENV.S6_URL || (_settings.s6 && _settings.s6.url) || 'http://10.175.50.243').replace(/\/+$/, '');
const SCENARIO_PATH = (_settings.s6 && _settings.s6.path) || '/search/order/seller';
const RATE_FACTOR = num('RATE_FACTOR', 1);
const RPM = Math.max(1, Math.round(num('RPM', 2000) * RATE_FACTOR));
const DURATION = __ENV.DURATION || '10m';
const RESP_P95 = num('RESP_P95_SLA_MS', 3000);
const RESP_P99 = num('RESP_P99_SLA_MS', 5000);
const PAGE_SIZE = Math.floor(num('SELLER_SEARCH_PAGE_SIZE', 50));
const REQUEST_TIMEOUT = __ENV.REQUEST_TIMEOUT || '30s';
const RPS = RPM / 60;
const PRE_VUS = Math.max(5, Math.ceil(RPS * 4));
const MAX_VUS = Math.max(50, PRE_VUS * 2);

function loadPool(paths, fallback) {
  for (const p of paths) {
    try { const a = JSON.parse(open(p)); if (Array.isArray(a) && a.length) return a; } catch (e) { /* try next */ }
  }
  return fallback;
}
const members = new SharedArray('members', () =>
  loadPool(['../data/members.json', './data/members.json'], [528672, 528673, 528674])
    .map((r) => (typeof r === 'object' && r !== null) ? { cuamCid: Number(r.cuamCid || r.CuamCid || r.CUAMCID || r.memberId || r.id) } : { cuamCid: Number(r) })
    .filter((m) => Number.isFinite(m.cuamCid)));
const dateRanges = new SharedArray('dateRanges', () =>
  loadPool(['../data/dateRanges.json', './data/dateRanges.json'], [{ startDaysAgo: 90, endDaysAgo: 0 }]));

function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
function pickMember() { return members.length ? pick(members) : { cuamCid: 528672 }; }
// 查詢區間(s2/s4/s6/s7 共用,說明見 helpers.js pickRange)
//   QUERYDATE=基準日(2026-10-07=台灣當天結束;也可給完整時間,沒寫時區=台灣時間)
//   QUERYDAYS=往前幾天(預設取 data/dateRanges.json);兩個都沒設=現在往前 N 天到現在
const DAY_MS = 24 * 3600 * 1000;
function parseQueryBase(raw) {
  const s = String(raw).trim();
  let m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], 23, 59, 59, 999) - 8 * 3600 * 1000;
  m = s.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)) - 8 * 3600 * 1000;
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})$/.test(s)) {
    const t = Date.parse(s);
    if (Number.isFinite(t)) return t;
  }
  throw new Error(`QUERYDATE 格式看不懂:${s}(請用 2026-10-07、2026-10-07 12:00 或 2026-10-07T12:00:00+08:00)`);
}
const QUERY_END_MS = __ENV.QUERYDATE ? parseQueryBase(__ENV.QUERYDATE) : null;
const QUERY_DAYS = Number(__ENV.QUERYDAYS) > 0 ? Number(__ENV.QUERYDAYS) : 0;
function pickRange() {
  const r = dateRanges.length ? pick(dateRanges) : { startDaysAgo: 90, endDaysAgo: 0 };
  const sda = (r.startDaysAgo === undefined) ? 90 : Number(r.startDaysAgo);
  const eda = (r.endDaysAgo === undefined) ? 0 : Number(r.endDaysAgo);
  const fixedStart = r.start || r.searchStartDate || r.OrderDateStart;
  const fixedEnd = r.end || r.searchEndDate || r.OrderDateEnd;
  if (QUERY_END_MS === null && !QUERY_DAYS && fixedStart && fixedEnd) return { start: fixedStart, end: fixedEnd };
  const days = QUERY_DAYS || (sda - eda) || 90;
  const endMs = QUERY_END_MS !== null ? QUERY_END_MS : Date.now() - eda * DAY_MS;
  return { start: new Date(endMs - days * DAY_MS).toISOString(), end: new Date(endMs).toISOString() };
}

function buildSellerSearch(cuamCid, coodName, range) {
  return {
    PageIndex: 0, PageSize: PAGE_SIZE, CuamCid: cuamCid,
    OrderDateStart: range.start, OrderDateEnd: range.end,
    DeliverMethodSearchKind: null, OrdChannelKindSearchKind: null, TempTypeSearchKind: null,
    CoomNo: null, CoomName: null, EsmmShipNo: null,
    CoodName: coodName, CoocNo: null, OrderState: null,
    OrderSorts: [1, 3], IsQaList: false,
  };
}

const apiOk = new Rate('api_ok_rate');
function postJson(body) {
  return http.post(`${SCENARIO_URL}${SCENARIO_PATH}`, JSON.stringify(body), {
    headers: { 'Content-Type': 'application/json' }, timeout: REQUEST_TIMEOUT,
    tags: { endpoint: SCENARIO_PATH, operation: 'primary' },
  });
}
function isOk(res) {
  return res && res.status === 200;
}

export const options = {
  scenarios: {
    s6: { executor: 'constant-arrival-rate', rate: RPM, timeUnit: '1m', duration: DURATION, preAllocatedVUs: PRE_VUS, maxVUs: MAX_VUS },
  },
  thresholds: {
    'http_req_failed{operation:primary}': ['rate<0.01'],
    'api_ok_rate{operation:primary}': ['rate>=0.99'],
    'http_req_duration{operation:primary}': [`p(95)<${RESP_P95}`, `p(99)<${RESP_P99}`],
    'dropped_iterations': ['count==0'],
  },
};

export default function () {
  const m = pickMember();
  const r = pickRange();
  const res = postJson(buildSellerSearch(m.cuamCid, null, r));
  const ok = isOk(res);
  apiOk.add(ok, { operation: 'primary' });
  check(res, { 'HTTP 200': () => ok }, { operation: 'primary' });
}
