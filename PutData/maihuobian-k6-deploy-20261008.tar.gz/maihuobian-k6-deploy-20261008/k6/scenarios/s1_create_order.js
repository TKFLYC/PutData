// ============================================================
//  情境 1:購物車成立訂單  [寫入,非同步]
//  端點:POST /orders/add (正式) 或 /events/create (Docker)
//  目標:1500/分
//  本檔「完全自包含」:只用 k6 內建模組,單檔即可交付/執行。
//  請求內容:有 ../data/s1_template.json(客戶模板)就用模板,
//    每筆換 ${CoomNo}、${CoocNo}(亂數且不重複)、${CreateDatetime}(現在),
//    CoomOrderDate 改成台灣今天 00:00(S1_ORDER_DATE_MODE=now 改成現在);沒有模板才用內建範例。
//
//  跑法:
//    k6 run scenarios/s1_create_order.js
//    k6 run -e RATE_FACTOR=0.1 -e DURATION=5m scenarios/s1_create_order.js
// ============================================================
import http from 'k6/http';
import { check } from 'k6';
import { Rate } from 'k6/metrics';
import { SharedArray } from 'k6/data';
import exec from 'k6/execution';

function num(name, def) { const v = Number(__ENV[name]); return Number.isFinite(v) ? v : def; }
function clamp09(v) { return Math.min(9, Math.max(0, Math.floor(v))); }

const _settings = JSON.parse(open('../settings.json'));
const S1_URL = (__ENV.S1_URL || (_settings.s1 && _settings.s1.url) || 'http://10.175.50.243').replace(/\/+$/, '');
const S1_PATH = (_settings.s1 && _settings.s1.path) || '/orders/add';
const RATE_FACTOR = num('RATE_FACTOR', 1);
const RPM = Math.max(1, Math.round(num('RPM', 1500) * RATE_FACTOR));
const DURATION = __ENV.DURATION || '10m';
const RESP_P95 = num('RESP_P95_SLA_MS', 3000);
const RESP_P99 = num('RESP_P99_SLA_MS', 5000);
const REQUEST_TIMEOUT = __ENV.REQUEST_TIMEOUT || '30s';
const INSTANCE_ID = clamp09(num('INSTANCE_ID', 0));
const ORDER_DATE_MODE = (__ENV.S1_ORDER_DATE_MODE || 'midnight').toLowerCase();
const RPS = RPM / 60;
const PRE_VUS = Math.max(5, Math.ceil(RPS * 4));
const MAX_VUS = Math.max(50, PRE_VUS * 2);

function loadPool(paths, fallback) {
  for (const p of paths) {
    try { const a = JSON.parse(open(p)); if (Array.isArray(a) && a.length) return a; } catch (e) { /* try next */ }
  }
  return fallback;
}
const members = new SharedArray('members', () =>
  loadPool(['../data/members.json', './data/members.json'], [528672, 528673, 528674])
    .map((r) => (typeof r === 'object' && r !== null) ? { cuamCid: Number(r.cuamCid || r.CuamCid || r.CUAMCID || r.memberId || r.id) } : { cuamCid: Number(r) })
    .filter((m) => Number.isFinite(m.cuamCid)));

function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
function pickMember() { return members.length ? pick(members) : { cuamCid: 528672 }; }
let fallbackCounter = 0;
function pad(v, w) { return String(v).padStart(w, '0'); }
function taiwanNow() { return new Date(Date.now() + 8 * 3600 * 1000); }
function ymd() { const t = taiwanNow(); return `${String(t.getUTCFullYear()).slice(2)}${pad(t.getUTCMonth() + 1, 2)}${pad(t.getUTCDate(), 2)}`; }
function isoNoMillis(d) { return d.toISOString().replace(/\.\d{3}Z$/, 'Z'); }
function taiwanTodayMidnightIso() {
  const t = taiwanNow();
  return isoNoMillis(new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate()) - 8 * 3600 * 1000));
}
function iterSeq() {
  try { if (exec && exec.scenario && Number.isFinite(exec.scenario.iterationInInstance)) return exec.scenario.iterationInInstance; } catch (e) { /* setup */ }
  fallbackCounter += 1; return fallbackCounter;
}
// 7 位流水:同一輪不重複、外觀打散(說明見 helpers.js nextOrderIds)
const SPACE = 10000000;
function scramble(base, a, b) { return (a * base + b) % SPACE; }
function nextIds(runSalt) {
  const base = (INSTANCE_ID * 100000 + (iterSeq() % 100000) + (Number(runSalt) || 0)) % SPACE;
  const d = ymd();
  return { coomNo: `CM${d}${pad(scramble(base, 7654321, 1234567), 7)}`, coocNo: `CC${d}${pad(scramble(base, 3141593, 7777777), 7)}` };
}

// 客戶模板
const TEMPLATE_KEYS = ['CoomNo', 'CoocNo', 'CreateDatetime'];
const TEMPLATE_RAW = (() => { try { return open('../data/s1_template.json'); } catch (e) { return ''; } })();
if (TEMPLATE_RAW) {
  const unknown = [...new Set((TEMPLATE_RAW.match(/\$\{[^}]*\}/g) || []).map((x) => x.slice(2, -1)).filter((k) => !TEMPLATE_KEYS.includes(k)))];
  if (unknown.length) throw new Error(`s1_template.json 有不認得的參數:${unknown.join(', ')}`);
  JSON.parse(TEMPLATE_RAW);
}
function setOrderDates(node, value) {
  if (Array.isArray(node)) { node.forEach((x) => setOrderDates(x, value)); return; }
  if (node && typeof node === 'object') {
    Object.keys(node).forEach((k) => { if (/OrderDate$/i.test(k) && typeof node[k] === 'string') node[k] = value; else setOrderDates(node[k], value); });
  }
}
function buildFromTemplate(ids) {
  const v = { CoomNo: ids.coomNo, CoocNo: ids.coocNo, CreateDatetime: isoNoMillis(new Date()) };
  const body = JSON.parse(TEMPLATE_RAW.replace(/\$\{(CoomNo|CoocNo|CreateDatetime)\}/g, (_, k) => v[k]));
  setOrderDates(body, ORDER_DATE_MODE === 'now' ? v.CreateDatetime : taiwanTodayMidnightIso());
  return body;
}

function buildCreateOrder(cuamCid, ids) {
  const now = new Date().toISOString();
  return {
    Sender: { System: 'C2C', Module: '3101', UserId: String(cuamCid) },
    List: [{
      coom: {
        CoomNo: ids.coomNo, CoomOrderDate: now, CoomName: 'k6test', CoomStatus: '10',
        CoomTempType: '01', CoomCreateDatetime: now, CoomCuamCid: cuamCid,
        CoomSellerGoodsTotalAmt: 138, CoomGoodsItemNum: 1, CoomGoodsTotalNum: 1,
        CoomRcvTotalAmt: 138, CoomCgdmId: 'GM2512170027503', CoomMergeListCoomNo: null,
      },
      cooc: {
        CoocNo: ids.coocNo, CoocPaymentType: '1', CoocDeliverMethod: '1', CoocOrdChannelKind: '1',
        CoocMemSid: cuamCid, CoocCreateDatetime: now,
        CoocOrdNameEnc: '9mGOVIAvjlA=', CoocRcvNameEnc: '1P9BqbGAeqs=',
        CoocRcvMobileEnc: 'RqoEfNAfHAsC67TumJ+FQQ==', CoocPaymentDueday: null, CoocPaymentPayDatetime: null,
      },
      cood: [{
        CgddId: '2601270002368654', CoodCgdsId: '2601270002368655', CoodName: 'k6 測試商品',
        CoodQty: 1, CoodOriginalPrice: 100, CoodDiscountPrice: 100, CoodReceivePrice: 100,
        CoodImagePath: '2601270002368647.jpg',
      }],
      cgdi: { CgdiNumberColumn1: 60 },
    }],
  };
}

const apiOk = new Rate('api_ok_rate');

function postJson(fullUrl, body, op) {
  return http.post(fullUrl, JSON.stringify(body), {
    headers: { 'Content-Type': 'application/json' }, timeout: REQUEST_TIMEOUT,
    tags: { endpoint: fullUrl, operation: op || 'primary' },
  });
}

function isOk(res) {
  return res && res.status === 200;
}

export const options = {
  scenarios: {
    s1: { executor: 'constant-arrival-rate', rate: RPM, timeUnit: '1m', duration: DURATION, preAllocatedVUs: PRE_VUS, maxVUs: MAX_VUS },
  },
  thresholds: {
    'http_req_failed{operation:primary}': ['rate<0.01'],
    'api_ok_rate{operation:primary}': ['rate>=0.99'],
    'http_req_duration{operation:primary}': [`p(95)<${RESP_P95}`, `p(99)<${RESP_P99}`],
    'dropped_iterations': ['count==0'],
  },
};

export function setup() {
  console.log(`s1 請求內容:${TEMPLATE_RAW ? '客戶模板 ../data/s1_template.json' : '內建範例(找不到模板)'}`);
  return { runSalt: Math.floor(Math.random() * SPACE) };
}

export default function (data) {
  const m = pickMember();
  const ids = nextIds(data && data.runSalt);
  const body = TEMPLATE_RAW ? buildFromTemplate(ids) : buildCreateOrder(m.cuamCid, ids);
  const res = postJson(`${S1_URL}${S1_PATH}`, body);
  const ok = isOk(res);
  apiOk.add(ok, { operation: 'primary' });
  check(res, { 'HTTP 200': () => ok }, { operation: 'primary' });
}
