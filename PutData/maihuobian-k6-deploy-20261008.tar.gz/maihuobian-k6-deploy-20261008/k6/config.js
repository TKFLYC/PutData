// ============================================================
//  賣貨便 k6 壓測 — 集中設定檔
//  原則:環境、負載、SLA、verify、分散式單號區隔都只在這裡調。
// ============================================================

function numberEnv(name, fallback, minValue) {
  const raw = __ENV[name];
  if (raw === undefined || raw === null || raw === '') return fallback;
  const value = Number(raw);
  if (!Number.isFinite(value)) return fallback;
  if (minValue !== undefined && value < minValue) return minValue;
  return value;
}

function intEnv(name, fallback, minValue, maxValue) {
  let value = Math.floor(numberEnv(name, fallback, minValue));
  if (maxValue !== undefined && value > maxValue) value = maxValue;
  return value;
}

function boolEnv(name, fallback) {
  const raw = __ENV[name];
  if (raw === undefined || raw === null || raw === '') return fallback;
  return ['1', 'true', 'yes', 'y', 'on'].includes(String(raw).toLowerCase());
}

function normalizeVerifyMode(raw) {
  const value = String(raw || 'auto').toLowerCase();
  if (['auto', 'all', 'sample', 'off'].includes(value)) return value;
  if (['true', '1', 'yes', 'y', 'on'].includes(value)) return 'auto';
  if (['false', '0', 'no', 'n'].includes(value)) return 'off';
  return 'auto';
}

// ── per-scenario settings ──
const _settings = JSON.parse(open('./settings.json'));

const DEFAULT_PATHS = {
  s1: '/orders/add',
  s2: '/search/GetHomeToDoOverview',
  s3: '/search/GetAppDashboardOverview',
  s4: '/search/order/seller',
  s5: '/orders/update/seller-memo',
  s6: '/search/order/seller',
  s7: '/search/GetAppSalesMetrics',
};

function resolveScenarioUrl(key) {
  const envKey = `${key.toUpperCase()}_URL`;
  if (__ENV[envKey]) return __ENV[envKey].replace(/\/+$/, '');
  const entry = _settings[key];
  if (entry && entry.url) return entry.url.replace(/\/+$/, '');
  return 'http://10.175.50.243';
}

function resolveScenarioPath(key) {
  const entry = _settings[key];
  if (entry && entry.path) return entry.path;
  return DEFAULT_PATHS[key] || '';
}

export function scenarioUrl(key) {
  return resolveScenarioUrl(key);
}

export function scenarioPath(key) {
  return resolveScenarioPath(key);
}

export function scenarioFullUrl(key) {
  return `${resolveScenarioUrl(key)}${resolveScenarioPath(key)}`;
}

export const ES_URL = (__ENV.ES_URL || (_settings.es && _settings.es.url) || '').replace(/\/+$/, '');
export const ES_INDEX = __ENV.ES_INDEX || 'order';

export function isDockerMode() {
  return ES_URL !== '';
}

export const MEMBER_DEFAULT = numberEnv('MEMBER_DEFAULT', 528672, 1);

export const SELECTED_SCENARIO = (__ENV.SCENARIO || 'all').toLowerCase();
export const LOAD_DURATION = __ENV.DURATION || '10m';
export const GRACEFUL_STOP = __ENV.GRACEFUL_STOP || '30s';

export const RATE_FACTOR = numberEnv('RATE_FACTOR', 1, 0);

export const RESP_P95_SLA_MS = numberEnv('RESP_P95_SLA_MS', 3000, 1);
export const RESP_P99_SLA_MS = numberEnv('RESP_P99_SLA_MS', 5000, 1);
export const HTTP_REQ_FAILED_RATE = numberEnv('HTTP_REQ_FAILED_RATE', 0.01, 0);
export const API_OK_RATE = numberEnv('API_OK_RATE', 0.99, 0);

export const FRESHNESS_SLA_MS = numberEnv('FRESHNESS_SLA_MS', 3000, 1);
export const FRESHNESS_P99_SLA_MS = numberEnv('FRESHNESS_P99_SLA_MS', FRESHNESS_SLA_MS, 1);
export const WRITE_VERIFY_OK_RATE = numberEnv('WRITE_VERIFY_OK_RATE', 0.99, 0);
export const VERIFY_POLL_INTERVAL_MS = numberEnv('VERIFY_POLL_INTERVAL_MS', 300, 50);
export const VERIFY_TIMEOUT_BUFFER_MS = numberEnv('VERIFY_TIMEOUT_BUFFER_MS', 1000, 0);

export const VERIFY_MODE = normalizeVerifyMode(__ENV.VERIFY_MODE || __ENV.VERIFY);
export const VERIFY_SAMPLE_RATE = numberEnv('VERIFY_SAMPLE_RATE', 0.05, 0);

export const PRE_ALLOCATED_VUS = intEnv('PRE_ALLOCATED_VUS', 0, 0);
export const MAX_VUS = intEnv('MAX_VUS', 0, 0);
export const MIN_PRE_ALLOCATED_VUS = intEnv('MIN_PRE_ALLOCATED_VUS', 5, 1);
export const VU_HEADROOM_SECONDS = numberEnv('VU_HEADROOM_SECONDS', 4, 1);
export const MAX_VUS_MULTIPLIER = numberEnv('MAX_VUS_MULTIPLIER', 2, 1);

export const REQUEST_TIMEOUT = __ENV.REQUEST_TIMEOUT || '30s';

export const INSTANCE_ID = intEnv('INSTANCE_ID', intEnv('INSTANCE', 0, 0, 9), 0, 9);
export const ORDER_RUN_ID = intEnv('ORDER_RUN_ID', new Date().getHours() % 10, 0, 9);
export const ORDER_NO_PREFIX = __ENV.ORDER_NO_PREFIX || 'CM';
export const ORDER_CHILD_NO_PREFIX = __ENV.ORDER_CHILD_NO_PREFIX || 'CC';

// s1 客戶模板的 CoomOrderDate：midnight＝台灣今天 00:00（預設），now＝現在時間
export const S1_ORDER_DATE_MODE = (__ENV.S1_ORDER_DATE_MODE || 'midnight').toLowerCase();

// s5 只更新 s1 建出來的訂單（setup 先用 s1 模板建 S5_SEED_ORDER_COUNT 筆）；
// 要改用 data/orders.json 的既存訂單才設 S5_USE_ORDERS_JSON=1
export const S5_USE_ORDERS_JSON = boolEnv('S5_USE_ORDERS_JSON', false);

// 查詢區間（s2／s4／s6／s7 共用）；變數名稱刻意不含底線（客戶 VDI 會吃掉底線）
//   QUERYDATE＝基準日：2026-10-07＝台灣當天結束；也可給完整時間（沒寫時區＝台灣時間）
//   QUERYDAYS＝往前幾天；沒設就用 data/dateRanges.json（90）
export const QUERY_DATE = __ENV.QUERYDATE || '';
export const QUERY_DAYS = numberEnv('QUERYDAYS', 0, 0);

export const S5_ALLOW_SETUP_SEED = boolEnv('S5_ALLOW_SETUP_SEED', true);
// 試跑時可用不含底線的 S5SEED 少建幾張（客戶 VDI 會吃掉底線）
export const S5_SEED_ORDER_COUNT = intEnv('S5_SEED_ORDER_COUNT', intEnv('S5SEED', 400, 0), 0);
export const S5_SEED_SETTLE_SECONDS = numberEnv('S5_SEED_SETTLE_SECONDS', 3, 0);

export const SELLER_SEARCH_PAGE_SIZE = intEnv('SELLER_SEARCH_PAGE_SIZE', 50, 1);
export const APP_SALES_DATE_RANGE_TYPE = __ENV.APP_SALES_DATE_RANGE_TYPE || 'Today';

export const CREATE_ORDER_DEFAULTS = {
  senderSystem: __ENV.SENDER_SYSTEM || 'C2C',
  createModule: __ENV.CREATE_ORDER_MODULE || '3101',
  memoModule: __ENV.UPDATE_MEMO_MODULE || '2201',
  orderName: __ENV.CREATE_ORDER_NAME || 'k6test',
  productName: __ENV.CREATE_PRODUCT_NAME || 'k6 測試商品',
  productImagePath: __ENV.CREATE_PRODUCT_IMAGE_PATH || '2601270002368647.jpg',
  cgdmId: __ENV.CREATE_CGDM_ID || 'GM2512170027503',
  cgddId: __ENV.CREATE_CGDD_ID || '2601270002368654',
  cgdsId: __ENV.CREATE_CGDS_ID || '2601270002368655',
  itemPrice: numberEnv('CREATE_ITEM_PRICE', 100, 1),
  sellerGoodsTotalAmt: numberEnv('CREATE_SELLER_GOODS_TOTAL_AMT', 138, 1),
  receiveTotalAmt: numberEnv('CREATE_RECEIVE_TOTAL_AMT', 138, 1),
  freightAmount: numberEnv('CREATE_FREIGHT_AMOUNT', 60, 0),
  orderStatus: __ENV.CREATE_ORDER_STATUS || '10',
  tempType: __ENV.CREATE_TEMP_TYPE || '01',
  paymentType: __ENV.CREATE_PAYMENT_TYPE || '1',
  deliverMethod: __ENV.CREATE_DELIVER_METHOD || '1',
  orderChannelKind: __ENV.CREATE_ORDER_CHANNEL_KIND || '1',
};

export const SCENARIOS = {
  s1: {
    id: 's1',
    exec: 's1',
    name: '購物車成立訂單',
    defaultPath: '/orders/add',
    type: 'write',
    rpm: numberEnv('S1_RPM', 1500, 1),
    sourceSalt: 0,
  },
  s2: {
    id: 's2',
    exec: 's2',
    name: 'WEB首頁賣家總覽',
    defaultPath: '/search/GetHomeToDoOverview',
    type: 'query',
    rpm: numberEnv('S2_RPM', 1700, 1),
    sourceSalt: 0,
  },
  s3: {
    id: 's3',
    exec: 's3',
    name: 'APP首頁訂單數據',
    defaultPath: '/search/GetAppDashboardOverview',
    type: 'query',
    rpm: numberEnv('S3_RPM', 1000, 1),
    sourceSalt: 0,
  },
  s4: {
    id: 's4',
    exec: 's4',
    name: '賣家訂單查詢-商品名模糊',
    defaultPath: '/search/order/seller',
    type: 'query',
    rpm: numberEnv('S4_RPM', 2000, 1),
    sourceSalt: 0,
  },
  s5: {
    id: 's5',
    exec: 's5',
    name: '更新賣家備註',
    defaultPath: '/orders/update/seller-memo',
    type: 'write',
    rpm: numberEnv('S5_RPM', 800, 1),
    sourceSalt: 1,
  },
  s6: {
    id: 's6',
    exec: 's6',
    name: '賣家訂單查詢-全部',
    defaultPath: '/search/order/seller',
    type: 'query',
    rpm: numberEnv('S6_RPM', 2000, 1),
    sourceSalt: 0,
  },
  s7: {
    id: 's7',
    exec: 's7',
    name: 'APP數據中心-銷售數據',
    defaultPath: '/search/GetAppSalesMetrics',
    type: 'query',
    rpm: numberEnv('S7_RPM', 1000, 1),
    sourceSalt: 0,
  },
};

export const SCENARIO_ORDER = ['s1', 's2', 's3', 's4', 's5', 's6', 's7'];

export function scenarioKeysFromSelection(selection = SELECTED_SCENARIO) {
  if (!selection || selection === 'all') return SCENARIO_ORDER.slice();

  const keys = String(selection)
    .split(',')
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean);

  const unknown = keys.filter((key) => !SCENARIOS[key]);
  if (unknown.length > 0) {
    throw new Error(`未知 SCENARIO=${unknown.join(',')}。可用值:${SCENARIO_ORDER.join(',')},all`);
  }

  return keys;
}

export function targetRatePerMinute(scenarioKey) {
  const rate = Math.round(SCENARIOS[scenarioKey].rpm * RATE_FACTOR);
  return Math.max(rate, 1);
}

export function effectiveVerifyMode(scenarioKey, selection = SELECTED_SCENARIO) {
  if (SCENARIOS[scenarioKey].type !== 'write') return 'off';
  if (VERIFY_MODE !== 'auto') return VERIFY_MODE;
  return selection === 'all' ? 'sample' : 'all';
}

export function scenarioWillVerify(scenarioKey, selection = SELECTED_SCENARIO) {
  const mode = effectiveVerifyMode(scenarioKey, selection);
  if (mode === 'off') return false;
  if (mode === 'sample' && VERIFY_SAMPLE_RATE <= 0) return false;
  return true;
}

function estimatePreAllocatedVus(ratePerMinute) {
  if (PRE_ALLOCATED_VUS > 0) return PRE_ALLOCATED_VUS;
  const ratePerSecond = ratePerMinute / 60;
  return Math.max(MIN_PRE_ALLOCATED_VUS, Math.ceil(ratePerSecond * VU_HEADROOM_SECONDS));
}

function estimateMaxVus(preAllocatedVus) {
  if (MAX_VUS > 0) return MAX_VUS;
  return Math.max(preAllocatedVus + 1, Math.ceil(preAllocatedVus * MAX_VUS_MULTIPLIER));
}

export function buildLoadScenarios(selection = SELECTED_SCENARIO) {
  const scenarios = {};

  scenarioKeysFromSelection(selection).forEach((key) => {
    const rate = targetRatePerMinute(key);
    const preAllocatedVUs = estimatePreAllocatedVus(rate);

    scenarios[key] = {
      executor: 'constant-arrival-rate',
      rate,
      timeUnit: '1m',
      duration: LOAD_DURATION,
      preAllocatedVUs,
      maxVUs: estimateMaxVus(preAllocatedVUs),
      gracefulStop: GRACEFUL_STOP,
      exec: SCENARIOS[key].exec,
      tags: {
        scenario_id: key,
        scenario_name: SCENARIOS[key].name,
        scenario_type: SCENARIOS[key].type,
      },
    };
  });

  return scenarios;
}

export function buildThresholds(selection = SELECTED_SCENARIO) {
  const keys = scenarioKeysFromSelection(selection);
  const thresholds = {
    'http_req_failed{operation:primary}': [`rate<${HTTP_REQ_FAILED_RATE}`],
    'api_ok_rate{operation:primary}': [`rate>=${API_OK_RATE}`],
    'http_req_duration{operation:primary}': [
      `p(95)<${RESP_P95_SLA_MS}`,
      `p(99)<${RESP_P99_SLA_MS}`,
    ],
    dropped_iterations: ['count==0'],
  };

  keys.forEach((key) => {
    thresholds[`api_ok_rate{scenario_id:${key},operation:primary}`] = [`rate>=${API_OK_RATE}`];
    thresholds[`http_req_duration{scenario_id:${key},operation:primary}`] = [
      `p(95)<${RESP_P95_SLA_MS}`,
      `p(99)<${RESP_P99_SLA_MS}`,
    ];
  });

  return thresholds;
}

export function buildLoadOptions(selection = SELECTED_SCENARIO) {
  return {
    discardResponseBodies: false,
    // s5 開跑前要先建數百張單（setup），k6 預設 setup 只等 60 秒，正式機回應慢時會逾時
    setupTimeout: __ENV.SETUP_TIMEOUT || '10m',
    scenarios: buildLoadScenarios(selection),
    thresholds: buildThresholds(selection),
  };
}
