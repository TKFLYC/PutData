// ============================================================
//  P1 Smoke — 7 支端點各打一次 + 新單號寫入 + 3 秒落地 verify
//  跑法:k6 run smoke.js
// ============================================================
import { check } from 'k6';
import {
  ES_URL,
  FRESHNESS_SLA_MS,
  SCENARIOS,
  SCENARIO_ORDER,
  isDockerMode,
  scenarioFullUrl,
  scenarioPath,
  scenarioUrl,
} from './config.js';
import {
  buildAppDashboard,
  buildAppSales,
  buildCreateOrder,
  buildCreateOrderFromTemplate,
  buildHomeOverview,
  buildMemoText,
  buildSellerSearch,
  buildUpdateMemo,
  extractDockerCoomNo,
  hasS1Template,
  isOk,
  newRunSalt,
  nextOrderIds,
  pickKeyword,
  pickMember,
  pickRange,
  sendScenarioRequest,
  templateMemberId,
  verifyOrderVisible,
  verifySellerMemoVisible,
} from './helpers.js';

export const options = {
  vus: 1,
  iterations: 1,
  thresholds: {
    checks: ['rate>=0.95'],
  },
};

function compactJson(value, maxLength) {
  const text = JSON.stringify(value);
  if (text.length <= maxLength) return text;
  return `${text.slice(0, maxLength)}...`;
}

function responsePreview(res) {
  return (res.body || '').slice(0, 300).replace(/\s+/g, ' ');
}

function logRequest(scenarioKey, payload) {
  console.log(`\n[${scenarioKey}] ${SCENARIOS[scenarioKey].name}`);
  console.log(`POST ${scenarioFullUrl(scenarioKey)}`);
  console.log(`payload: ${compactJson(payload, 600)}`);
}

function logResponse(scenarioKey, res) {
  console.log(`response: HTTP ${res.status}, ${res.timings.duration.toFixed(0)}ms`);
  console.log(`body: ${responsePreview(res)}`);
  check(res, { [`${scenarioKey} HTTP 200 且 code=00`]: isOk }, {
    scenario_id: scenarioKey,
    operation: 'primary',
  });
}

function callAndLog(scenarioKey, payload) {
  logRequest(scenarioKey, payload);
  const res = sendScenarioRequest(scenarioKey, payload);
  logResponse(scenarioKey, res);
  return res;
}

export default function () {
  const member = pickMember();
  const range = pickRange();
  const keyword = pickKeyword();

  console.log('============================================================');
  console.log('賣貨便 OrderSDK.API k6 Smoke');
  console.log(`模式: ${isDockerMode() ? 'Docker 直打' : '正式環境'}`);
  console.log('--- 各情境 URL ---');
  SCENARIO_ORDER.forEach((key) => {
    console.log(`  ${key}: ${scenarioUrl(key)}${scenarioPath(key)}`);
  });
  if (ES_URL) console.log(`  ES: ${ES_URL}`);
  console.log(`會員 cuamCid=${member.cuamCid}, 日期=${range.start} ~ ${range.end}, 關鍵字=${keyword}`);
  console.log('============================================================');

  callAndLog('s2', buildHomeOverview(member, range));
  callAndLog('s3', buildAppDashboard(member));
  callAndLog('s4', buildSellerSearch(member, { coodName: keyword, range }));
  callAndLog('s6', buildSellerSearch(member, { coodName: null, range }));
  callAndLog('s7', buildAppSales(member, range));

  const ids = nextOrderIds('smoke', newRunSalt());
  const createPayload = hasS1Template() ? buildCreateOrderFromTemplate(ids) : buildCreateOrder(member, ids);
  const createMemberId = hasS1Template() ? templateMemberId(createPayload) : member.cuamCid;
  const createRes = callAndLog('s1', createPayload);

  // Docker 模式下用 Docker 回傳的 coomNo 做 verify
  let verifyCoomNo = ids.coomNo;
  if (isDockerMode()) {
    const dockerCoomNo = extractDockerCoomNo(createRes);
    if (dockerCoomNo) {
      console.log(`[s1] Docker 產生的 coomNo: ${dockerCoomNo} (k6: ${ids.coomNo})`);
      verifyCoomNo = dockerCoomNo;
    }
  }

  console.log(`\n[s1 verify] 反查新訂單 ${verifyCoomNo}, SLA=${FRESHNESS_SLA_MS}ms`);
  if (isOk(createRes)) {
    const freshnessMs = verifyOrderVisible(verifyCoomNo, createMemberId, 's1');
    if (freshnessMs >= 0) {
      console.log(`verify result: 查到,端到端 ${freshnessMs}ms`);
    } else {
      console.log('verify result: 超時未查到。可能是非同步管線延遲、查詢條件不符,或單號格式尚未被系統接受。');
    }
    check({ freshnessMs }, {
      's1 寫入後 3 秒內查得到': (o) => o.freshnessMs >= 0 && o.freshnessMs <= FRESHNESS_SLA_MS,
    }, { scenario_id: 's1', operation: 'verify' });
  } else {
    console.log('s1 收單失敗,略過 s1 verify。');
  }

  const memo = buildMemoText(verifyCoomNo);
  const memoPayload = buildUpdateMemo(member, verifyCoomNo, memo);
  const memoRes = callAndLog('s5', memoPayload);

  console.log(`\n[s5 verify] 反查賣家備註是否更新到查詢結果, memo="${memo}"`);
  if (isOk(memoRes)) {
    const memoFreshnessMs = verifySellerMemoVisible(verifyCoomNo, member.cuamCid, memo, 's5');
    if (memoFreshnessMs >= 0) {
      console.log(`verify result: 查到備註,端到端 ${memoFreshnessMs}ms`);
    } else {
      console.log('verify result: 超時未查到新備註。若查詢回傳不含備註欄位,需請 RD 提供可驗證欄位或查詢方式。');
    }
    check({ memoFreshnessMs }, {
      's5 備註更新後 3 秒內查得到': (o) => o.memoFreshnessMs >= 0 && o.memoFreshnessMs <= FRESHNESS_SLA_MS,
    }, { scenario_id: 's5', operation: 'verify' });
  } else {
    console.log('s5 更新失敗,略過 s5 verify。');
  }

  console.log('\nSmoke 完成。請優先看每支 response 是否 code=00,再看 s1/s5 verify 是否在 3 秒內查到。');
}
