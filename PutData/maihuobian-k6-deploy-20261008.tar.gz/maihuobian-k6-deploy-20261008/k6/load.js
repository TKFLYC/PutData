// ============================================================
//  P3/P5 壓測入口
//  - P3: -e SCENARIO=s4 跑單情境
//  - P5: -e SCENARIO=all 跑 7 情境混合負載
// ============================================================
import { check, sleep } from 'k6';
import {
  S5_ALLOW_SETUP_SEED,
  S5_SEED_ORDER_COUNT,
  S5_SEED_SETTLE_SECONDS,
  S5_USE_ORDERS_JSON,
  SCENARIOS,
  SELECTED_SCENARIO,
  buildLoadOptions,
  isDockerMode,
  scenarioKeysFromSelection,
  scenarioPath,
  scenarioUrl,
  targetRatePerMinute,
} from './config.js';
import {
  buildAppDashboard,
  buildAppSales,
  buildCreateOrder,
  buildCreateOrderFromTemplate,
  buildHomeOverview,
  buildMemoText,
  buildSellerSearch,
  buildUpdateMemo,
  describeQueryRange,
  hasMemoOrderData,
  hasS1Template,
  isOk,
  newRunSalt,
  nextOrderIds,
  pickKeyword,
  pickMember,
  pickMemoOrder,
  pickRange,
  recordSyntheticApiFailure,
  sendScenarioRequest,
  templateMemberId,
} from './helpers.js';

export const options = buildLoadOptions(SELECTED_SCENARIO);

function logLoadPlan() {
  const keys = scenarioKeysFromSelection(SELECTED_SCENARIO);
  console.log(`壓測模式: SCENARIO=${SELECTED_SCENARIO} (${isDockerMode() ? 'Docker 直打' : '正式環境'})`);
  keys.forEach((key) => {
    console.log(`  ${key} ${SCENARIOS[key].name}: ${targetRatePerMinute(key)} rpm → ${scenarioUrl(key)}${scenarioPath(key)}`);
  });
  if (keys.some((key) => ['s2', 's4', 's6', 's7'].includes(key))) {
    console.log(`  查詢區間(s2/s4/s6/s7 共用):${describeQueryRange()}`);
  }
  if (keys.includes('s1') || keys.includes('s5')) {
    console.log(`  s1 請求內容:${hasS1Template() ? '客戶模板 data/s1_template.json(換單號與日期)' : '內建範例(找不到模板)'}`);
  }
}

// s1 請求：有客戶模板就用模板，沒有才用內建範例
function createOrderBody(member, ids) {
  if (hasS1Template()) {
    const body = buildCreateOrderFromTemplate(ids);
    return { body, cuamCid: templateMemberId(body) };
  }
  return { body: buildCreateOrder(member, ids), cuamCid: member.cuamCid };
}

function primaryCheck(scenarioKey, res) {
  const ok = isOk(res);
  check(res, { [`${scenarioKey} HTTP 200`]: () => ok }, {
    scenario_id: scenarioKey,
    operation: 'primary',
  });
  return ok;
}

function seedMemoOrdersIfNeeded(keys, runSalt) {
  if (!keys.includes('s5')) return [];
  if (S5_USE_ORDERS_JSON && hasMemoOrderData()) {
    console.log('s5 使用 data/orders.json 的既存訂單(S5_USE_ORDERS_JSON=1)。');
    return [];
  }

  if (!S5_ALLOW_SETUP_SEED || S5_SEED_ORDER_COUNT <= 0) {
    console.log('警告:S5_ALLOW_SETUP_SEED=false 或 S5_SEED_ORDER_COUNT=0,沒有 s1 建的訂單可更新,s5 iteration 會被標成失敗。');
    return [];
  }

  console.log(`s5 要更新的訂單:setup 先用 s1(客戶模板)建立 ${S5_SEED_ORDER_COUNT} 筆,s5 只更新這些訂單。`);
  const seeded = [];
  for (let i = 0; i < S5_SEED_ORDER_COUNT; i += 1) {
    const member = pickMember();
    const ids = nextOrderIds('setup', runSalt);
    const order = createOrderBody(member, ids);
    const res = sendScenarioRequest('s1', order.body, 'setup_create');
    if (isOk(res)) seeded.push({ coomNo: ids.coomNo, cuamCid: order.cuamCid });
    sleep(0.05);
  }

  if (S5_SEED_SETTLE_SECONDS > 0 && seeded.length > 0) {
    console.log(`setup 已建立 ${seeded.length} 筆暫用訂單,等待 ${S5_SEED_SETTLE_SECONDS}s 讓非同步管線落地。`);
    sleep(S5_SEED_SETTLE_SECONDS);
  }

  return seeded;
}

export function setup() {
  logLoadPlan();
  const keys = scenarioKeysFromSelection(SELECTED_SCENARIO);
  const runSalt = newRunSalt();
  return {
    runSalt,
    seedMemoOrders: seedMemoOrdersIfNeeded(keys, runSalt),
  };
}

export function s1(data) {
  const member = pickMember();
  const ids = nextOrderIds('s1', data && data.runSalt);
  const res = sendScenarioRequest('s1', createOrderBody(member, ids).body);
  primaryCheck('s1', res);
}

export function s2() {
  const member = pickMember();
  const range = pickRange();
  const res = sendScenarioRequest('s2', buildHomeOverview(member, range));
  primaryCheck('s2', res);
}

export function s3() {
  const member = pickMember();
  const res = sendScenarioRequest('s3', buildAppDashboard(member));
  primaryCheck('s3', res);
}

export function s4() {
  const member = pickMember();
  const range = pickRange();
  const keyword = pickKeyword();
  const payload = buildSellerSearch(member, { coodName: keyword, range });
  const res = sendScenarioRequest('s4', payload);
  primaryCheck('s4', res);
}

export function s5(data) {
  const target = pickMemoOrder(data && data.seedMemoOrders);
  if (!target) {
    recordSyntheticApiFailure('s5');
    check(null, { 's5 有可更新訂單資料': () => false }, {
      scenario_id: 's5',
      operation: 'primary',
    });
    sleep(1);
    return;
  }

  const memo = buildMemoText(target.coomNo);
  const res = sendScenarioRequest('s5', buildUpdateMemo(target.cuamCid, target.coomNo, memo));
  primaryCheck('s5', res);
}

export function s6() {
  const member = pickMember();
  const range = pickRange();
  const payload = buildSellerSearch(member, { coodName: null, range });
  const res = sendScenarioRequest('s6', payload);
  primaryCheck('s6', res);
}

export function s7() {
  const member = pickMember();
  const range = pickRange();
  const res = sendScenarioRequest('s7', buildAppSales(member, range));
  primaryCheck('s7', res);
}
