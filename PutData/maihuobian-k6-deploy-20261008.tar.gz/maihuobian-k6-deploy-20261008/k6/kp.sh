{
kpw() {
local S=$1 R=$2 L=$3 P="" A i r c l M=0 C=0 T0 TE LD=0
for i in $(seq 1 100); do [ -s "$L.pid" ] && break; sleep 0.1; done
P=$(cat "$L.pid" 2>/dev/null); [ -z "$P" ] && return
T0=$(date +%s); TE=$T0
for i in $(seq 1 150); do grep -q 'rpm →' "$L" && break; kill -0 $P 2>/dev/null || break; sleep 0.2; done
A=$(grep -m1 -oE '[0-9]+ rpm →' "$L" | cut -d' ' -f1)
if [ "$A" = "$R" ]; then echo "確認: 實際每分鐘 $A 筆，開始測"
else echo "${A:-?}" > "$L.stop"; kill -9 $P 2>/dev/null; return; fi
case "$S" in s2|s4|s6|s7)
  for i in $(seq 1 10); do grep -q '查詢區間' "$L" && break; sleep 0.2; done
  grep -m1 -oE '查詢區間[^;]*' "$L" | sed 's/^/確認: /' ;;
esac
while kill -0 $P 2>/dev/null; do
  r=$(awk '/^VmRSS/{print $2}' /proc/$P/status 2>/dev/null); [ "${r:-0}" -gt "$M" ] && M=$r
  c=$(awk '{print $14+$15}' /proc/$P/stat 2>/dev/null); [ -n "$c" ] && C=$c && TE=$(date +%s)
  l=$(cut -d' ' -f1 /proc/loadavg); LD=$(awk -v a="$l" -v b="$LD" 'BEGIN{print (a>b)?a:b}')
  sleep 2
done
echo "$C $TE $T0 $M $LD" > "$L.res"
}
kp() {
local S=$1 R=$2 D=${3:-3m} W=$4 U V L RC x K F G H
H="用法: kp <s1~s7> <每分鐘筆數> [時長] [write]（s1、s5 會寫入正式資料，要加 write）"
[ "$3" = write ] && { D=3m; W=write; }
if [ -n "$KPSTOP" ]; then echo "略過 $S：之前已中斷（要重新開始先打 kpgo）"; return 2; fi
case "$S" in s1|s2|s3|s4|s5|s6|s7) ;; *) echo "$H"; return 1 ;; esac
case "$R" in ''|*[^0-9]*) echo "$H"; return 1 ;; esac
case "$S" in s1|s5) [ "$W" = write ] || { echo "STOP: $S 會寫入正式資料。客戶已同意就打：kp $S $R $D write"; return 1; } ;; esac
U=$(awk 'BEGIN{printf "%c", 95}'); V="$(echo $S | tr a-z A-Z)${U}RPM"
L="k6-$S-${R}rpm-$(date +%m%d-%H%M%S).log"; KPLAST="$L"
echo "== $(date '+%T') $S 每分鐘 $R 筆、跑 $D（中途要停按一次 Ctrl+C）→ 紀錄檔 $L"
[ "$S" = s1 ] && echo "注意: 寫入正式資料，每筆建 1 張單（客戶模板，會員 528672）"
[ "$S" = s5 ] && echo "注意: 寫入正式資料，先用 s1 建一批單（預設 400 張，需 1 分鐘以上），之後只改這些單的備註"
( kpw "$S" "$R" "$L" & )
( echo $BASHPID > "$L.pid"; exec k6 run -e SCENARIO=$S -e "$V=$R" -e DURATION=$D load.js ) > "$L" 2>&1
RC=$?
for x in $(seq 1 50); do { [ -s "$L.res" ] || [ -s "$L.stop" ]; } && break; sleep 0.2; done
if [ -s "$L.stop" ]; then KPSTOP=1; echo "STOP: 實際每分鐘 $(cat "$L.stop") 筆，不是 $R，已強制停止"; return 1; fi
G='^ +(http.req.duration|http.reqs|http.req.failed|dropped.iterations)\.'
grep -E "$G" "$L" | sed -E 's/\.{3,}/ /; s/ +/ /g' | cut -c1-150
K=$(getconf CLK${U}TCK)
F=' 資源: 主機 %d 核、負載最高 %s｜k6 平均 CPU %.1f%%（單核=100%%）、記憶體最高 %d MB\n'
[ -s "$L.res" ] && awk -v k=$K -v n=$(nproc) -v f="$F" '{e=$2-$3; printf f, n, $5, (e>0?$1/k/e*100:0), $4/1024}' "$L.res"
case "$RC" in 0|99) ;; *) KPSTOP=1; echo "已中斷（k6 結束碼 $RC），k6 已停止，後面的情境不會再跑"; return 2 ;; esac
}
kt() {
local f s n q e m p d
printf '%-4s %6s %7s %8s %10s %10s %6s\n' 情境 每分鐘 請求數 失敗率 中位數 p95 掉單
for f in "$@"; do
  s=$(echo "$f" | cut -d- -f2); n=$(echo "$f" | cut -d- -f3 | tr -d 'rpm')
  q=$(grep -E '^ +http.reqs\.' "$f" | awk '{print $2}'); e=$(grep -E '^ +http.req.failed\.' "$f" | awk '{print $2}')
  m=$(grep -E '^ +http.req.duration\.' "$f" | grep -oE 'med=[^ ]+' | cut -d= -f2)
  p=$(grep -E '^ +http.req.duration\.' "$f" | grep -oE 'p\(95\)=[^ ]+' | cut -d= -f2)
  d=$(grep -E '^ +dropped.iterations\.' "$f" | awk '{print $2}')
  printf '%-4s %6s %7s %8s %10s %10s %6s\n' "$s" "$n" "${q:-0}" "${e:--}" "${m:--}" "${p:--}" "${d:-0}"
done
}
kr() {
local M=$1 D=${2:-3m} S R x N=0 FL=""
case "$M" in full) ;; ''|*[^0-9]*) echo "用法: kr <每分鐘筆數|full>，例如 kr 100 或 kr full"; return 1 ;; esac
KPSTOP=""
for S in s2 s3 s4 s6 s7; do
  R=$M; [ "$M" = full ] && case $S in s2) R=1700 ;; s3|s7) R=1000 ;; *) R=2000 ;; esac
  [ $N -gt 0 ] && { echo "（休息 30 秒）"; sleep 30; }
  N=1; kp $S $R $D; x=$?; FL="$FL $KPLAST"
  [ $x -ne 0 ] && { echo "== 本輪中途停止"; kt $FL; return 1; }
done
echo "== 本輪完成（$M）"; kt $FL
}
kw() {
local M=$1 D=${2:-3m} W=$3 S R x N=0 FL=""
[ "$2" = write ] && { D=3m; W=write; }
case "$M" in full) ;; ''|*[^0-9]*) echo "用法: kw <每分鐘筆數|full> [時長] write（跑 s1、s5，會寫入正式資料）"; return 1 ;; esac
[ "$W" = write ] || { echo "STOP: kw 會寫入正式資料。客戶已同意就打：kw $M $D write"; return 1; }
KPSTOP=""
for S in s1 s5; do
  R=$M; [ "$M" = full ] && case $S in s1) R=1500 ;; s5) R=800 ;; esac
  [ $N -gt 0 ] && { echo "（休息 30 秒）"; sleep 30; }
  N=1; kp $S $R $D write; x=$?; FL="$FL $KPLAST"
  [ $x -ne 0 ] && { echo "== 本輪中途停止"; kt $FL; return 1; }
done
echo "== 寫入輪完成（$M）"; kt $FL
}
ka() {
local M=$1 B=$2 N=$3 D=${4:-3m} S R x K=0 FL="" Z=${KPREST:-30} H
H='用法: ka <每分鐘筆數|full> <基準日|now> [往前天數] [每支時長]，例如 ka full 2026-10-07 1'
case "$M" in full) ;; ''|*[^0-9]*) echo "$H"; return 1 ;; esac
echo "$B" | grep -qE '^(now|[0-9]{4}-[0-9]{2}-[0-9]{2}( [0-9]{2}:[0-9]{2}(:[0-9]{2})?)?)$' || { echo "$H"; return 1; }
case "$N" in ''|*[^0-9]*) [ -n "$N" ] && { echo "$H"; return 1; } ;; esac
if [ "$B" = now ]; then unset QUERYDATE; else export QUERYDATE="$B"; fi
if [ -n "$N" ]; then export QUERYDAYS="$N"; else unset QUERYDAYS; fi
echo "== 查詢基準: ${QUERYDATE:-現在}，往前 ${QUERYDAYS:-90} 天（s2 s4 s6 s7 共用；s3 沒有日期）"
echo "== 順序: s2 s3 s4 s6 s7（查詢）→ s1 s5（寫入正式資料）；每支 $D，中間休息 $Z 秒"
echo "== 10 秒後開始，全部跑完才結束；要取消或中途停止按一次 Ctrl+C"; sleep 10
KPSTOP=""
for S in s2 s3 s4 s6 s7 s1 s5; do
  R=$M; [ "$M" = full ] && case $S in s2) R=1700 ;; s3|s7) R=1000 ;; s1) R=1500 ;; s5) R=800 ;; *) R=2000 ;; esac
  [ $K -gt 0 ] && { echo "（休息 $Z 秒）"; sleep $Z; }
  K=1; kp $S $R $D write; x=$?; FL="$FL $KPLAST"
  [ $x -ne 0 ] && { echo "== 全部流程中途停止"; kt $FL; return 1; }
done
echo "== 全部完成（$M）；查詢基準仍是 ${QUERYDATE:-現在}，要恢復預設打 unset QUERYDATE QUERYDAYS"; kt $FL
}
kpgo() { KPSTOP=""; echo "已重設，可以重新開始"; }
}
