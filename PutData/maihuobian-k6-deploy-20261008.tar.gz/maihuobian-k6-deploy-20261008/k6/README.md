# 賣貨便 B2C 訂單系統 k6 壓測腳本

本資料夾是一套可離線執行的 Grafana k6 壓測腳本，涵蓋 7 支 API 情境。

## 檔案結構

```
├── settings.json          ← 情境 URL + 路徑設定（部署前必改）
├── config.js              ← 壓測參數（RPM、SLA、VU、verify 等）
├── helpers.js             ← 共用函式（HTTP 包裝、payload 建構、成功判斷）
├── smoke.js               ← 連通性測試：7 支各打一次 + 寫入落地驗證
├── load.js                ← 壓力測試：單情境 / 混合負載
├── scenarios/             ← 7 支獨立情境腳本（可單獨跑）
│   ├── s1_create_order.js
│   ├── s2_web_home_overview.js
│   ├── s3_app_home_dashboard.js
│   ├── s4_seller_search_product.js
│   ├── s5_update_seller_memo.js
│   ├── s6_seller_search_all.js
│   └── s7_app_sales_metrics.js
└── data/                  ← 測試資料母體
    ├── members.json       ← 會員清單（請換成正式資料）
    ├── keywords.json      ← 商品名模糊查詢關鍵字
    ├── dateRanges.json    ← 查詢日期區間
    └── orders.json        ← s5 更新備註用的既存訂單
```

## 前置準備

### 1. 安裝 k6

在壓測機上安裝 k6（不要裝在被測 API 主機上）：

```powershell
k6 version    # 確認已安裝
```

若內網無法下載，請預先帶入 k6 binary。本腳本不需要 `npm install`，也不依賴任何遠端模組。

### 2. 設定 settings.json

`settings.json` 控制每個情境打哪個 URL。**部署前必須修改**：

```json
{
  "s1": { "url": "http://API主機位址", "path": "/orders/add" },
  "s2": { "url": "http://API主機位址", "path": "/search/GetHomeToDoOverview" },
  "s3": { "url": "http://API主機位址", "path": "/search/GetAppDashboardOverview" },
  "s4": { "url": "http://API主機位址", "path": "/search/order/seller" },
  "s5": { "url": "http://API主機位址", "path": "/orders/update/seller-memo" },
  "s6": { "url": "http://API主機位址", "path": "/search/order/seller" },
  "s7": { "url": "http://API主機位址", "path": "/search/GetAppSalesMetrics" },
  "es": { "url": "" }
}
```

- 每個情境可以指向不同主機（若寫入/查詢服務分開部署）
- `es.url` 留空即可（正式環境不需要）

### 3. 換成正式測試資料

| 檔案 | 格式範例 | 說明 |
|------|----------|------|
| `data/members.json` | `[528672, 528673]` | 有效會員 ID 清單 |
| `data/keywords.json` | `["襪子", "手機殼"]` | 商品名模糊查詢關鍵字 |
| `data/dateRanges.json` | `[{"label":"近90天","startDaysAgo":90,"endDaysAgo":0}]` | 查詢日期區間 |
| `data/orders.json` | `[{"coomNo":"CM2606150123456","cuamCid":528672}]` | s5 用的既存訂單 |
| `data/s1_template.json` | 客戶提供的建單請求模板 | s1（以及 smoke、s5 暫用訂單）的請求內容。`${CoomNo}`、`${CoocNo}` 每筆換成亂數且不重複的單號（`CM`／`CC`＋台灣今天 yymmdd＋7 碼），`${CreateDatetime}` 換成現在時間，`CoomOrderDate` 改成台灣今天 00:00（以 UTC 表示，`-e S1_ORDER_DATE_MODE=now` 改成現在時間）；其他欄位照模板原樣送出。模板若出現其他 `${...}` 參數，k6 啟動時直接報錯 |

`orders.json` 是 s5 壓測最重要的資料。正式 800 RPM 壓測務必提供足量真實訂單，避免多個 VU 反覆更新同幾筆。

### 4. 確認網路連通

```powershell
Test-NetConnection API主機位址 -Port 80
```

---

## 測試流程

### Step 1：Smoke 連通性測試

7 支端點各打一次，確認全部 HTTP 200 + code 正確，並驗證 s1 寫入落地：

```powershell
k6 run smoke.js
```

預期結果：9 checks 全 pass（7 API + s1 verify + s5 verify）。

### Step 2：單情境試跑

先用低流量（10%）確認單一情境正常：

```powershell
# 查詢情境
k6 run -e SCENARIO=s4 -e RATE_FACTOR=0.1 -e DURATION=5m load.js

# 寫入情境
k6 run -e SCENARIO=s1 -e RATE_FACTOR=0.1 -e DURATION=5m load.js
```

### Step 3：單情境全量

```powershell
# 查詢情境（建議關閉 verify 避免額外負載）
k6 run -e SCENARIO=s4 -e RATE_FACTOR=1 -e DURATION=10m -e VERIFY_MODE=off load.js

# 寫入情境（verify 抽樣 5%）
k6 run -e SCENARIO=s1 -e RATE_FACTOR=1 -e DURATION=10m -e VERIFY_MODE=sample -e VERIFY_SAMPLE_RATE=0.05 load.js
```

### Step 4：7 情境混合全量

```powershell
k6 run -e SCENARIO=all -e RATE_FACTOR=1 -e DURATION=30m -e VERIFY_MODE=sample -e VERIFY_SAMPLE_RATE=0.02 load.js
```

總目標量約 10,000 RPM。

### Step 5：階梯加壓（選做）

逐步提高 RATE_FACTOR 找出系統瓶頸：

```powershell
# 50% → 100% → 150%
k6 run -e SCENARIO=all -e RATE_FACTOR=0.5  -e DURATION=10m load.js
k6 run -e SCENARIO=all -e RATE_FACTOR=1    -e DURATION=10m load.js
k6 run -e SCENARIO=all -e RATE_FACTOR=1.5  -e DURATION=10m load.js
```

---

## 單檔腳本（獨立執行）

每支情境腳本可以單獨跑，不依賴 `config.js` / `helpers.js`：

```powershell
k6 run scenarios/s1_create_order.js
k6 run scenarios/s4_seller_search_product.js
```

單檔腳本自行讀取 `settings.json`，適合快速驗證單一情境。

---

## 分散式多機壓測

每台壓測機設定不同 `INSTANCE_ID`（0~9）：

```powershell
# 第一台
k6 run -e SCENARIO=all -e INSTANCE_ID=0 -e ORDER_RUN_ID=1 load.js

# 第二台
k6 run -e SCENARIO=all -e INSTANCE_ID=1 -e ORDER_RUN_ID=1 load.js
```

同一天重跑不用再調 `ORDER_RUN_ID`：每一輪開跑時會自動取隨機起點，單號不會和前幾輪重複（機率約千分之一，且日期不同就不會撞）。

---

## 環境變數一覽

> 查詢日期的設定方式（名稱刻意不含底線，客戶 VDI 會吃掉底線）：
> - 直接跑 k6：`k6 run -e SCENARIO=s2 -e QUERYDATE=2026-10-07 -e QUERYDAYS=1 load.js`
> - 用分段壓測指令 kp／kr：先 `export QUERYDATE=2026-10-07 QUERYDAYS=1`，之後每一支都套用；`unset QUERYDATE QUERYDAYS` 恢復預設
> - 實際用了哪個區間：k6 啟動時會印「查詢區間(s2/s4/s6/s7 共用):…(台灣 …)」，在紀錄檔裡 `grep 查詢區間 k6-*.log`

| 變數 | 預設 | 說明 |
|------|------|------|
| `SCENARIO` | `all` | `s1`~`s7`、`all`、或 `s1,s4` 組合 |
| `RATE_FACTOR` | `1` | 目標 RPM 調節係數（0.1=10%、1=100%） |
| `DURATION` | `10m` | 壓測時間 |
| `VERIFY_MODE` | `auto` | `auto`/`all`/`sample`/`off` |
| `VERIFY_SAMPLE_RATE` | `0.05` | verify 抽樣比例 |
| `INSTANCE_ID` | `0` | 分散式壓測機編號（0~9） |
| `ORDER_RUN_ID` | 目前小時尾數 | 舊版單號用；s1 改用模板後已不需要（每輪自動隨機起點） |
| `RESP_P95_SLA_MS` | `3000` | API p95 回應時間門檻（ms） |
| `RESP_P99_SLA_MS` | `5000` | API p99 回應時間門檻（ms） |
| `FRESHNESS_SLA_MS` | `3000` | 寫入落地 SLA（ms） |
| `S5_SEED_ORDER_COUNT` | `400` | s5 開跑前先用 s1（客戶模板）建立的訂單筆數；**s5 只更新這些 s1 建的訂單** |
| `S5_USE_ORDERS_JSON` | 不設 | 設 `1` 才改用 `data/orders.json` 的既存訂單（預設不用） |
| `S1_ORDER_DATE_MODE` | `midnight` | s1 的 `CoomOrderDate`：`midnight`＝台灣今天 00:00；`now`＝現在 |
| `QUERYDATE` | 不設（＝現在） | **查詢基準日，s2／s4／s6／s7 共用**（s3 沒有日期欄位）。`2026-10-07`＝台灣當天 23:59:59；`2026-10-07 12:00`＝台灣時間；也可給 `2026-10-07T04:00:00Z` 這種含時區的寫法。其他格式啟動即報錯 |
| `QUERYDAYS` | 不設（＝`data/dateRanges.json`，90） | 往前幾天。查詢區間＝基準時間往前 QUERYDAYS×24 小時 ～ 基準時間 |

---

## 結果判讀

關鍵指標（依優先順序）：

1. **`http_req_failed{operation:primary}`** — HTTP 層失敗率，應為 0%
2. **`api_ok_rate{operation:primary}`** — API 回應成功率（HTTP 200 + code 正確）
3. **`dropped_iterations`** — 是否追不上目標 RPM（壓測機瓶頸）
4. **`http_req_duration{operation:primary}` p95/p99** — 回應時間（不看平均值）
5. **`write_freshness_ms` / `write_verify_success_rate`** — 寫入後多久查得到

`operation=primary` 只包含 7 個正式情境的主請求。verify 反查標記為 `operation=verify`，不會混入 primary 的統計。

---

## 7 情境 RPM 目標

| 情境 | 名稱 | 目標 RPM |
|------|------|---------|
| s1 | 購物車成立訂單 | 500 |
| s2 | WEB首頁賣家總覽 | 500 |
| s3 | APP首頁訂單數據 | 1,000 |
| s4 | 賣家查詢-商品名模糊 | 2,000 |
| s5 | 更新賣家備註 | 800 |
| s6 | 賣家查詢-全部 | 2,000 |
| s7 | APP銷售數據 | 3,000 |
| **合計** | | **~9,800** |

---

## 離線注意事項

- 本腳本不需要 `npm install`
- 不依賴任何遠端 CDN 模組
- 整個資料夾 + k6 binary 帶入內網即可使用
- k6 輸出預設為 console summary；如需接 Grafana/InfluxDB 請另行設定
