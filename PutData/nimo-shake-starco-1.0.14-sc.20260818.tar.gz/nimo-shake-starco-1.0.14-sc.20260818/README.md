# nimo-shake-starco 1.0.14-sc.20260818

DynamoDB → MongoDB 搬遷 + 逐欄位型別校驗工具包(基於 Alibaba NimoShake 1.0.14,含 StarCo 改寫:
`mchange_cast` 寫入前型別轉換 + 全新 nimo-full-check 校驗引擎)。

## 三行上手

```bash
vi nimo-shake.conf                            # 填入 AWS 金鑰 / MongoDB 連線字串(其餘已設好)
./nimo-shake.linux -conf ./nimo-shake.conf    # 啟動搬遷(前景執行,畫面直接看進度)
# 等 "full sync done!" → "sync complete!" 出現,程式自行退出即完成
```

全量模式(`sync_mode = full`)跑完程式會自行退出;詳細 log 在 `nimo-shake.log`。
需要背景執行(登出不中斷)、或想要啟動防呆(檔案檢查/重複啟動偵測/啟動失敗回報)時,
可改用附帶的啟停腳本:

```bash
./start.sh                # 背景啟動(setsid;預設吃 nimo-shake.conf)+ preflight 檢查
./stop.sh                 # 停止(跑完後再執行只是確認,不會報錯)
```

搬遷完成後校驗(逐欄位型別驗證,全量):

```bash
./nimo-full-check.linux \
  -s <ACCESS_KEY> --sourceSecretAccessKey=<SECRET_KEY> --sourceRegion=<region> \
  -t "mongodb+srv://<帳號>:<密碼>@<cluster>/" -i <目標db名> \
  -c mchange_cast --convertTypeRulesPath=type_rules_nimoshake.json \
  -m dynamodb --sample=0 --filterCollectionWhite=<表名> -d out_check
echo "exit=$?"   # 0=PASS / 1=FAIL / 2=執行障礙 / 3=通過但來源有不可轉資料
```

詳細部署、參數、增量期間校驗(converge)、報告判讀:見 `docs/部署與使用說明.md`。

## 檔案清單

| 檔案 | 說明 |
|---|---|
| nimo-shake.linux | 搬遷工具(含 mchange_cast 型別轉換;Linux x86_64) |
| nimo-full-check.linux | 校驗工具(StarCo 改寫版,含 converge 二次收斂;`--version` 可查) |
| nimo-shake.conf | 設定檔(填連線資訊即可用;`convert.type=mchange_cast` 已設) |
| nimo-shake.conf.example | 原始模板對照本(改壞了可以 diff 回來) |
| type_rules_nimoshake.json | 27 個列管欄位轉型規則(兩工具共用;勿移動,conf 以相對路徑引用) |
| start.sh / stop.sh | 啟停腳本(用法同舊版;改良見下) |
| ChangeLog | 版本沿革(上游歷史保留 + StarCo 條目) |
| SHA256SUMS | 檔案指紋(`sha256sum -c SHA256SUMS` 可驗) |
| docs/ | 部署與使用說明、驗證報告 |

## 與舊包(v1.0.14)的差異

- `nimo-full-check.linux` **整顆換新**:舊顆(2025-07-04)有「誤報/漏報/報 0 diff」缺陷,新顆為 StarCo 重寫版
- `start.sh` 修正:舊版執行不存在的 `./dynamo-shake` 且帶已廢棄的 `-type` 參數;新版預設吃 `nimo-shake.conf`,啟動失敗會回報(舊版靜默)。**舊的兩參數用法照樣能打**(第二參數忽略並提示)
- `stop.sh` 修正:kill 前驗證 pid 身分(防 PID 重用誤殺);「已跑完」視為正常而非錯誤
- **hypervisor 已移除**:舊包那顆是 macOS 執行檔(Linux 上從未運作),且其無條件重啟邏輯在
  `sync_mode=full + target.db.exist=drop` 下會反覆清空目標資料——已以 `setsid nohup` 背景化取代。
  如需常駐監管(`sync_mode=all`),請用 systemd(`Restart=on-failure`),勿自行補回 hypervisor
- darwin 執行檔不再附帶(目標環境為 Linux;無 macOS 驗證環境)

## 已知限制

- ⚠️ `target.db.exist = drop`:每次啟動搬遷會**先清空目標 collection**(start.sh 會印警告)
- nimo-shake 全量無斷點續傳:中斷後須整批重跑(nimo-full-check 有 `--checkpointFile` 續跑)
- pid 檔名 = conf 的 `id` 值(本包預設 `starco` → `starco.pid`;start.sh 另複製一份為固定名 `nimo-shake.pid`)
