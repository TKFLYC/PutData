# NimoShake 監控與告警 — OPAPP 1.0.16c（可續傳版）改版交付說明 v5.0

| 項目 | 內容 |
|---|---|
| 適用 | OPAPP 正式機，NimoShake `1.0.16-sc.20261001c-OPAPP`（2026-10-05 起） |
| 依據 | YC《NimoShake 1.0.16c（OPAPP）log 格式與監控改版說明》2026-10-06 第 2 版（下稱「規格」）、遮罩樣本 `02_log樣本_已遮罩_2026-10-06.txt`、1.0.16c 交付包 `start.sh`／`stop.sh`／`docs/變更說明_1.0.16.md` |
| 交付日期 | 2026-10-08（10-07 初版，10-08 依外部審查 5 點修正後重測） |
| 版本 | monitor v5.0 / alert v5.0（OPAPP 專用；MyShip 維持 v4.3 不變，兩套分開維護） |
| 狀態 | 程式與自測完成，待 YC 依規格 §8.3 審查、重播測試、正式機 `DRY_RUN=1` 試跑 7 天後部署 |

---

## 1. 為什麼要改版（結論）

OPAPP 正式機 2026-10-05 02:04 UTC 起改用 1.0.16c 可續傳版。這版的 log 字樣、HTTP API、退出行為與 1.0.14／1.0.15 完全不同，現行 v4.3 監控在 1.0.16c 上：

| 失效項目 | 原因 |
|---|---|
| 全量進度（9341 `/progress`） | 永遠回空殼 `{"progress":"-%",…,"collection_metric":{}}` |
| CDC 統計（9340 `/metric`） | 埠沒開 |
| 階段、表進度、效能、增量 | 16 個舊字樣（`scanCount`、`stage=incr`、`checkpoint map:`、`full sync done` …）在 1.0.16c 都不存在 |
| ERROR 告警 | log4go 把 ERROR 印成 `[EROR]`，舊比對式 `[ERROR]` 從未命中（既有 bug，舊版也一樣） |
| PANIC 告警 | panic 只出現在 `nimo-shake.linux.output`，不在 log |
| 資安 | 舊版讀 `configuration:` 行（含 AWS 金鑰與 Mongo 密碼明文）並把原始行放進 JSON 與信件；FullCheck 信含主鍵與資料值 |

因此依規格重寫，**只讀 3 個來源**：log（附錄 A 錨定 ERE）、`.output`（白名單行）、pid 檔＋`/proc/<pid>/exe`。不再打任何 HTTP 端點。

---

## 2. 架構

```
cron 每分鐘 ──▶ nimoshake-alert.sh (state/ 唯一寫入者)
                 ├─ (1) log 新段落: inode+offset 跨輪替讀取，只讀到最後一個完整行
                 ├─ (2) .output 新段落: 自己的 offset，首次只建基準
                 ├─ (3) 存活 (alive_pid) + 停機起算時間
                 ├─ (4) 階段狀態機 ns_state.awk ──▶ state/ns_state
                 ├─ (5) STATE 條件 ◀── nimoshake-monitor.sh --conditions (只讀 ns_state、cond/)
                 ├─ (6) EVENT 條件 (新段落計數)
                 ├─ (7) 條件狀態機: 新增 🔴 / 未解除 🟠 / 已解除 🟢；EVENT 保留期、STATE 遲滯
                 ├─ (8) FullCheck 結束通知 (run-manifest.json)
                 └─ (9) 寄信 (SendGrid) → state/.heartbeat (看門狗用)
```

| 檔案 | 說明 |
|---|---|
| `nimoshake-alert.sh` v5.0 | 告警引擎（上圖） |
| `nimoshake-monitor.sh` v5.0 | 報表／`--json`／`--summary`／`--conditions`／`--watch`；所有模式只讀，不寫 `state/` |
| `nimoshake-watchdog.sh` | 看門狗（與 v4.3 相同） |
| `lib/ere.sh` | 規格附錄 A.1 的 ERE 原樣抽出 |
| `lib/common.sh` | 設定載入（`apply_defaults`）、SendGrid、`DRY_RUN_DUMP` |
| `lib/resume-lib.sh` | log／.output／ns_state 共用讀取函式 |
| `lib/ns_state.awk` | 階段狀態機（規格 §5） |
| `lib/batches.awk`、`lib/delta.awk` | L27/L28/L29 批次彙總與 Δ 指標（規格 §6.5；`delta.awk` 另加 `lagTable`、`backlogAnyGrow`、`retryNone3` 等欄位供報表與解除門檻用，計算邏輯不變） |
| `lib/out_scan.awk` | `.output` 掃描（規格 §6.4 (3)） |
| `test/gen-replay.sh`、`test/run-replay-tests.sh` | 合成重播資料產生器與 8 個情境的自動測試 |

---

## 3. 階段狀態機（規格 §5）

| 狀態 | 進入條件 | 說明 |
|---|---|---|
| STARTING | L04 `schema=v2 semantics=` | 剛啟動 |
| PREPARING | L19 `bootstrap table=`（新的一輪） | 清空 `live_runid`、`fin_tables`、`seg_done`；表數＝L19 的表名集合大小 |
| SCANNING | L20 `resume effective scan page limit=` | 全量掃描 |
| CATCH-UP | 本輪 L26 `resume table finish` 湊滿表數；或 STARTING 中看到 L21 且 runid≠live_runid | 追趕全量期間的增量 |
| LIVE | L30 `resume LIVE`；或 STARTING 中看到 L21 且 runid＝live_runid（LIVE 中重啟不會再印 L30） | 即時同步 |
| BLOCKED | L43 `migration BLOCKED` 或 L41 `BLOCKED 未能落盤` | 程式正在退出 |
| STOPPED/\<子類\> | 程序不在（報表顯示用，不寫回 phase） | 子類 PLANNED／FATAL／BLOCKED／CRASH 每輪由 `.output` 尾段與 log 尾段重算 |

- 重讀同一段落結果相同：`fin_tables`、`seg_done`、`run_table_set` 都是集合；階段轉換只依行內容。
- L26 的 runId 先與目前 `runid` 比對再更新：不同（且 runid 已知）的 L26 不收進 `fin_tables`、也不改 `runid`（新一輪的 L18／L22 會先把 runid 換掉，所以不會漏收）。
- 備援（規格 §5.3 末列）：STARTING 超過 900 秒、最新 L18 已超過 120 秒（或本次啟動沒有 L18）、期間有 L27 且沒有 L20 → 視同 L21。
- `absent_runs`／`stopped_since` 由 alert 每輪的存活檢查更新；`stopped_since` 取「log 最後一行時間」與「`.output` mtime」較晚者。
- 首次執行（`ns_state` 不存在）：依 `ls -1tr` 時間序重播全部 log 檔重建 `ns_state`，offset 設成目前大小，不發 EVENT 信。

---

## 4. 監控報表項目（`nimoshake-monitor.sh --human`）

| 區塊 | 內容 | 來源 |
|---|---|---|
| [1] 程式狀態 | 存活／PID／CPU／RSS；停機原因與起算時間；累計啟動次數；最近啟動；心跳距今與最近 3 次心跳類型 | `alive_pid`、`ps`、`.output` L01、ns_state、`E_HB` |
| [2] 同步階段 | phase、runId 前 8 碼、進入時間、本輪最後階段、LIVE 起、BLOCKED 續傳還原狀態 | ns_state |
| [3] 全量進度 | 完成表 x/本輪表數、segment y/(表數×N)；每表 已搬／頁數／總筆數／進度%／速率與預計剩餘（掃描中）或耗時（完成）；整體 % | L23（RECENT）、L26（全檔）、conf `TABLE_TOTALS` |
| [4] 增量 | 最新一批：表數、Σopen、Σspool、ΣgapEvents、captured／applied、最大延遲與表、checkpoint IO；對 600 秒前那批的 apply／capture 速率；applyStall／backlogGrowing／captureIdle／retry3；活躍表 Top 3 | `batches.awk`、`delta.awk` |
| [5] 重試／警告 | 600 秒內 retry 行分 來源／目標／checkpoint 庫 三類與 operation×code Top 3；throttle／conn／buffer／discovery／spool GC／shard trimmed 行數 | L31–L36 |
| [6] 錯誤與品質 | EROR/CRIT、BLOCKED、型別轉換失敗（已知／未知）、未知 WARN 行數；`.output` 尾段摘要 | `E_ERR`、`E_BLK`、L42、`out_scan.awk` |
| [7] 系統資源 | 核心、負載、記憶體、安裝目錄所在磁碟（/home） | /proc、df |
| [8] 設定參數 | 只讀 `nimo-shake.conf` 白名單鍵（`E_CONF_WL`） | conf |
| [告警條件] | 本輪 STATE 條件 | — |

拿掉的舊項目：[4] 效能 avg/P95、[5] 瓶頸判定、[7] HTTP 端點、INSERT/MODIFY/REMOVE 拆分、configuration 行參數、`--totals` 模式、`state/.api_snapshot`。

`--summary`（每封告警信附的「系統狀態判讀」表）改為 7 列：程式狀態、同步階段、全量進度（只在 SCANNING）、增量、心跳、重試、系統資源。

---

## 5. 告警條件總表（42 條，規格 §6.3）

嚴重度只用 high／medium／info；「緊急」寫在 TITLE 字首 `[CRITICAL] `，本封有任一 `[CRITICAL]` 卡片時主旨前也加 `[CRITICAL] `。`ALERT_MIN_SEVERITY=medium`（預設）時 info 只記錄不寄。

### 5.1 EVENT（由 alert 依新段落計數；保留期 `EVENT_HOLD_SEC`=3600 內再出現只依 `REALERT_INTERVAL` 提醒，不重寄新增信）

| ID | 嚴重度 | 觸發 | DETAIL 只放 |
|---|---|---|---|
| MIGRATION_BLOCKED | high [CRITICAL] | `E_BLK`（L43／L41）> 0 | 第 1 個 `table=`、`reason=` 的大寫代碼（不在白名單記 OTHER） |
| FATAL_EXIT | high [CRITICAL] | `.output` 新段落致命行 > 0（且不是重複啟動） | §6.4 (4) 分類代碼：白名單代碼／RETRY_BUDGET_EXHAUSTED \<op\>／MIGRATION_ALREADY_RUNNING／CRASH／CONF_ERROR／OTHER |
| LOG_WRITE_FAILED | high [CRITICAL] | `.output` 出現 `FileLogWriter(` | 行數 |
| ERROR_DETECTED | high | `E_ERR` 命中但 `E_BLK` 不命中 | 行數 |
| WRONG_PATH | high | L10 | — |
| SHARD_TRIMMED | medium [WARN] | L36 | shard 數 |
| BLOCKED_AUTORESUME | medium [WARN] | L14／L16／L39 | 行數、resumeState |
| OWNER_HOST | medium | L13 | — |
| NEW_RUN | medium [WARN] | L19 或 L15 | 行數、runId |
| RULES_CHANGED | medium | L04 的 `rules_sha256` ≠ conf `RULES_SHA256` | — |
| UNKNOWN_WARN | medium [WARN] | `[WARN]` 行但 `E_WARNKNOWN` 不命中 | 行數 |
| OUTPUT_UNKNOWN | medium | `.output` 非白名單行（已排除空行與崩潰附屬行；FATAL_EXIT 同輪時不發） | 行數 |
| WEAK_CONCERN | medium | L08 | — |
| NEW_SOURCE_TABLES | medium | L11 | — |
| LOG_GAP | medium [WARN] | 輪替後找不到上次的 inode | — |
| DUPLICATE_START | medium [WARN] | `.output` 致命行在最後一個 `max process:` 之後，且程序仍存活（此時不發 FATAL_EXIT） | 致命行代碼、PID |
| LIVE_REACHED | info | L30 | runId |

### 5.2 STATE（由 monitor 判定；`cond/<ID>` 存在時改用解除門檻；不再輸出時寄 🟢）

| ID | 嚴重度 | 觸發 | 解除 |
|---|---|---|---|
| PROCESS_DOWN | high | `absent_runs`≥2、停機原因 FATAL／BLOCKED／CRASH、`run_phase` 不是 PREPARING／SCANNING | 存活 |
| FULL_SYNC_INCOMPLETE | high | 同上但 `run_phase` 是 PREPARING／SCANNING | 存活 |
| STOP_LONG | medium [WARN] | 程序不在達 `STOP_WARN_SEC`（43200） | 存活 |
| STOP_TOO_LONG | high [CRITICAL] | 達 `STOP_CRIT_SEC`（72000） | 存活 |
| PLANNED_STOP | info | `absent_runs`≥2 且停機原因 PLANNED | 存活 |
| HEARTBEAT_LOST | high | 存活、啟動超過 900 秒、`HB_AGE` > 120（空值當 RECENT_SEC） | ≤120 |
| HEARTBEAT_LOST_LONG | high [CRITICAL] | 同上 > 600 | 同上 |
| LOG_MISSING | high | log 不可讀（期間凍結其他 log 類條件，`.output` 類仍處理） | 可讀 |
| RETRY_BUDGET_LOW | high | 600 秒內任一 L31 `remaining` < 600 秒 | 600 秒內無 L31 |
| BOOTSTRAP_STUCK | high | 最新 L18 在 120 秒內且 `waited` ≥ 1200 秒 | 120 秒內無 L18 |
| FULL_STALL | high | SCANNING 中，未完成表 60 秒內有 L23，`committedPages` 與 600 秒前相同 | 頁數增加或 L26 |
| APPLY_STALL | high | CATCH-UP／LIVE、最新一批未過期（≤90 秒），`applyStall=1` | `applyStall=0` |
| APPLY_LAG | medium [WARN] | LIVE、距 `live_ts` 與 `start_ts` 皆 > 1800 秒，`maxLagSec` > 300 | < 150 |
| APPLY_LAG_HIGH | high | 同上 > 1800 | < 900 |
| BACKLOG_GROWING | medium [WARN] | LIVE，最近 5 批 ΣgapEvents 連續上升且最新 ≥ 1000 | 5 批內無任何上升 |
| STREAM_RETRY | medium [WARN] | 最近 3 批 retryBusy 都 > 0 | 3 批都 0 |
| STREAM_HEALTH_UNAVAILABLE | medium [WARN] | 最近 3 次心跳都是 L29 | 3 次都 L28 |
| THROTTLE | medium | 600 秒內 `E_L31THR` ≥ 5 | 0 |
| CONN_ERROR | medium | 600 秒內同一 operation `E_L31NET` ≥ 5 | 0 |
| SPOOL_GC_FAIL | medium [WARN] | 600 秒內 L35 ≥ 3 | 0 |
| BUFFER_WAIT | medium [WARN] | 600 秒內同一 owner L32 ≥ 3 | 0 |
| DISCOVERY_WAIT | medium [WARN] | 600 秒內 L34 ≥ 30 | 0 |
| CAST_ISSUE | medium | 3600 秒內 L42 且非 `E_CASTKNOWN` ≥ 1 | 0 |
| LOG_TZ_UNEXPECTED | medium | RECENT 中有前綴不是 UTC（成立時停用所有時間類條件） | 全部 UTC |
| CAPTURE_IDLE | medium [WARN] | CATCH-UP／LIVE、最新一批未過期，Σcaptured 與 `CAPTURE_IDLE_SEC` 前相同 | 增加 |

不告警、只在報表顯示：L05、L12、L17、L21、L33、L37、L44、L46。處置文字全部依規格 §6.6（只引用代碼，不要求貼原始內容）。

### 5.3 「本輪無法判定」≠「已解除」

規格對 APPLY_STALL／APPLY_LAG／BACKLOG_GROWING／CAPTURE_IDLE 說「最新一批過期 (>90 秒) 時本輪不判定」，對 STREAM_RETRY 說「批次不足時 na」，對 LOG_TZ_UNEXPECTED 說「停用時間類條件」。若 monitor 在這些情況下直接不輸出，alert 會把「沒輸出」當成恢復而誤寄 🟢。本版的做法：條件先前已成立（`cond/<ID>` 存在）而本輪資料不足時，monitor 仍輸出該條件，DETAIL 標「本輪無法判定（原因），維持上一輪判定」；只有真正達到解除門檻（或階段已離開該條件適用的階段）才解除。適用：APPLY_STALL、CAPTURE_IDLE、APPLY_LAG、APPLY_LAG_HIGH（最新一批過期或寬限中）、BACKLOG_GROWING（最新一批過期，或批次不足 5 個無法判定「5 批都沒上升」）、STREAM_RETRY（批次 < 3）、STREAM_HEALTH_UNAVAILABLE（心跳 < 3 行）、以及 LOG_TZ_UNEXPECTED 成立期間的全部時間類條件。

FULL_STALL 的解除門檻是「該表頁數增加，或出現 L26」，所以停滯的表名存在 TITLE 裡（alert 會保存）；下一輪逐表判：已完成（L26）→ 該表解除；60 秒內有可判的 L23 → 依頁數判；都沒有 → 該表維持。全部表都解除時才解除整個條件。

---

## 6. 信件與資安（規格 §8）

### 6.1 硬性要求的落實

| 要求 | 做法 |
|---|---|
| 不讀 `configuration:` 行 | 每條讀 log 的管線先 `LC_ALL=C grep -avF ' configuration: '`（`seg()`、`load_recent()`、停機時間取值），或第一個比對式就是附錄 A 的錨定 `E_*`、之後只用 `-o` 取固定欄位；`E_L06` 全程未使用 |
| 所有輸出只放數字與代碼 | 信件／`--json`／`--summary`／`--conditions`／`--status`／report.txt／`state/*`／alert.log 皆由解析後的欄位組成；`reason=`、`err`、`sync failed:` 後的文字一律只取代碼；`keyHash`、主鍵、連線字串不進任何輸出 |
| FullCheck 不放主鍵與資料值 | 信件只有表名、筆數、「表 / 欄位路徑 / 分類」分布 Top 10；拿掉 pk／sk／source_value／actual_value 與 diff 節錄 |
| 原始段落不落地 | 只放變數，`printf '%s\n' "$X" \| awk/grep`；monitor／alert／lib／watchdog／test 全部無 here-string、無 here-doc；`tac` 直接讀檔；`--status` 不建目錄、不寫 alert.log，暫存目錄只放 `ns_state` 與 `cond/` 副本（皆為解析後資料） |
| stderr | 時間一律 gawk `mktime`／`strftime`，全部腳本（含看門狗）的執行指令無 `date -d`（註解有提及該字串）；無把變數當 printf 格式字串 |
| 編碼與 NUL | 全部 `LC_ALL=C grep -a`，比對前 `tr -d '\000'`；offset 只推進到最後一個換行，RECENT 去掉檔尾半行 |
| conf | 只讀 `E_CONF_WL` 白名單鍵（不讀金鑰、連線字串） |
| 金絲雀測試 | `DRY_RUN_DUMP=1` 時把信件主旨／內文／HTML 寫到 `state/dryrun/<epoch>-<pid>-<n>.txt`（0600） |

### 6.2 信件格式

與 v4.3 相同的 HTML 卡片式（純文字＋HTML 雙版本）：🔴 新增／🟠 持續未解除／🟢 已解除，每項附「狀況」與「👉 處理」，🔴🟠 附 7 列「系統狀態判讀」表；頁尾改列 NimoShake 安裝目錄、階段、runId 與快速指令。主旨：`[CRITICAL] 【StarCo OPAPP·正式機】🔴 新增 N 項告警`。

---

## 7. 設定參數（`opapp.conf`，規格 §6.7）

| 動作 | 參數 | 預設／建議值 |
|---|---|---|
| 新增（必填） | `INSTALL_DIR` | `/home/Starco/nimo-shake-starco-1.0.16-sc.20261001c-OPAPP` |
| 改（可由 INSTALL_DIR 推得） | `LOG_FILE`、`OUTPUT_FILE`、`NIMO_CONF` | `$INSTALL_DIR/logs/nimo-shake.log`、`…/nimo-shake.linux.output`、`…/nimo-shake.conf` |
| 新增 | `TOTAL_TABLES` | 23 |
| 新增 | `RULES_SHA256` | `d1a0498d…`（**正式機的值**，不是交付包的 `e3242b3f…`） |
| 改 | `TABLE_TOTALS` | 10-05 那輪 L26 的 committedItems（合計 84,080,398；範本已填） |
| 新增 | `HB_HIGH_SEC`／`HB_CRIT_SEC`／`HB_STARTUP_GRACE_SEC` | 120／600／900 |
| 新增 | `LAG_WARN_SEC`／`LAG_HIGH_SEC`／`LAG_GRACE_SEC` | 300／1800／1800 |
| 新增 | `WINDOW_SEC`／`THROTTLE_MIN`／`CONN_MIN`／`RETRY_REMAINING_MIN_SEC` | 600／5／5／600 |
| 新增 | `STOP_WARN_SEC`／`STOP_CRIT_SEC` | 43200／72000 |
| 新增 | `BOOTSTRAP_STUCK_SEC`／`STALL_SEC` | 1200／600 |
| 新增 | `CAPTURE_IDLE_SEC` | 1800（假設值，待 YC 用 nsmon 校正） |
| 新增 | `RECENT_SEC`／`EVENT_HOLD_SEC` | 3600／3600（程式會自動把 RECENT_SEC 補到 ≥ 最大時間窗+120） |
| 新增 | `DRY_RUN_DUMP` | 0（審查與試跑時設 1） |
| 刪除 | `EXPECT_RUNNING`、`PROC_PATTERN`、`HTTP_FULL_PORT`、`HTTP_INCR_PORT`、`INCR_TAG`、`SLOW_WRITE_MS`、`SLOW_SCAN_MS`、`SCAN_TAIL_LINES`、`HANG_SECONDS`、`STALL_SECONDS`、`FULLCHECK_MODE`、`FULLCHECK_NATIVE_LOG` | 功能已不存在；OPAPP 1.0.16c 包內的 nimo-full-check 即專版（run-manifest.json），不再需要 native 模式 |

門檻全部先用規格建議值，YC 試跑 7 天後依值班需求調整。

---

## 8. 部署與升級（規格 §1.3 #11）

1. 把 `opapp-monitor/` 整個上傳主機（建議 `/opt/starco/opapp-monitor`），`cp opapp.conf.example opapp.conf && chmod 600 opapp.conf`，填 `INSTALL_DIR`、`SENDGRID_API_KEY`、`HOST_ROLE`、`RULES_SHA256`。
2. 確認工具：`awk --version` 必須是 GNU Awk（gawk）；`grep --version` GNU grep；`tac` 存在。
3. **自 v4.3 升級**：`sudo crontab -e` 先把舊的 OPAPP 兩行（引擎、看門狗）註解掉 → 清掉舊 `state/`（`.log_offset`、`.log_inode`、`.output_offset`、`.api_snapshot`、`cond/*`；建議整個 `state/` 換新）。
4. `sudo bash nimoshake-alert.sh opapp.conf`（`DRY_RUN=1`）跑 1 次：首次會重播 log 重建 `ns_state`，不發 EVENT 信。
5. `sudo bash nimoshake-alert.sh --status opapp.conf`：確認 `ns_state` 的 `phase=LIVE`、`runid=7ef5a846…`、`fin_count=23`；`FATAL_EXIT=0`、`OUTPUT_UNKNOWN=0`（正式機 `.output` 現有 3 行不得被當成新事件）。
6. 依 `crontab.example` 裝排程（`sudo crontab -e`，**一律 root**）。
7. 試跑期間 conf 設 `DRY_RUN=1`、`DRY_RUN_DUMP=1`，YC 每天與 nsmon 比對；7 天 0 誤報後改 `DRY_RUN=0`。

---

## 9. 自測結果（2026-10-07，Windows Git Bash：GNU grep 3.0、GNU Awk 5.0.0、bash 5.2）

### 9.1 重播測試（`test/run-replay-tests.sh`）

合成資料：依規格格式字串造一輪完整 10-05 情境（啟動 → PREPARING → SCANNING → CATCH-UP → LIVE，到 now），18,461 行；
L27 718 批 × 23 表、L23 652 行、L25 412 行、L26 23 行、L21 46 行（23 掃描＋23 apply 啟動）。

| 情境 | 預期 | 結果 |
|---|---|---|
| 1 首次執行 | `phase=LIVE`、`fin_count=23`、`seg_count=184`、runId 正確、不發信、cond/ 為空 | PASS |
| 2 穩態 | ALL_CLEAR、不發信 | PASS |
| 3 金絲雀＋程序消失 | MIGRATION_BLOCKED（code=STREAM_GAP）、FATAL_EXIT、UNKNOWN_WARN、SHARD_TRIMMED、BLOCKED_AUTORESUME、THROTTLE、CONN_ERROR、RETRY_BUDGET_LOW、SPOOL_GC_FAIL、BUFFER_WAIT、CAST_ISSUE；ERROR_DETECTED 不成立（兩行 EROR 都是 BLOCKED）；OUTPUT_UNKNOWN 被抑制；`phase=BLOCKED`；發 2 封（告警＋FullCheck）；主旨加 `[CRITICAL]` | PASS |
| 3 金絲雀搜尋 | `grep -rai canary state/ <human/json/summary/conditions/status 擷取>` = 0 筆；主鍵／密碼／金鑰／keyHash／ARN = 0 筆 | PASS（0 筆） |
| 4 absent_runs=2 | PROCESS_DOWN（停機原因 BLOCKED） | PASS |
| 5 重啟自動續傳 | `phase` 回 LIVE（靠 live_runid）、`resume_state=LIVE`、PROCESS_DOWN 🟢 解除、`max process:` 不算致命 | PASS |
| 6 log 輪替 | inode 偵測、補讀舊檔尾巴的 L13 → OWNER_HOST、phase 不變、inode 更新 | PASS |
| 7 EVENT 保留期 | 3600 秒後 EVENT 條件檔清除 | PASS |
| 8 LOG_MISSING | log 不可讀 → LOG_MISSING，恢復後解除 | PASS |

合計 47 項檢查全部 PASS，完整輸出見交付包 `test/replay-result.txt`（2026-10-08 修正後重跑）。

### 9.2 逐條件測試（`test/run-condition-tests.sh`）

重播測試只直接涉及部分 ID，另以極小 log／.output／ns_state／cond 逐條驗證。下表列出每個條件實際做了哪些類別的案例（✓＝有獨立案例；「—」＝沒有，原因見備註）；不是每條都有三類，請依表判讀。2026-10-08 執行：105 項全部 PASS，結果見交付包 `test/cond-result.txt`。

| 條件 | 觸發 | 解除 | 遲滯（門檻附近仍成立） | 維持（資料不足） |
|---|---|---|---|---|
| HEARTBEAT_LOST／_LONG | ✓（300／700 秒；1 小時無心跳） | ✓（心跳回來） | 啟動 900 秒寬限 ✓ | 時區異常 ✓ |
| PROCESS_DOWN／FULL_SYNC_INCOMPLETE／PLANNED_STOP | ✓（FATAL／CRASH／PLANNED；absent_runs=1 不判） | ✓（程序存活） | — | — |
| STOP_LONG／STOP_TOO_LONG | ✓ | ✓（程序存活） | — | — |
| BOOTSTRAP_STUCK | ✓ | ✓（120 秒內無 L18） | — | —（無資料不足情境） |
| FULL_STALL | ✓ | ✓（頁數增加；停滯表完成且無其他 L23；混合） | — | ✓（無可判 L23；舊格式條件檔） |
| APPLY_STALL | ✓ | ✓（applied 增加） | — | ✓（最新一批過期；含 alert 端無假 🟢） |
| APPLY_LAG／_HIGH | ✓（400／2000 秒） | ✓（100 秒 < 150） | ✓（200 秒仍成立） | ✓（寬限中） |
| BACKLOG_GROWING | ✓ | ✓（5 批無上升） | ✓（5 批中 1 批上升仍成立） | ✓（批次 < 5；最新一批過期） |
| CAPTURE_IDLE | ✓ | ✓（captured 增加） | — | ✓（最新一批過期；批次涵蓋不足 na） |
| STREAM_RETRY | ✓ | ✓（3 批 idle） | — | ✓（批次 < 3） |
| STREAM_HEALTH_UNAVAILABLE | ✓ | ✓（3 次 L28） | ✓（3 次中仍有 L29） | ✓（心跳 < 3 行） |
| THROTTLE | ✓（重播情境 3） | ✓（0 行） | ✓（1 行仍成立） | — |
| CONN_ERROR | ✓（重播情境 3） | ✓（0 行） | ✓（1 行仍成立） | — |
| RETRY_BUDGET_LOW | ✓（重播情境 3） | ✓（無 L31） | ✓（remaining 回升但仍有 L31） | — |
| SPOOL_GC_FAIL | ✓（重播情境 3） | ✓（0 行） | ✓（1 行仍成立） | — |
| BUFFER_WAIT | ✓（重播情境 3） | ✓（0 行） | ✓（1 行仍成立） | — |
| DISCOVERY_WAIT | ✓ | ✓（0 行） | ✓（3 行仍成立） | — |
| CAST_ISSUE | ✓（重播情境 3） | ✓（只剩已知的 inside_link_m） | — | — |
| LOG_TZ_UNEXPECTED | ✓ | ✓（全部 UTC） | — | 期間時間類條件維持 ✓ |
| LOG_MISSING | ✓（重播情境 8） | ✓ | — | — |
| 增量條件在新一輪回到 SCANNING | — | ✓（APPLY_LAG／APPLY_STALL／BACKLOG_GROWING／CAPTURE_IDLE 一起解除） | — | — |
| EVENT：MIGRATION_BLOCKED、FATAL_EXIT、UNKNOWN_WARN、SHARD_TRIMMED、BLOCKED_AUTORESUME（重播情境 3）；WRONG_PATH、WEAK_CONCERN、NEW_SOURCE_TABLES、RULES_CHANGED、ERROR_DETECTED、NEW_RUN、LIVE_REACHED、LOG_WRITE_FAILED、OUTPUT_UNKNOWN、DUPLICATE_START、LOG_GAP、OWNER_HOST | ✓ | 保留期到期清除（重播情境 7） | 不適用 | 不適用 |

未有獨立案例的：BOOTSTRAP_STUCK、CAST_ISSUE、THROTTLE 等窗口計數條件的「維持」（這些條件沒有資料不足的情境，窗口內 0 行就是解除）；FATAL_EXIT 以外的 EVENT 分類代碼各值（fatal_code 的六種分類只在 FATAL_EXIT 走 CRASH、DUPLICATE_START 走 MIGRATION_ALREADY_RUNNING 兩條路徑驗過）。

另驗證：`--status` 不建 `state/`、不寫 alert.log；L26 runId 不同時不收進 fin_tables。

### 9.3 規格 §8.3 #1 程式審查（自查）

`grep -nE '<<<|<<[A-Za-z_]|tail -n|head -n'` 於 monitor／alert／watchdog／lib／test：0 筆。`date -d` 在執行指令中 0 筆（註解裡仍有「不用 date -d」的說明文字，純文字搜尋會命中註解）。`cut -c` 只有 4 處，全部用在錨定 ERE 的輸出（`cut -c2-20` 前綴時間、`cut -c8-` E_REASON、`cut -c14-` E_F_CODE）。`configuration` 只出現在 `grep -avF` 過濾、ERE 定義與處置文字。

### 9.4 尚未做的驗證

規格 §8.3 #3 的 YC 重播檔（由 YC 另交）與 #4 正式機 7 天試跑尚未進行；`alive_pid` 需 Linux `/proc`，本機無法實測（見第 10 節）。

---

## 10. 待 YC 驗證／決定的事項（規格附錄 C 與本次新增）

| # | 項目 | 影響 | 驗證方式 |
|---|---|---|---|
| 1 | `alive_pid`（pid 檔 + `/proc/<pid>/exe`）本機無 Linux `/proc`，未實測 | 存活判斷、停機原因規則 4 | 正式機 `ls -l <安裝目錄>/*.pid`、`readlink /proc/<pid>/exe`；試跑第 1 天比對 `--status` 的 `alive=` |
| 2 | 正式機 awk 是否 gawk | `mktime`／`strftime`／`ARGIND`／`RT` | `awk --version`；不是的話 `yum install gawk` |
| 3 | `CAPTURE_IDLE_SEC`=1800 是假設 | CAPTURE_IDLE 誤報率 | YC 用 nsmon 算 10-05～10-06 Σcaptured 連續不增加的最長時間 × 2 |
| 4 | pid 檔實際檔名（`nimo-shake.pid` + `<id>.pid`） | 停機原因 PLANNED 規則 4 | 同 #1 |
| 5 | 失敗啟動後 `logs/` 只剩 1 個檔（照理應有 `.1`） | 首次重播的檔案清單 | 詢問客戶是否清過 `logs/` |
| 6 | 長期運行後 L29 佔心跳比例 | STREAM_HEALTH_UNAVAILABLE 誤報 | 試跑 7 天觀察報表 Σ(open+EOF) 與 reads 趨勢 |
| 7 | 正式機 bash 版本 | here-string 規則背景（本版未使用） | `bash --version` |
| 8 | 每分鐘一輪的耗時 | cron 重疊（有 flock 保護） | 試跑第 1 天看 `cron.log` 時間差；本機（Windows）一輪約 15–40 秒，主要是程序生成開銷，Linux 預期 1–3 秒 |

---

## 11. 與 MyShip（v4.3）的關係

| 環境 | NimoShake | 監控程式 | 位置 |
|---|---|---|---|
| OPAPP 正式機 | 1.0.16c 可續傳版 | **v5.0（本文件）** | `monitor/opapp-resume/`、交付包 `NimoShake監控告警-OPAPP-v5` |
| MyShip | 1.0.14-sc.20260818（`stage=incr` 格式、9340/9341 API） | v4.3 不變 | `monitor/`、交付包 `NimoShake監控告警-MyShip` |

兩套 log 格式零交集，刻意不做單腳本雙模式；MyShip 日後若升級到 1.0.16 系列，再把 v5 複製一份給 MyShip，不反向合併。
