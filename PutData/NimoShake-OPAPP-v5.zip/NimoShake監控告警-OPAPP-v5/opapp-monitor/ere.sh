#!/bin/bash
# =============================================================================
# lib/ere.sh — NimoShake 1.0.16c (OPAPP 可續傳版) log 行的錨定 ERE 定義
# -----------------------------------------------------------------------------
# 來源: YC《NimoShake 1.0.16c（OPAPP）log 格式與監控改版說明》2026-10-06 第 2 版 附錄 A.1，
#       原樣抽出，未改寫。每條 ERE 以前綴 P 開頭 (= §8.1 #1 的寫法 (b): 第一個比對式
#       必為 ${P}\[LEVEL\] <固定訊息>)，之後只用 -o 取固定欄位。
# 使用規則 (§2.6):
#   - 所有 grep/sed/awk/sort 前面加 LC_ALL=C；grep 一律加 -a；比對前 tr -d '\000'
#   - E_L06 (configuration 行，含金鑰) 只准用在 grep -c；任何地方不得讀其內容
#   - 本檔含 UTF-8 中文字 (E_L08/E_L15/E_WARNKNOWN/E_NEWRUN)，必須存成 UTF-8
#   - E_O_*、E_F_* 只用在 nimo-shake.linux.output；E_CONF_WL 只用在 nimo-shake.conf
# 行 ID (L01–L49) 的意義見交付文件附錄 / YC 規格 §3。
# =============================================================================
# shellcheck disable=SC2034

P='^\[[0-9/]{10} [0-9:]{8} [^]]+\] '
E_PFX="${P}\[(FNST|FINE|DEBG|TRAC|INFO|WARN|EROR|CRIT)\]( |$)"
E_L04="${P}\[INFO\] (schema=v2 semantics=|source _id fields=|source_id_basis=)"
E_L05="${P}\[WARN\] ?$"
E_L06="${P}\[INFO\] .* configuration:[ ]"
E_L07="${P}\[INFO\] New session to[ ]"
E_L08="${P}\[WARN\] 資料寫入未達 majority\+journal"
E_L09="${P}\[INFO\] resume full writer:[ ]"
E_L10="${P}\[WARN\] target/checkpoint combination has no resume"
E_L11="${P}\[WARN\] resume uses the manifest.s fixed source tables"
E_L12="${P}\[WARN\] HTTP monitoring (disabled|stopped)"
E_L13="${P}\[WARN\] resume ownerHost differs"
E_L14="${P}\[WARN\] (=+ |BLOCKED reason=)"
E_L15="${P}\[WARN\] 舊版全量未完成"
E_L16="${P}\[WARN\] retrying table BLOCKED table="
E_L17="${P}\[INFO\] resumable all: incr_sync_parallel=false"
E_L18="${P}\[WARN\] capture bootstrap waiting runId="
E_L19="${P}\[INFO\] bootstrap table="
E_L20="${P}\[INFO\] resume effective scan page limit="
E_L21="${P}\[INFO\] MTypeCastConverter loaded"
E_L22="${P}\[INFO\] resume table start runId="
E_L23="${P}\[INFO\] resume health runId="
E_L24="${P}\[INFO\] resume first durable batch runId="
E_L25="${P}\[INFO\] resume segment runId="
E_L26="${P}\[INFO\] resume table finish runId="
E_L27="${P}\[INFO\] resume streams table="
E_L28="${P}\[INFO\] resume checkpoint IO interval="
E_L29="${P}\[WARN\] stream health unavailable[ ]"
E_L30="${P}\[INFO\] resume LIVE runId="
E_L31="${P}\[WARN\] retry operation="
E_L32="${P}\[WARN\] buffer reservation waiting lane="
E_L33="${P}\[WARN\] bounded worker queue waiting"
E_L34="${P}\[WARN\] discovery/replay vector waiting"
E_L35="${P}\[WARN\] spool GC (scan )?failed"
E_L36="${P}\[WARN\] capture (trimmed AFTER|GetRecords trimmed):[ ]"
E_L37="${P}\[WARN\] flush poll before shard BLOCKED failed"
E_L38="${P}\[EROR\] shard BLOCKED persistence failed"
E_L39="${P}\[WARN\] retrying prior shard BLOCKED"
E_L40="${P}\[EROR\] table BLOCKED persistence failed"
E_L41="${P}\[EROR\] BLOCKED [^ ]+ runId="
E_L42="${P}\[WARN\] CastDocument: field\["
E_L43="${P}\[EROR\] migration BLOCKED"
E_L44="${P}\[WARN\] mongo client cleanup did not finish"
E_L45="${P}\[INFO\] stopped by signal$"
E_L46="${P}\[INFO\] sync complete"
E_HB="${P}\[(INFO|WARN)\] (resume checkpoint IO interval=|stream health unavailable )"
E_START="${P}\[INFO\] schema=v2 semantics="
E_ERR="${P}\[(EROR|CRIT)\][ ]"
E_BLK="${P}\[EROR\] (migration BLOCKED|BLOCKED [^ ]+ runId=)"
E_AUTORESUME="${P}\[WARN\] (=+ |BLOCKED reason=|retrying (table|prior shard) BLOCKED )"
E_L25T="${P}\[INFO\] resume segment runId=.* done=true[ ]"
E_L27RETRY="${P}\[INFO\] resume streams table=.* retryStatus=[^ ]*:attempt="
E_L27LAG1M="${P}\[INFO\] resume streams table=.* oldestUnappliedAge=[0-9]+(h|m[0-9])"
E_L31THR="${P}\[WARN\] retry operation=[^ ]+ class=[0-9]+ code=(Throttling(Exception)?|LimitExceededException|ProvisionedThroughputExceededException|RequestLimitExceeded)[ ]"
E_L31NET="${P}\[WARN\] retry operation=[^ ]+ class=[0-9]+ code=(transport-or-unclassified|RequestError|RequestCanceled|RequestTimeout(Exception)?|InternalServerError(Exception)?|ServiceUnavailable(Exception)?|InternalFailure|0|6|7|50|64|89|91|189|262|9001|10107|11600|11602|13435|13436)[ ]"
E_CASTKNOWN="${P}\[WARN\] CastDocument: field\[expiration_date\] castToInt64 failed: collection\[inside_link_m\] .*reason\[TYPE_MISMATCH\]"
E_WARNKNOWN="${P}\[WARN\]( ?$| (資料寫入|target/checkpoint|resume uses|HTTP monitoring|resume ownerHost|=+ |BLOCKED reason=|舊版全量|retrying (table|prior shard) BLOCKED|capture bootstrap|stream health|retry operation=|buffer reservation|bounded worker|discovery/replay|spool GC|capture (trimmed|GetRecords)|flush poll|CastDocument:|mongo client cleanup))"
E_NEWRUN="${P}\[(INFO\] bootstrap table=|WARN\] 舊版全量未完成)"
E_BATCH="${P}\[(INFO\] resume (streams table|checkpoint IO interval)=|WARN\] stream health unavailable )"
E_RUNID="${P}\[(INFO|WARN)\] (capture bootstrap waiting|resume (table start|health|first durable batch|segment|table finish|LIVE)) runId="
E_UTC='^\[[0-9/]{10} [0-9:]{8} UTC\] '
E_REASON='reason=[A-Z][A-Z_]{3,}'
E_CONF_WL='^(sync_mode|full\.(concurrency|read\.concurrency|document\.write\.batch)|qps\.full(\.batch_num)?|incr_sync_parallel|increase\.concurrency|log\.(file|level|buffer)) *='
E_O_START='^max process: [0-9]+$'
E_O_STOP='^stopped by signal$'
E_O_FATAL='^(sync failed: |panic: |fatal error: |SIG[A-Z]+: |Configure file |Conf\.Options check failed|type rules initialization failed|current required configuration version\[|illegal value\[|write pid failed|marshal configuration failed|[a-z.]+\.budget_sec must )'
E_O_WHITE='^(max process: [0-9]+$|stopped by signal$|sync failed: |panic: |fatal error: |SIG[A-Z]+: |FileLogWriter\(|Configure file |Conf\.Options check failed|type rules initialization failed|current required configuration version\[|illegal value\[|write pid failed|marshal configuration failed|[a-z.]+\.budget_sec must )'
E_F_CODE='^sync failed: [A-Z][A-Z_]{3,}'
E_F_BUDGET='^sync failed: .*retry budget exhausted'
E_F_PIDLOCK='^write pid failed'
E_F_CRASH='^(panic: |fatal error: |SIG[A-Z]+: )'
E_F_CONF='^(Configure file |Conf\.Options check failed|type rules initialization failed|current required configuration version\[|illegal value\[|marshal configuration failed|[a-z.]+\.budget_sec must )'
E_F_LOGWRITE='^FileLogWriter\('
FATAL_CODES='CHECKPOINT_INCOMPLETE FINGERPRINT_MISMATCH MIGRATION_ALREADY_RUNNING LEGACY_CHECKPOINT_UNSAFE STREAM_GAP UNSUPPORTED_SCHEMA TARGET_NOT_EMPTY TARGET_NOT_EMPTY_OR_CHANGED TARGET_UUID_MISMATCH TARGET_INDEX_MISSING TARGET_INDEX_MISMATCH TARGET_DDL_MISMATCH MISSING_PRIMARY_KEY PRIMARY_MAPPING_COLLISION LOSSY_PRIMARY_MAPPING INVALID_PRIMARY_SELECTOR INVALID_PRIMARY_KEY_SCHEMA INVALID_PRIMARY_KEY INVALID_NUMERIC_PRIMARY_MAPPING INVALID_CONVERSION_OUTPUT FULL_PAGE_MEMORY_LIMIT'

# out_scan.awk 以 ENVIRON 讀取 (不用 -v: gawk 會改掉 \[ 等跳脫)
export E_O_START E_O_STOP E_O_FATAL E_O_WHITE E_F_LOGWRITE
