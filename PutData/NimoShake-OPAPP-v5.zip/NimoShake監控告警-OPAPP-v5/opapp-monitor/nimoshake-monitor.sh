#!/bin/bash
# =============================================================================
# nimoshake-monitor.sh  v5.0 (OPAPP 1.0.16c 可續傳版專用) — NimoShake 監控解析器
# -----------------------------------------------------------------------------
# 專案 : StarCo Migration  環境: OPAPP 正式機 (nimo-shake-starco-1.0.16-sc.20261001c-OPAPP)
# 依賴 : bash + gawk + grep + tac + (可選) ps  — 無外部套件、不打任何 HTTP 端點
#
# 1.0.16c 與舊版 (1.0.14/1.0.15) 的 log 完全不同，本程式依 YC《log 格式與監控改版說明》
# (2026-10-06 第 2 版) 重寫，只讀 3 個來源:
#   1. <安裝目錄>/logs/nimo-shake.log  — 附錄 A 錨定 ERE 命中的行 (進度/階段/增量/心跳/重試/完整性錯誤)
#   2. <安裝目錄>/nimo-shake.linux.output — 白名單行 (啟動次數/致命退出/log 寫入失敗)
#   3. pid 檔 + /proc/<pid>/exe            — 程序存活
# 階段 (STARTING/PREPARING/SCANNING/CATCH-UP/LIVE/BLOCKED/STOPPED) 由 nimoshake-alert.sh 的
# 狀態機寫在 state/ns_state；本程式「只讀」ns_state 與 state/cond/，不寫 state/ 下任何檔。
#
# 資安 (YC 規格 §8): 所有輸出只放解析後的數字、代碼、表名、時間；不放原始 log 行、
# 不讀 configuration 行 (含金鑰)、不讀 conf 的金鑰/連線字串 (只讀白名單鍵)。
#
# 用法 (目標可為 conf 檔、log 檔、或留空):
#   ./nimoshake-monitor.sh                        # 不帶參數: 自動找腳本旁唯一的 *.conf
#                                                 #   互動終端機下自動持續刷新 (同 --watch)，Ctrl-C 結束
#   ./nimoshake-monitor.sh <opapp.conf>           # 指定 conf (建議: 才有 ns_state 階段與門檻)
#   ./nimoshake-monitor.sh <logfile>              # 直接看某個 log 檔 (無 ns_state，階段顯示 UNKNOWN)
#   ./nimoshake-monitor.sh --human [目標]         # 單次報表
#   ./nimoshake-monitor.sh --json [目標]          # JSON 輸出
#   ./nimoshake-monitor.sh --conditions [目標]    # 告警引擎用的 STATE 條件清單 (EVENT 由 alert 產生)
#   ./nimoshake-monitor.sh --summary [目標]       # 逐面向判讀 (告警信的「系統狀態判讀」表來源)
#   ./nimoshake-monitor.sh --watch [秒] [目標]    # 持續刷新 (預設 10 秒)
#
# --conditions 每行格式: STATE|SEVERITY|ID|COUNT|TITLE|DETAIL   (SEVERITY=high|medium|info)
# --summary    每行格式: status|面向|說明 (status=ok/bad/info/na)
# 環境變數 (由 alert 傳入；手動執行不需要):
#   NS_STATE_FILE  ns_state 路徑 (預設 conf 旁 state/ns_state)
#   NS_COND_DIR    條件狀態目錄 (遲滯用；預設 conf 旁 state/cond；--status 時是暫存副本)
#   NS_NOW         固定「現在」(epoch；重播測試用)   NS_TEST_ALIVE=0|1 存活覆寫 (重播測試用)
# =============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/lib/common.sh" ]; then LIBD="$SCRIPT_DIR/lib"; else LIBD="$SCRIPT_DIR"; fi
# shellcheck source=lib/common.sh
. "$LIBD/common.sh"
# shellcheck source=lib/resume-lib.sh
. "$LIBD/resume-lib.sh"

MODE="human"; MODE_EXPLICIT=0; WATCH_INTERVAL=10; TARGET=""; CONF_PATH=""
while [ $# -gt 0 ]; do
  case "$1" in
    --json)       MODE="json";       MODE_EXPLICIT=1 ;;
    --conditions) MODE="conditions"; MODE_EXPLICIT=1 ;;
    --summary)    MODE="summary";    MODE_EXPLICIT=1 ;;
    --human)      MODE="human";      MODE_EXPLICIT=1 ;;
    --watch)
      MODE="watch"; MODE_EXPLICIT=1
      if [ "${2:-}" ] && printf '%s' "${2:-}" | grep -qE '^[0-9]+$'; then WATCH_INTERVAL="$2"; shift; fi ;;
    -h|--help) grep -E '^#( |$)' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    -*) echo "未知參數: $1" >&2; exit 2 ;;
    *)  TARGET="$1" ;;
  esac
  shift
done
if [ "$MODE_EXPLICIT" -eq 0 ] && [ -t 1 ]; then MODE="watch"; fi

# ---- 目標解析 ----
if [ -z "$TARGET" ]; then
  _confs=$(ls "$SCRIPT_DIR"/*.conf "$SCRIPT_DIR"/*/*.conf 2>/dev/null)
  _n=$(printf '%s\n' "$_confs" | grep -c '\.conf$')
  if [ "$_n" -eq 1 ]; then TARGET="$_confs"
  elif [ "$_n" -eq 0 ]; then echo "用法: $0 [--json|--summary|--conditions|--watch [秒]] [opapp.conf|log檔]" >&2; exit 2
  else echo "找到多個 conf，請指定其中一個:" >&2; printf '%s\n' "$_confs" >&2; exit 2; fi
fi
if printf '%s' "$TARGET" | grep -q '\.conf$'; then
  CONF_PATH="$TARGET"
  [ -f "$CONF_PATH" ] || { echo "找不到 conf 檔: $CONF_PATH" >&2; exit 2; }
  # shellcheck disable=SC1090
  set -a; . "$CONF_PATH"; set +a
  apply_defaults
  STATE_DIR="${STATE_DIR:-$(cd "$(dirname "$CONF_PATH")" && pwd)/state}"
else
  LOG_FILE="$TARGET"
  INSTALL_DIR="${INSTALL_DIR:-$(cd "$(dirname "$TARGET")/.." 2>/dev/null && pwd)}"
  apply_defaults
  STATE_DIR="${STATE_DIR:-}"
fi
[ -z "${LOG_FILE:-}" ] && { echo "conf 缺少 LOG_FILE / INSTALL_DIR" >&2; exit 2; }
NS_STATE_FILE="${NS_STATE_FILE:-${STATE_DIR:+$STATE_DIR/ns_state}}"
NS_COND_DIR="${NS_COND_DIR:-${STATE_DIR:+$STATE_DIR/cond}}"
NOW=$(now_epoch)

# =============================================================================
# 讀取 (每輪各讀一次)
# =============================================================================
LOG_OK=1; [ -r "$LOG_FILE" ] || LOG_OK=0
LOG_BYTES=0; LOG_MTIME=0
if [ "$LOG_OK" -eq 1 ]; then LOG_BYTES=$(wc -c < "$LOG_FILE" | tr -d ' '); LOG_MTIME=$(file_mtime "$LOG_FILE"); fi
RECENT=""; [ "$LOG_OK" -eq 1 ] && load_recent
compute_hb; compute_tz; compute_batches
compute_out_scan 0
STARTS_TOTAL=$(out_starts_total)

ALIVE_PID=$(alive_pid); ALIVE=0; [ -n "$ALIVE_PID" ] && ALIVE=1
PROC_CPU="-"; PROC_MEM_MB="-"; PROC_THREADS="-"; PROC_UPTIME="-"
if [ "$ALIVE" -eq 1 ] && command -v ps >/dev/null 2>&1 && [ -z "${NS_TEST_ALIVE:-}" ]; then
  PROC_CPU=$(ps -p "$ALIVE_PID" -o %cpu= 2>/dev/null | tr -d ' '); : "${PROC_CPU:=-}"
  _rss=$(ps -p "$ALIVE_PID" -o rss= 2>/dev/null | tr -d ' '); [ -n "$_rss" ] && PROC_MEM_MB=$((_rss/1024))
  PROC_THREADS=$(ps -p "$ALIVE_PID" -o nlwp= 2>/dev/null | tr -d ' '); : "${PROC_THREADS:=-}"
  PROC_UPTIME=$(ps -p "$ALIVE_PID" -o etime= 2>/dev/null | tr -d ' '); : "${PROC_UPTIME:=-}"
fi

# ns_state (只讀)
PHASE=$(ns_get phase); : "${PHASE:=UNKNOWN}"
PHASE_SINCE=$(ns_get phase_since); RUN_PHASE=$(ns_get run_phase); RUNID=$(ns_get runid)
LIVE_TS=$(ns_get live_ts); START_TS=$(ns_get start_ts); RUN_TABLES=$(ns_get run_tables)
FIN_TABLES=$(ns_get fin_tables); FIN_COUNT=$(ns_get fin_count); SEG_COUNT=$(ns_get seg_count)
ABSENT_RUNS=$(ns_get absent_runs); STOPPED_SINCE=$(ns_get stopped_since); RESUME_STATE=$(ns_get resume_state)
: "${RUN_TABLES:=0}" "${FIN_COUNT:=0}" "${SEG_COUNT:=0}" "${ABSENT_RUNS:=0}"
[ "$RUN_TABLES" -eq 0 ] && RUN_TABLES_EFF="$TOTAL_TABLES" || RUN_TABLES_EFF="$RUN_TABLES"
HAS_STATE=0; [ -n "$NS_STATE_FILE" ] && [ -f "$NS_STATE_FILE" ] && HAS_STATE=1
# ns_state 沒有 runid 時從 RECENT 取 (§6.5)
[ -z "$RUNID" ] && [ -n "$RECENT" ] && RUNID=$(printf '%s\n' "$RECENT" | LC_ALL=C grep -m1 -aE "$E_RUNID" | LC_ALL=C grep -aoE 'runId=[0-9a-f]{32}' | cut -d= -f2)
RUNID8="${RUNID:0:8}"
# 停機原因 / 顯示用階段
STOP_REASON=""; [ "$ALIVE" -eq 0 ] && STOP_REASON=$(stop_reason)
PHASE_DISP="$PHASE"; [ "$ALIVE" -eq 0 ] && [ "$ABSENT_RUNS" -ge 1 ] && PHASE_DISP="STOPPED/${STOP_REASON}"
# 全量讀取 N (segment 數)
SEG_N=$(conf_wl_get full.read.concurrency); : "${SEG_N:=8}"
[ -n "$RECENT" ] && _sn=$(printf '%s\n' "$RECENT" | LC_ALL=C grep -m1 -aE "$E_L25" | LC_ALL=C grep -aoE 'segment=[0-9]+/[0-9]+' | cut -d/ -f2) && [ -n "${_sn:-}" ] && SEG_N="$_sn"

# 是否在時間窗內 (DELTA)
D_BATCHES=$(dget batches); : "${D_BATCHES:=0}"
D_AGE=$(dget ageSec); D_LAG=$(dget lagSec); D_LAGT=$(dget lagTable); D_GAP=$(dget gapEvents); D_SPOOL=$(dget spool)
D_OPEN=$(dget open); D_CAP=$(dget captured); D_APP=$(dget applied); D_STALL=$(dget applyStall)
D_APS=$(dget applyPerSec); D_CPS=$(dget capturePerSec); D_GROW=$(dget backlogGrowing); D_ANYGROW=$(dget backlogAnyGrow)
D_IDLE=$(dget captureIdle); D_R3=$(dget retry3); D_RN3=$(dget retryNone3); D_READS=$(dget reads); D_WRITES=$(dget writes)
BATCH_FRESH=0; [ "$D_BATCHES" -gt 0 ] && [ "${D_AGE:-999}" -le 90 ] && BATCH_FRESH=1

# =============================================================================
# 全量進度資料 (SCANNING 中: RECENT 的 L23；已完成: fin_tables + L26 最終值)
# =============================================================================
# SCAN_ROWS: table<TAB>items<TAB>pages<TAB>docs<TAB>ts_new<TAB>pages_old<TAB>items_old<TAB>ts_old  (每表一列；old=≥STALL_SEC 前那行)
SCAN_ROWS=""
if [ -n "$RECENT" ]; then
  SCAN_ROWS=$(printf '%s\n' "$RECENT" | LC_ALL=C grep -aE "$E_L23" | TZ=UTC LC_ALL=C "$GAWK" -v stall="$STALL_SEC" '
    function ep(line,  d){d=substr(line,2,19); gsub(/[\/:]/," ",d); return mktime(d)}
    function kv(key,  r){ if (match($0, " " key "=[^ ]+")) return substr($0, RSTART+length(key)+2, RLENGTH-length(key)-2); return "" }
    { t=kv("table"); if (t=="") next; ts=ep($0)
      if (!(t in seen)) { seen[t]=1; order[++n]=t; it[t]=kv("committedItems"); pg[t]=kv("committedPages"); dc[t]=kv("committedDocs"); tn[t]=ts; po[t]=""; io[t]=""; to[t]="" }
      else if (po[t]=="" && tn[t]-ts >= stall) { po[t]=kv("committedPages"); io[t]=kv("committedItems"); to[t]=ts } }
    END { for (i=1;i<=n;i++) { t=order[i]; printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", t, it[t], pg[t], dc[t], tn[t], po[t], io[t], to[t] } }')
fi
# FIN_ROWS: table<TAB>items<TAB>pages<TAB>elapsed_sec<TAB>ts (本輪 L26 最終值；全檔掃描，只在 human/json/summary 做)
FIN_ROWS=""
load_fin_rows() {
  [ "$LOG_OK" -eq 1 ] || return 0
  FIN_ROWS=$(tac "$LOG_FILE" | tr -d '\000' | LC_ALL=C grep -avF ' configuration: ' | LC_ALL=C grep -aE "$E_L26" \
    | TZ=UTC LC_ALL=C "$GAWK" -v rid="$RUNID" "$AWK_DUR_FN"'
    function ep(line,  d){d=substr(line,2,19); gsub(/[\/:]/," ",d); return mktime(d)}
    function kv(key,  r){ if (match($0, " " key "=[^ ]+")) return substr($0, RSTART+length(key)+2, RLENGTH-length(key)-2); return "" }
    { if (rid != "" && kv("runId") != rid) next; t=kv("table"); if (t=="" || (t in seen)) next; seen[t]=1
      printf "%s\t%s\t%s\t%.0f\t%d\n", t, kv("committedItems"), kv("committedPages"), dur(kv("elapsed")), ep($0) }')
}
total_for() { # table -> TABLE_TOTALS 的分母 (沒有印空)
  printf '%s' "$TABLE_TOTALS" | tr ',' '\n' | LC_ALL=C "$GAWK" -F: -v t="$1" '$1==t && $2 ~ /^[0-9]+$/ { print $2; exit }'
}
has_fin() { case ",$FIN_TABLES," in *",$1,"*) return 0;; esac; return 1; }
sum_totals() { printf '%s' "$TABLE_TOTALS" | tr ',' '\n' | LC_ALL=C "$GAWK" -F: '$2 ~ /^[0-9]+$/ {s+=$2} END{print s+0}'; }

# =============================================================================
# STATE 條件 (§6.3；遲滯: $NS_COND_DIR/<ID> 存在時用解除門檻)
# =============================================================================
CONDITIONS=""
held() { [ -n "$NS_COND_DIR" ] && [ -f "$NS_COND_DIR/$1" ]; }
emit_cond() { # TYPE SEV ID COUNT TITLE DETAIL
  local t="$1" sev="$2" id="$3" c="$4" title="$5" detail="$6"
  title=${title//|/／}; detail=${detail//|/／}; title=${title//$'\n'/ }; detail=${detail//$'\n'/ }
  CONDITIONS+="${t}|${sev}|${id}|${c}|${title}|${detail}"$'\n'
}
# 「本輪無法判定」≠「已解除」: 條件已成立 (cond/<ID> 存在) 但本輪資料不足 (最新一批過期、
# 批次不夠、時區異常、沒有可判的 L23…) 時，維持上一輪判定，不讓 alert 誤寄 🟢
cond_prev() { LC_ALL=C "$GAWK" -F '\t' -v k="$2" '$1==k{ sub(/^[^\t]*\t/,""); print; exit }' "$NS_COND_DIR/$1" 2>/dev/null; }
hold_cond() { # ID 原因
  held "$1" || return 0
  local sev title; sev=$(cond_prev "$1" severity); title=$(cond_prev "$1" title)
  emit_cond STATE "${sev:-medium}" "$1" 1 "${title:-$1}" "本輪無法判定 ($2)，維持上一輪判定。"
}
# 時間類條件在 LOG_TZ_UNEXPECTED 成立時停用 (已成立者維持)
TIME_OK=1
if [ "$LOG_OK" -eq 0 ]; then
  emit_cond STATE high LOG_MISSING 1 "log 檔不存在或不可讀" "LOG_FILE 讀不到，監控暫時失效；確認 conf 的 LOG_FILE 與排程是否用 root 執行。"
else
  if [ "${TZ_BAD:-0}" -gt 0 ]; then
    TIME_OK=0
    emit_cond STATE medium LOG_TZ_UNEXPECTED "$TZ_BAD" "log 時間不是 UTC，時間類條件已停用" "最近 ${RECENT_SEC} 秒內有 ${TZ_BAD} 行前綴時區不是 UTC。"
    for _id in HEARTBEAT_LOST HEARTBEAT_LOST_LONG RETRY_BUDGET_LOW BOOTSTRAP_STUCK FULL_STALL APPLY_STALL APPLY_LAG APPLY_LAG_HIGH BACKLOG_GROWING STREAM_RETRY STREAM_HEALTH_UNAVAILABLE THROTTLE CONN_ERROR SPOOL_GC_FAIL BUFFER_WAIT DISCOVERY_WAIT CAST_ISSUE CAPTURE_IDLE; do
      hold_cond "$_id" "log 時區異常，時間類條件停用"
    done
  fi
fi
# ---- #3/#4/#7 程序不在 (absent_runs ≥ 2 才判；由 alert 每輪更新) ----
if [ "$ALIVE" -eq 0 ] && [ "$ABSENT_RUNS" -ge 2 ]; then
  _since=""; [ -n "$STOPPED_SINCE" ] && _since="，停機起算 $(fmt_epoch "$STOPPED_SINCE")"
  case "$STOP_REASON" in
    FATAL|BLOCKED|CRASH)
      if [ "$RUN_PHASE" = "PREPARING" ] || [ "$RUN_PHASE" = "SCANNING" ]; then
        emit_cond STATE high FULL_SYNC_INCOMPLETE 1 "全量掃描中途停止 (停機原因 ${STOP_REASON})" "本輪階段 ${RUN_PHASE}，已完成 ${FIN_COUNT}/${RUN_TABLES_EFF} 張表、segment ${SEG_COUNT}/$((RUN_TABLES_EFF*SEG_N))${_since}。重跑 start.sh 會從各 segment 已落盤的頁接續。"
      else
        emit_cond STATE high PROCESS_DOWN 1 "NimoShake 程序不在 (停機原因 ${STOP_REASON})" "本輪階段 ${RUN_PHASE:-?}，runId ${RUNID8:-?}${_since}。重跑 start.sh 會從 checkpoint 續傳。"
      fi ;;
    PLANNED) emit_cond STATE info PLANNED_STOP 1 "計畫內停機" "程序以 stop.sh 正常停止${_since}。" ;;
  esac
fi
# ---- #5/#6 停機過久 (不論原因) ----
if [ "$ALIVE" -eq 0 ] && [ -n "$STOPPED_SINCE" ]; then
  _sd=$((NOW - STOPPED_SINCE)); [ "$_sd" -lt 0 ] && _sd=0
  [ "$_sd" -ge "$STOP_CRIT_SEC" ] && emit_cond STATE high STOP_TOO_LONG 1 "[CRITICAL] 程式已停止超過 $((STOP_CRIT_SEC/3600)) 小時" "已停機 $(human_secs "$_sd")；超過 23 小時會 STREAM_GAP，只能開新的一輪重搬。"
  [ "$_sd" -ge "$STOP_WARN_SEC" ] && emit_cond STATE medium STOP_LONG 1 "[WARN] 程式已停止超過 $((STOP_WARN_SEC/3600)) 小時" "已停機 $(human_secs "$_sd")，請盡快重跑 start.sh。"
fi
# ---- #8/#9 心跳 ----
if [ "$TIME_OK" -eq 1 ] && [ "$ALIVE" -eq 1 ] && [ -n "$START_TS" ] && [ $((NOW - START_TS)) -gt "$HB_STARTUP_GRACE_SEC" ]; then
  _hb="${HB_AGE:-$RECENT_SEC}"
  [ "$_hb" -gt "$HB_CRIT_SEC" ] && emit_cond STATE high HEARTBEAT_LOST_LONG 1 "[CRITICAL] 心跳中斷超過 $((HB_CRIT_SEC/60)) 分鐘 (程式還在)" "最後一筆心跳距今 $(human_secs "$_hb")；PID ${ALIVE_PID}。"
  [ "$_hb" -gt "$HB_HIGH_SEC" ] && emit_cond STATE high HEARTBEAT_LOST 1 "心跳中斷 (程式還在，log 停了)" "最後一筆心跳距今 $(human_secs "$_hb") (門檻 ${HB_HIGH_SEC} 秒)；PID ${ALIVE_PID}。"
fi
# ---- #13 重試預算 ----
if [ "$TIME_OK" -eq 1 ] && [ -n "$RECENT" ]; then
  _l31w=$(recent_window "$WINDOW_SEC" | LC_ALL=C grep -aE "$E_L31")
  _l31n=$(printf '%s\n' "$_l31w" | LC_ALL=C grep -acE "$E_L31"); : "${_l31n:=0}"
  if [ "$_l31n" -gt 0 ]; then
    _minrem=$(printf '%s\n' "$_l31w" | LC_ALL=C "$GAWK" "$AWK_DUR_FN"'{ if (match($0,/ remaining=[^ ]+/)) { r=dur(substr($0,RSTART+11,RLENGTH-11)); if (m=="" || r<m) m=r } } END{ if (m!="") printf "%.0f", m }')
    if [ -n "$_minrem" ] && { [ "$_minrem" -lt "$RETRY_REMAINING_MIN_SEC" ] || held RETRY_BUDGET_LOW; }; then
      _ops=$(printf '%s\n' "$_l31w" | LC_ALL=C grep -aoE 'operation=[^ ]+' | sort | uniq -c | sort -rn | head -3 | LC_ALL=C "$GAWK" '{printf "%s%s×%s", (NR>1?"、":""), substr($2,11), $1}')
      emit_cond STATE high RETRY_BUDGET_LOW "$_l31n" "重試預算快用完 (剩餘最少 ${_minrem} 秒)" "最近 ${WINDOW_SEC} 秒 ${_l31n} 行重試；operation: ${_ops}。用完程式會退出。"
    fi
  fi
fi
# ---- #14 bootstrap 卡住 ----
if [ "$TIME_OK" -eq 1 ] && [ -n "$RECENT" ]; then
  _l18=$(recent_window 120 | LC_ALL=C grep -m1 -aE "$E_L18")
  if [ -n "$_l18" ]; then
    _waited=$(printf '%s\n' "$_l18" | LC_ALL=C grep -aoE 'waited=[0-9hms.]+' | cut -d= -f2); _ws=$(dur_secs "${_waited:-0}"); _ws=${_ws%.*}
    _ready=$(printf '%s\n' "$_l18" | LC_ALL=C grep -aoE 'ready=[0-9]+/[0-9]+' | cut -d= -f2)
    if [ "${_ws:-0}" -ge "$BOOTSTRAP_STUCK_SEC" ] || held BOOTSTRAP_STUCK; then
      emit_cond STATE high BOOTSTRAP_STUCK 1 "啟動時建立增量起點超過 $((BOOTSTRAP_STUCK_SEC/60)) 分鐘" "capture bootstrap 已等 $(human_secs "${_ws:-0}")，ready=${_ready:-?}。正式機正常約 5 分鐘。"
    fi
  fi
fi
# ---- #15 全量停滯 (SCANNING 中) ----
# 解除門檻是「該表頁數增加，或出現 L26」，所以停滯的表名存在 TITLE 裡 (alert 會保存)；下一輪逐表看:
#   已完成 (fin_tables) → 該表解除；有可判的 L23 → 依頁數判；都沒有 → 該表維持上一輪
if [ "$TIME_OK" -eq 1 ] && [ "$PHASE" = "SCANNING" ]; then
  _stalled=""; _judged=","; _prev_tabs=""
  held FULL_STALL && _prev_tabs=$(cond_prev FULL_STALL title | LC_ALL=C sed -n 's/^.*: //p' | tr ',' ' ')
  while IFS=$'\t' read -r tb it pg dc tn po io to; do
    [ -z "$tb" ] && continue; has_fin "$tb" && continue
    [ $((NOW - tn)) -gt 60 ] && continue            # 60 秒內要有 L23
    [ -z "$po" ] && continue                          # 沒有 ≥STALL_SEC 前的那行 → 無法判
    _judged+="$tb,"
    [ "$pg" = "$po" ] && _stalled+="${tb},"
  done < <(printf '%s\n' "$SCAN_ROWS")
  _held_tabs=""
  for tb in $_prev_tabs; do
    has_fin "$tb" && continue                                   # 出現 L26 → 解除
    case "$_judged" in *",$tb,"*) continue ;; esac               # 本輪已依頁數判過
    _held_tabs+="${tb},"                                        # 沒有可判資料 → 維持
  done
  if [ -n "$_stalled$_held_tabs" ]; then
    _all="${_stalled}${_held_tabs}"; _all="${_all%,}"
    _d="停滯: ${_stalled%,}"; [ -n "$_held_tabs" ] && _d+="；維持上一輪 (60 秒內沒有可判的 resume health 行): ${_held_tabs%,}"
    emit_cond STATE high FULL_STALL 1 "全量掃描停滯 (${STALL_SEC} 秒沒有新頁落盤): ${_all}" "${_d#停滯: ；}。查 AWS Scan 限流與 Atlas 負載。"
  elif held FULL_STALL && [ -z "$_prev_tabs" ] && [ "$_judged" = "," ]; then
    hold_cond FULL_STALL "60 秒內沒有可判的 resume health 行"   # 舊格式條件檔 (TITLE 無表名) 的相容路徑
  fi
fi
# ---- #16 APPLY_STALL / #42 CAPTURE_IDLE (CATCH-UP 或 LIVE；最新一批過期時維持上一輪) ----
if [ "$TIME_OK" -eq 1 ] && { [ "$PHASE" = "CATCH-UP" ] || [ "$PHASE" = "LIVE" ]; }; then
  if [ "$BATCH_FRESH" -eq 1 ]; then
    if [ "$D_STALL" = "1" ] || { held APPLY_STALL && [ "$D_STALL" != "0" ]; }; then
      emit_cond STATE high APPLY_STALL 1 "增量套用停滯 (有待套用事件但 ${STALL_SEC} 秒沒有寫入)" "ΣgapEvents=${D_GAP}、Σspool=${D_SPOOL}、Σapplied=${D_APP} (${STALL_SEC} 秒沒增加)。查 Atlas 是否可寫。"
    fi
    if [ "$D_IDLE" = "1" ] || { held CAPTURE_IDLE && [ "$D_IDLE" != "0" ]; }; then
      emit_cond STATE medium CAPTURE_IDLE 1 "[WARN] 增量抓取 $((CAPTURE_IDLE_SEC/60)) 分鐘沒有任何新事件" "Σcaptured=${D_CAP} 已 ${CAPTURE_IDLE_SEC} 秒沒增加。若來源這段時間確實有寫入，表示 capture 停住。"
    fi
  else
    hold_cond APPLY_STALL "最新一批已過期 ${D_AGE:-?} 秒"; hold_cond CAPTURE_IDLE "最新一批已過期 ${D_AGE:-?} 秒"
  fi
fi
# ---- #17/#18 APPLY_LAG (LIVE，寬限 LAG_GRACE_SEC) / #19 BACKLOG_GROWING ----
if [ "$TIME_OK" -eq 1 ] && [ "$PHASE" = "LIVE" ]; then
  _lag=${D_LAG%.*}; : "${_lag:=0}"
  _past_grace=0; [ -n "$LIVE_TS" ] && [ -n "$START_TS" ] && [ $((NOW - LIVE_TS)) -gt "$LAG_GRACE_SEC" ] && [ $((NOW - START_TS)) -gt "$LAG_GRACE_SEC" ] && _past_grace=1
  if [ "$BATCH_FRESH" -eq 1 ] && [ "$_past_grace" -eq 1 ]; then
    if [ "$_lag" -gt "$LAG_HIGH_SEC" ] || { held APPLY_LAG_HIGH && [ "$_lag" -ge $((LAG_HIGH_SEC/2)) ]; }; then
      emit_cond STATE high APPLY_LAG_HIGH 1 "增量延遲超過 $((LAG_HIGH_SEC/60)) 分鐘" "最新一批最大延遲 ${D_LAG} 秒 (表 ${D_LAGT})，ΣgapEvents=${D_GAP}，applyPerSec=${D_APS}。"
    fi
    if [ "$_lag" -gt "$LAG_WARN_SEC" ] || { held APPLY_LAG && [ "$_lag" -ge $((LAG_WARN_SEC/2)) ]; }; then
      emit_cond STATE medium APPLY_LAG 1 "[WARN] 增量延遲超過 $((LAG_WARN_SEC/60)) 分鐘" "最新一批最大延遲 ${D_LAG} 秒 (表 ${D_LAGT})，ΣgapEvents=${D_GAP}，applyPerSec=${D_APS}。"
    fi
  else
    _why="最新一批已過期 ${D_AGE:-?} 秒"; [ "$_past_grace" -eq 0 ] && _why="LIVE/啟動後 ${LAG_GRACE_SEC} 秒寬限中"
    hold_cond APPLY_LAG_HIGH "$_why"; hold_cond APPLY_LAG "$_why"
  fi
  if [ "$BATCH_FRESH" -eq 1 ]; then
    if [ "$D_GROW" = "1" ] || { held BACKLOG_GROWING && [ "$D_BATCHES" -ge 5 ] && [ "$D_ANYGROW" = "1" ]; }; then
      emit_cond STATE medium BACKLOG_GROWING 1 "[WARN] 增量積壓持續增加" "最近 5 批 ΣgapEvents 連續上升，最新 ${D_GAP}；applyPerSec=${D_APS}、capturePerSec=${D_CPS}。"
    elif [ "$D_BATCHES" -lt 5 ]; then hold_cond BACKLOG_GROWING "取樣窗內批次不足 5 個，無法判定「5 批都沒上升」"; fi
  else hold_cond BACKLOG_GROWING "最新一批已過期 ${D_AGE:-?} 秒"; fi
fi
# ---- #20 STREAM_RETRY / #21 STREAM_HEALTH_UNAVAILABLE (批次/心跳不足 3 個時維持上一輪) ----
if [ "$TIME_OK" -eq 1 ]; then
  if [ "$D_BATCHES" -ge 3 ]; then
    if [ "$D_R3" = "1" ] || { held STREAM_RETRY && [ "$D_RN3" != "1" ]; }; then
      emit_cond STATE medium STREAM_RETRY 1 "[WARN] 有操作持續重試中" "最近 3 批 retryStatus 都不是 idle。看報表「重試」列的 operation 與 code。"
    fi
  else hold_cond STREAM_RETRY "取樣窗內批次不足 3 個"; fi
  _hbn=$(printf '%s' "$HB_LAST3" | tr ',' '\n' | grep -c .)
  if [ "$_hbn" -ge 3 ]; then
    if [ "$HB_LAST3" = "L29,L29,L29" ] || { held STREAM_HEALTH_UNAVAILABLE && [ "$HB_LAST3" != "L28,L28,L28" ]; }; then
      emit_cond STATE medium STREAM_HEALTH_UNAVAILABLE 1 "[WARN] 增量健康統計查不到 (程式仍在跑)" "最近 3 次心跳都是 stream health unavailable；通常是 checkpoint 庫慢或連不上。"
    fi
  else hold_cond STREAM_HEALTH_UNAVAILABLE "取樣窗內心跳不足 3 行"; fi
fi
# ---- #22 THROTTLE / #23 CONN_ERROR (600 秒窗，依 operation 分組) ----
if [ "$TIME_OK" -eq 1 ] && [ -n "$RECENT" ]; then
  _thr=$(recent_window "$WINDOW_SEC" | LC_ALL=C grep -aE "$E_L31THR" | LC_ALL=C grep -aoE 'operation=[^ ]+' | sort | uniq -c | sort -rn)
  _thrn=$(printf '%s\n' "$_thr" | LC_ALL=C "$GAWK" '{s+=$1} END{print s+0}')
  if [ "$_thrn" -ge "$THROTTLE_MIN" ] || { held THROTTLE && [ "$_thrn" -gt 0 ]; }; then
    emit_cond STATE medium THROTTLE "$_thrn" "來源/目標限流 (重試中)" "最近 ${WINDOW_SEC} 秒 ${_thrn} 行: $(printf '%s\n' "$_thr" | head -3 | LC_ALL=C "$GAWK" '{printf "%s%s×%s", (NR>1?"、":""), substr($2,11), $1}')。"
  fi
  _net=$(recent_window "$WINDOW_SEC" | LC_ALL=C grep -aE "$E_L31NET" | LC_ALL=C grep -aoE 'operation=[^ ]+' | sort | uniq -c | sort -rn)
  _netmax=$(printf '%s\n' "$_net" | LC_ALL=C "$GAWK" 'NR==1{print $1+0}'); : "${_netmax:=0}"
  _netn=$(printf '%s\n' "$_net" | LC_ALL=C "$GAWK" '{s+=$1} END{print s+0}')
  if [ "$_netmax" -ge "$CONN_MIN" ] || { held CONN_ERROR && [ "$_netn" -gt 0 ]; }; then
    emit_cond STATE medium CONN_ERROR "$_netn" "連線/逾時/主節點切換 (重試中)" "最近 ${WINDOW_SEC} 秒 ${_netn} 行: $(printf '%s\n' "$_net" | head -3 | LC_ALL=C "$GAWK" '{printf "%s%s×%s", (NR>1?"、":""), substr($2,11), $1}')。"
  fi
fi
# ---- #28 SPOOL_GC_FAIL / #29 BUFFER_WAIT / #30 DISCOVERY_WAIT ----
if [ "$TIME_OK" -eq 1 ] && [ -n "$RECENT" ]; then
  _gc=$(win_count "$E_L35" "$WINDOW_SEC")
  if [ "$_gc" -ge 3 ] || { held SPOOL_GC_FAIL && [ "$_gc" -gt 0 ]; }; then
    emit_cond STATE medium SPOOL_GC_FAIL "$_gc" "[WARN] 暫存事件清理失敗 (checkpoint 庫會持續變大)" "最近 ${WINDOW_SEC} 秒 ${_gc} 行 spool GC failed。查 Atlas。"
  fi
  _bw=$(recent_window "$WINDOW_SEC" | LC_ALL=C grep -aE "$E_L32" | LC_ALL=C "$GAWK" '{o=$0; sub(/.*owner=/,"",o); c[o]++} END{m=0; for(k in c){n++; if(c[k]>m)m=c[k]}; print m+0, n+0}')
  _bwmax=${_bw%% *}; _bwn=${_bw##* }; : "${_bwmax:=0}" "${_bwn:=0}"
  if [ "$_bwmax" -ge 3 ] || { held BUFFER_WAIT && [ "$_bwmax" -gt 0 ]; }; then
    emit_cond STATE medium BUFFER_WAIT "$_bwmax" "[WARN] 記憶體緩衝等待 (背壓)" "最近 ${WINDOW_SEC} 秒同一 owner 最多 ${_bwmax} 行、共 ${_bwn} 個 owner。通常是寫入端慢。"
  fi
  _dw=$(win_count "$E_L34" "$WINDOW_SEC")
  if [ "$_dw" -ge 30 ] || { held DISCOVERY_WAIT && [ "$_dw" -gt 0 ]; }; then
    emit_cond STATE medium DISCOVERY_WAIT "$_dw" "[WARN] discovery 等待持續" "最近 ${WINDOW_SEC} 秒 ${_dw} 行 discovery/replay vector waiting。"
  fi
fi
# ---- #35 CAST_ISSUE (3600 秒窗，排除已知) ----
if [ "$TIME_OK" -eq 1 ] && [ -n "$RECENT" ]; then
  _cast=$(recent_window 3600 | LC_ALL=C grep -aE "$E_L42" | LC_ALL=C grep -avE "$E_CASTKNOWN")
  _castn=$(printf '%s\n' "$_cast" | LC_ALL=C grep -acE "$E_L42"); : "${_castn:=0}"
  if [ "$_castn" -ge 1 ]; then
    _castd=$(printf '%s\n' "$_cast" | LC_ALL=C grep -aoE 'field\[[^]]*\] [A-Za-z0-9]+ failed: collection\[[^]]*\].*reason\[[A-Z_]+\]' \
      | LC_ALL=C sed -E 's/field\[([^]]*)\] [A-Za-z0-9]+ failed: collection\[([^]]*)\].*reason\[([A-Z_]+)\]/\2.\1:\3/' | sort | uniq -c | sort -rn | head -3 \
      | LC_ALL=C "$GAWK" '{printf "%s%s×%s", (NR>1?"、":""), $2, $1}')
    emit_cond STATE medium CAST_ISSUE "$_castn" "新的型別轉換失敗 (原值已保留寫入)" "最近 1 小時 ${_castn} 行 (不含已知的 inside_link_m.expiration_date): ${_castd}。"
  fi
fi
[ -z "$CONDITIONS" ] && emit_cond STATE info ALL_CLEAR 1 "目前運行正常" "階段 ${PHASE_DISP}；無異常條件。"

# =============================================================================
# 輸出
# =============================================================================
print_conditions() { printf '%s' "$CONDITIONS"; }

# 重試統計 (報表/summary 共用): 來源/目標/checkpoint 庫 三類行數 + operation×code Top
retry_stats() { # 印出 "src tgt ckpt total" 與 第二行 Top3
  local w; w=$(recent_window "$WINDOW_SEC" | LC_ALL=C grep -aE "$E_L31")
  printf '%s\n' "$w" | LC_ALL=C "$GAWK" '
    { if (match($0,/ operation=[^ ]+/)) { op=substr($0,RSTART+11,RLENGTH-11); code=""; if (match($0,/ code=[^ ]+/)) code=substr($0,RSTART+6,RLENGTH-6)
        if (op ~ /^(aws|capture)\./) s++; else if (op ~ /^(target\.|mongo\.connect)/) t++; else c++; n++; k[op ":" code]++ } }
    END { printf "%d %d %d %d\n", s+0, t+0, c+0, n+0; for (x in k) printf "%d %s\n", k[x], x }' | { read -r a b c d; echo "$a $b $c $d"; sort -rn | head -3 | LC_ALL=C "$GAWK" '{printf "%s%s×%s", (NR>1?"、":""), $2, $1}'; echo; }
}

print_summary() {
  # 1) 程式狀態
  local hb="${HB_AGE:-}"; local hbdesc; [ -n "$hb" ] && hbdesc="心跳距今 ${hb} 秒" || hbdesc="最近 $((RECENT_SEC/60)) 分鐘沒有心跳"
  local hb_bad=0; [ "$ALIVE" -eq 1 ] && [ -n "$START_TS" ] && [ $((NOW - START_TS)) -gt "$HB_STARTUP_GRACE_SEC" ] && [ "${hb:-$RECENT_SEC}" -gt "$HB_HIGH_SEC" ] && hb_bad=1
  if [ "$ALIVE" -eq 1 ] && [ "$hb_bad" -eq 0 ]; then echo "ok|程式狀態|運行中 (PID ${ALIVE_PID}, CPU ${PROC_CPU}%, RSS ${PROC_MEM_MB}MB)；${hbdesc}"
  elif [ "$ALIVE" -eq 1 ]; then echo "bad|程式狀態|運行中 (PID ${ALIVE_PID}) 但 ${hbdesc} (門檻 ${HB_HIGH_SEC} 秒)"
  else echo "bad|程式狀態|程序不在${STOP_REASON:+ (停機原因 ${STOP_REASON})}${STOPPED_SINCE:+，停機起算 $(fmt_epoch "$STOPPED_SINCE")}"; fi
  # 2) 同步階段
  local ph="${PHASE}${RUNID8:+，runId ${RUNID8}}${PHASE_SINCE:+，進入 $(fmt_epoch "$PHASE_SINCE")}"
  if [ "$ALIVE" -eq 0 ] && [ "$ABSENT_RUNS" -ge 1 ] && [ "$STOP_REASON" != "PLANNED" ]; then echo "bad|同步階段|STOPPED (${STOP_REASON})；停機前 ${ph}。重跑 start.sh 會從 checkpoint 續傳，不會清空目標庫"
  elif [ "$ALIVE" -eq 0 ] && [ "$ABSENT_RUNS" -ge 1 ]; then echo "ok|同步階段|STOPPED (PLANNED，計畫內停機)；停機前 ${ph}"
  else echo "ok|同步階段|${ph}"; fi
  # 3) 全量進度 (只在 SCANNING)
  if [ "$PHASE" = "SCANNING" ]; then
    local moved; moved=$(printf '%s\n' "$SCAN_ROWS" | LC_ALL=C "$GAWK" -F'\t' '{s+=$2} END{print s+0}')
    load_fin_rows; local finsum; finsum=$(printf '%s\n' "$FIN_ROWS" | LC_ALL=C "$GAWK" -F'\t' '{s+=$2} END{print s+0}')
    local tot; tot=$(sum_totals); local pct="-"; [ "$tot" -gt 0 ] && pct=$(LC_ALL=C "$GAWK" -v a=$((moved+finsum)) -v t="$tot" 'BEGIN{p=a*100/t; if(p>100)p=99.9; printf "%.1f%%", p}')
    local st="ok"; printf '%s' "$CONDITIONS" | grep -q '|FULL_STALL|' && st="bad"
    echo "${st}|全量進度|完成表 ${FIN_COUNT}/${RUN_TABLES_EFF}、segment ${SEG_COUNT}/$((RUN_TABLES_EFF*SEG_N))、Σ已搬 $((moved+finsum)) 筆、整體 ${pct}"
  fi
  # 4) 增量
  if [ "$D_BATCHES" -gt 0 ]; then
    local st="ok"; printf '%s' "$CONDITIONS" | grep -qE '\|(APPLY_LAG|APPLY_LAG_HIGH|APPLY_STALL|BACKLOG_GROWING|CAPTURE_IDLE)\|' && st="bad"
    echo "${st}|增量|最新一批 $(fmt_hms $((NOW - D_AGE))) UTC: maxLagSec ${D_LAG} (${D_LAGT})、ΣgapEvents ${D_GAP}、Σspool ${D_SPOOL}、applyPerSec ${D_APS}、capturePerSec ${D_CPS}"
  else
    echo "na|增量|最近 $((RECENT_SEC/60)) 分鐘沒有完整的 streams 批次"
  fi
  # 5) 心跳
  if [ -n "$HB_AGE" ] && [ "$HB_AGE" -le "$HB_HIGH_SEC" ]; then echo "ok|心跳|HB_AGE ${HB_AGE} 秒 (最近 3 次: ${HB_LAST3})"
  elif [ -n "$HB_AGE" ]; then echo "bad|心跳|HB_AGE ${HB_AGE} 秒 > ${HB_HIGH_SEC}"
  else echo "bad|心跳|最近 $((RECENT_SEC/60)) 分鐘沒有心跳行"; fi
  # 6) 重試
  local rs; rs=$(retry_stats); local r1; r1=$(printf '%s\n' "$rs" | head -1); local r2; r2=$(printf '%s\n' "$rs" | sed -n 2p)
  local rsrc rtgt rckpt; rsrc=$(echo "$r1" | cut -d' ' -f1); rtgt=$(echo "$r1" | cut -d' ' -f2); rckpt=$(echo "$r1" | cut -d' ' -f3)
  st="ok"; printf '%s' "$CONDITIONS" | grep -qE '\|(THROTTLE|CONN_ERROR|RETRY_BUDGET_LOW)\|' && st="bad"
  echo "${st}|重試|最近 ${WINDOW_SEC} 秒: 來源 ${rsrc:-0}、目標 ${rtgt:-0}、checkpoint 庫 ${rckpt:-0} 行${r2:+ (${r2})}"
  # 7) 系統資源
  local disk_pct mem_pct load1 cores sys_bad=""
  disk_pct=$(sys_disk_pct); mem_pct=$(sys_mem_pct); load1=$(sys_load1); cores=$(sys_cores)
  [ -n "$disk_pct" ] && [ "$disk_pct" -gt "$DISK_ALERT_PCT" ] 2>/dev/null && sys_bad+="磁碟 ${disk_pct}% 超過門檻 ${DISK_ALERT_PCT}%；"
  [ -n "$mem_pct" ] && [ "$mem_pct" -gt "$MEM_ALERT_PCT" ] 2>/dev/null && sys_bad+="記憶體 ${mem_pct}% 超過門檻 ${MEM_ALERT_PCT}%；"
  if [ -n "$load1" ] && [ "$cores" != "-" ] && LC_ALL=C "$GAWK" -v l="$load1" -v c="$cores" 'BEGIN{exit !(l>c)}'; then sys_bad+="負載 ${load1} 超過核心數 ${cores}；"; fi
  if [ -n "$sys_bad" ]; then echo "bad|系統資源|${sys_bad%；}"; else echo "ok|系統資源|磁碟(/home) ${disk_pct:-?}%、記憶體 ${mem_pct:-?}%、負載 ${load1:-?}/${cores} 核"; fi
}

json_str() { json_escape "$1"; }
print_json() {
  load_fin_rows
  local first=1
  printf '{"version":"5.0","now":%s,"log":{"file":"%s","readable":%s,"bytes":%s,"mtime":%s,"recent_sec":%s},' "$NOW" "$(json_str "$LOG_FILE")" "$LOG_OK" "$LOG_BYTES" "$LOG_MTIME" "$RECENT_SEC"
  printf '"process":{"alive":%s,"pid":"%s","cpu":"%s","mem_mb":"%s","threads":"%s","uptime":"%s","starts_total":%s,"stop_reason":"%s"},' "$ALIVE" "${ALIVE_PID:-}" "$PROC_CPU" "$PROC_MEM_MB" "$PROC_THREADS" "$PROC_UPTIME" "$STARTS_TOTAL" "$STOP_REASON"
  printf '"state":{"has_state":%s,"phase":"%s","phase_since":"%s","run_phase":"%s","runid":"%s","live_ts":"%s","start_ts":"%s","run_tables":%s,"fin_count":%s,"seg_count":%s,"seg_n":%s,"absent_runs":%s,"stopped_since":"%s","resume_state":"%s"},' \
    "$HAS_STATE" "$PHASE" "$PHASE_SINCE" "$RUN_PHASE" "$RUNID" "$LIVE_TS" "$START_TS" "$RUN_TABLES" "$FIN_COUNT" "$SEG_COUNT" "$SEG_N" "$ABSENT_RUNS" "$STOPPED_SINCE" "$RESUME_STATE"
  printf '"heartbeat":{"age_sec":"%s","last3":"%s","tz_bad":%s},' "$HB_AGE" "$HB_LAST3" "${TZ_BAD:-0}"
  printf '"incr":{%s},' "$(printf '%s' "$DELTA" | LC_ALL=C "$GAWK" '{for(i=1;i<=NF;i++){split($i,a,"="); printf "%s\"%s\":\"%s\"", (i>1?",":""), a[1], a[2]}}')"
  printf '"out_scan":{%s},' "$(printf '%s' "$OUT_SCAN" | LC_ALL=C "$GAWK" '{for(i=1;i<=NF;i++){split($i,a,"="); printf "%s\"%s\":\"%s\"", (i>1?",":""), a[1], a[2]}}')"
  printf '"tables":['
  while IFS=$'\t' read -r tb it pg dc tn po io to; do
    [ -z "$tb" ] && continue; [ $first -eq 0 ] && printf ','; first=0
    printf '{"table":"%s","status":"scanning","items":%s,"pages":%s,"docs":%s,"ts":%s,"total":"%s"}' "$(json_str "$tb")" "${it:-0}" "${pg:-0}" "${dc:-0}" "${tn:-0}" "$(total_for "$tb")"
  done < <(printf '%s\n' "$SCAN_ROWS")
  while IFS=$'\t' read -r tb it pg el ts; do
    [ -z "$tb" ] && continue; [ $first -eq 0 ] && printf ','; first=0
    printf '{"table":"%s","status":"finished","items":%s,"pages":%s,"elapsed_sec":%s,"ts":%s,"total":"%s"}' "$(json_str "$tb")" "${it:-0}" "${pg:-0}" "${el:-0}" "${ts:-0}" "$(total_for "$tb")"
  done < <(printf '%s\n' "$FIN_ROWS")
  printf '],"streams":['
  first=1
  while read -r ts n open spool gap cap app lag lagt retry rd wr; do
    [ -z "$ts" ] && continue; [ $first -eq 0 ] && printf ','; first=0
    printf '{"ts":%s,"tables":%s,"open":%s,"spool":%s,"gapEvents":%s,"captured":%s,"applied":%s,"maxLagSec":%s,"maxLagTable":"%s","retryBusy":%s,"reads":%s,"writes":%s}' "$ts" "$n" "$open" "$spool" "$gap" "$cap" "$app" "$lag" "$lagt" "$retry" "$rd" "$wr"
  done < <(printf '%s\n' "$BATCHES" | head -20)
  printf '],"conditions":['
  first=1
  while IFS='|' read -r t sev id c title detail; do
    [ -z "$id" ] && continue; [ $first -eq 0 ] && printf ','; first=0
    printf '{"type":"%s","severity":"%s","id":"%s","count":%s,"title":"%s","detail":"%s"}' "$t" "$sev" "$id" "${c:-0}" "$(json_str "$title")" "$(json_str "$detail")"
  done < <(printf '%s' "$CONDITIONS")
  printf ']}\n'
}

print_human() {
  local B="\033[1m" R="\033[0m" G="\033[32m" Y="\033[33m" RED="\033[31m" DIM="\033[2m"
  echo -e "${B}══════════ NimoShake 監控報表 (OPAPP 1.0.16c 可續傳版 / monitor v5.0) ══════════${R}"
  echo -e "Log 檔案 : $LOG_FILE  ($(( LOG_BYTES/1048576 )) MB, 最後寫入 $(human_secs $((NOW - LOG_MTIME))) 前)"
  echo -e "現在     : $(fmt_epoch "$NOW")   取樣窗: 最近 $((RECENT_SEC/60)) 分鐘 $(printf '%s\n' "$RECENT" | grep -c . ) 行"
  [ "$HAS_STATE" -eq 0 ] && echo -e "${Y}(找不到 ns_state: 階段/本輪表數無法顯示；請用 conf 當目標並先跑過 nimoshake-alert.sh)${R}"
  echo
  echo -e "${B}[1] 程式狀態${R}"
  if [ "$ALIVE" -eq 1 ]; then
    echo -e "   ${G}● 運行中${R}  PID=$ALIVE_PID  CPU=${PROC_CPU}%  RSS=${PROC_MEM_MB}MB  執行緒=${PROC_THREADS}  運行=${PROC_UPTIME}"
  else
    echo -e "   ${RED}● 程序不在${R}  停機原因=${STOP_REASON:-?}${STOPPED_SINCE:+  停機起算=$(fmt_epoch "$STOPPED_SINCE") (已 $(human_secs $((NOW - STOPPED_SINCE))))}"
  fi
  echo -e "   啟動次數 (累計，.output): ${STARTS_TOTAL}   最近啟動: $(fmt_epoch "$START_TS")"
  if [ -n "$HB_AGE" ]; then echo -e "   心跳距今: ${HB_AGE} 秒 (最近 3 次: ${HB_LAST3})"; else echo -e "   ${RED}心跳: 最近 $((RECENT_SEC/60)) 分鐘沒有心跳行${R}"; fi
  echo -e "${B}[2] 同步階段${R}"
  echo -e "   階段: ${PHASE_DISP}   runId: ${RUNID8:-?}   進入: $(fmt_epoch "$PHASE_SINCE")   本輪最後階段: ${RUN_PHASE:-?}"
  [ -n "$LIVE_TS" ] && echo -e "   LIVE 起: $(fmt_epoch "$LIVE_TS") (已 $(human_secs $((NOW - LIVE_TS))))"
  [ -n "$RESUME_STATE" ] && echo -e "   ${Y}上次 BLOCKED 後自動續傳，還原狀態 ${RESUME_STATE}${R}"
  echo -e "${B}[3] 全量進度${R}  (本輪 ${RUN_TABLES_EFF} 張表 × ${SEG_N} segment；完成表 ${FIN_COUNT}/${RUN_TABLES_EFF}，segment ${SEG_COUNT}/$((RUN_TABLES_EFF*SEG_N)))"
  load_fin_rows
  local tot; tot=$(sum_totals); local moved=0 any=0
  printf "   %-30s %-8s %14s %10s %12s %8s %12s\n" "Table" "狀態" "已搬筆數" "頁數" "總筆數" "進度%" "速率/預計"
  while IFS=$'\t' read -r tb it pg dc tn po io to; do
    [ -z "$tb" ] && continue; has_fin "$tb" && continue; any=1; moved=$((moved + it))
    local t; t=$(total_for "$tb"); local pct="-" eta="-" rate="-"
    [ -n "$po" ] && [ "$tn" -gt "$to" ] && rate=$(( (it - io) / (tn - to) ))
    if [ -n "$t" ] && [ "$t" -gt 0 ]; then pct=$(LC_ALL=C "$GAWK" -v a="$it" -v t="$t" 'BEGIN{p=a*100/t; if(p>100)p=99.9; printf "%.1f%%", p}')
      [ "$rate" != "-" ] && [ "$rate" -gt 0 ] && [ "$t" -gt "$it" ] && eta=$(human_secs $(( (t - it) / rate ))); fi
    printf "   %-30s %-8s %14s %10s %12s %8s %12s\n" "$tb" "掃描中" "$it" "$pg" "${t:--}" "$pct" "${rate}/s ${eta}"
  done < <(printf '%s\n' "$SCAN_ROWS")
  local finsum=0
  while IFS=$'\t' read -r tb it pg el ts; do
    [ -z "$tb" ] && continue; any=1; finsum=$((finsum + it))
    printf "   %-30s %-8s %14s %10s %12s %8s %12s\n" "$tb" "完成" "$it" "$pg" "$(total_for "$tb")" "100%" "耗時 $(human_secs "$el")"
  done < <(printf '%s\n' "$FIN_ROWS")
  if [ "$any" -eq 0 ]; then echo -e "   ${DIM}(取樣窗內無 resume health 行、本檔無 resume table finish 行；LIVE 中屬正常)${R}"; fi
  if [ "$tot" -gt 0 ]; then
    echo -e "   ${DIM}整體: 已搬 $((moved+finsum)) / 基準 ${tot} 筆 ($(LC_ALL=C "$GAWK" -v a=$((moved+finsum)) -v t="$tot" 'BEGIN{p=a*100/t; if(p>100)p=100; printf "%.1f%%", p}'))；基準 = conf TABLE_TOTALS (10-05 那輪 L26 的 committedItems)${R}"
  else echo -e "   ${DIM}(進度% 需要 conf 的 TABLE_TOTALS 當分母)${R}"; fi
  echo -e "${B}[4] 增量 (capture → spool → apply)${R}"
  if [ "$D_BATCHES" -gt 0 ]; then
    local fresh=""; [ "$BATCH_FRESH" -eq 0 ] && fresh="${Y}(最新一批已過期 ${D_AGE} 秒，本輪不判增量條件)${R}"
    echo -e "   最新一批 $(fmt_hms $((NOW - D_AGE))) UTC (取樣窗 ${D_BATCHES} 批): 表 $(printf '%s\n' "$BATCHES" | head -1 | cut -d' ' -f2)  open shard ${D_OPEN}  Σspool ${D_SPOOL}  ΣgapEvents(待套用) ${D_GAP}  ${fresh}"
    echo -e "   累計 captured ${D_CAP} / applied ${D_APP}   資料延遲(最老未套用) ${D_LAG} 秒 (表 ${D_LAGT})   checkpoint IO: reads ${D_READS} / writes ${D_WRITES} (每 30 秒)"
    echo -e "   速率 (對 ${STALL_SEC} 秒前那批): apply ${D_APS} 筆/s  capture ${D_CPS} 筆/s   applyStall=${D_STALL} backlogGrowing=${D_GROW} captureIdle=${D_IDLE} retry3=${D_R3}"
    local top; top=$(printf '%s\n' "$RECENT" | LC_ALL=C grep -aE "$E_L27" | TZ=UTC LC_ALL=C "$GAWK" -v now="$NOW" -v w="$STALL_SEC" '
      function ep(line,  d){d=substr(line,2,19); gsub(/[\/:]/," ",d); return mktime(d)}
      function kv(key){ if (match($0, " " key "=[^ ]+")) return substr($0, RSTART+length(key)+2, RLENGTH-length(key)-2); return "" }
      { t=kv("table"); c=kv("captured")+0; ts=ep($0); if (!(t in n)) { n[t]=c; tn[t]=ts } else if (!(t in o) && tn[t]-ts>=w) o[t]=c }
      END { for (t in o) if (n[t]-o[t]>0) printf "%d %s\n", n[t]-o[t], t }' | sort -rn | head -3 | LC_ALL=C "$GAWK" '{printf "%s%s(+%s)", (NR>1?"、":""), $2, $1}')
    [ -n "$top" ] && echo -e "   活躍表 Top 3 (${STALL_SEC} 秒內 Δcaptured): ${top}"
    [ "$PHASE" = "SCANNING" ] && echo -e "   ${DIM}(SCANNING 期間 apply 尚未啟動，applied=0、gapEvents 累積屬正常)${R}"
  else echo -e "   ${DIM}(最近 $((RECENT_SEC/60)) 分鐘沒有完整的 streams 批次)${R}"; fi
  echo -e "${B}[5] 重試 / 警告 (最近 ${WINDOW_SEC} 秒)${R}"
  local rs; rs=$(retry_stats); local r1; r1=$(printf '%s\n' "$rs" | head -1); local r2; r2=$(printf '%s\n' "$rs" | sed -n 2p)
  echo -e "   retry 行: 來源(aws/capture) $(echo "$r1" | cut -d' ' -f1)  目標(target/mongo) $(echo "$r1" | cut -d' ' -f2)  checkpoint 庫(resume/shard/spool) $(echo "$r1" | cut -d' ' -f3)${r2:+   Top: ${r2}}"
  echo -e "   throttle $(win_count "$E_L31THR" "$WINDOW_SEC")  conn/timeout $(win_count "$E_L31NET" "$WINDOW_SEC")  buffer wait $(win_count "$E_L32" "$WINDOW_SEC")  discovery wait $(win_count "$E_L34" "$WINDOW_SEC")  spool GC fail $(win_count "$E_L35" "$WINDOW_SEC")  shard trimmed $(win_count "$E_L36" "$WINDOW_SEC")"
  echo -e "${B}[6] 錯誤與品質 (取樣窗 $((RECENT_SEC/60)) 分鐘)${R}"
  echo -e "   EROR/CRIT 行: $(recent_count "$E_ERR")   migration BLOCKED: $(recent_count "$E_BLK")   型別轉換失敗: $(recent_count "$E_L42") (已知 $(printf '%s\n' "$RECENT" | LC_ALL=C grep -acE "$E_CASTKNOWN"))   未知 WARN: $(printf '%s\n' "$RECENT" | LC_ALL=C grep -aE "${P}\[WARN\]" | LC_ALL=C grep -avcE "$E_WARNKNOWN")"
  echo -e "   .output: 啟動 ${STARTS_TOTAL} 次累計；最後一次啟動之後 $(oget tail_lines) 行、致命行 $(oget tail_fatal)、最後一行 $(oget tail_last)"
  echo -e "${B}[7] 系統資源${R}"
  echo -e "   CPU核心:$(sys_cores)  負載:$(cut -d' ' -f1-3 /proc/loadavg 2>/dev/null || echo -)  記憶體:$(sys_mem_desc)  磁碟(安裝目錄):$(sys_disk_desc)"
  echo -e "${B}[8] 設定參數 (nimo-shake.conf 白名單鍵)${R}"
  echo -e "   $(conf_wl | paste -sd' ' - )"
  echo -e "${B}[告警條件] (STATE 由本程式判定；EVENT 由 alert 引擎依新段落判定)${R}"
  while IFS='|' read -r t sev id c title detail; do
    [ -z "$id" ] && continue
    local mark="  "; case "$sev" in high) mark="${RED}✗${R}";; medium) mark="${Y}▲${R}";; info) mark="${G}✓${R}";; esac
    echo -e "   $mark [$sev/$id] $title ${DIM}$detail${R}"
  done < <(printf '%s' "$CONDITIONS")
  echo -e "${B}════════════════════════════════════════════════════════════════════${R}"
}

case "$MODE" in
  json)       print_json ;;
  conditions) print_conditions ;;
  summary)    print_summary ;;
  human)      print_human ;;
  watch)
    trap 'printf "\n(監控結束)\n"; exit 0' INT TERM
    while true; do
      _out=$(bash "$0" --human "${CONF_PATH:-$LOG_FILE}" 2>&1)
      clear 2>/dev/null || printf '\033[2J\033[H'
      printf '%s\n' "$_out"
      echo "(每 ${WATCH_INTERVAL}s 刷新，Ctrl-C 結束；要單次報表請加 --human)"
      sleep "$WATCH_INTERVAL" & wait $! || true
    done ;;
esac
