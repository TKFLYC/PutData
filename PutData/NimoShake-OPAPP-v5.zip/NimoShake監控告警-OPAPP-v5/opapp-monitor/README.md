# NimoShake 監控 + SendGrid 告警 — OPAPP 1.0.16c 可續傳版專用 (v5.0)

OPAPP 正式機自 2026-10-05 起改跑 YC 專版 `nimo-shake-starco-1.0.16-sc.20261001c-OPAPP`（可續傳版）。
這版的 log 字樣、API、退出行為與 1.0.14/1.0.15 完全不同，舊監控 v4.3 的進度、階段、增量、錯誤告警全部失效。
本資料夾是依 YC《NimoShake 1.0.16c（OPAPP）log 格式與監控改版說明》（2026-10-06 第 2 版，`20261007/交付新達_2026-10-06.zip`）
重寫的 **OPAPP 專用** 監控；**MyShip 仍用 `monitor/` 下的 v4.3，兩套分開維護，不互相合併。**

## 目錄結構

```
monitor/opapp-resume/
├── nimoshake-monitor.sh      # v5.0 監控解析器：報表 / --json / --summary / --conditions / --watch（只讀 ns_state 與 cond/，不寫 state/）
├── nimoshake-alert.sh        # v5.0 告警引擎：階段狀態機 + 條件狀態機 + inode/offset 去重 + 寄信（state/ 唯一寫入者）
├── nimoshake-watchdog.sh     # 看門狗（與 v4.3 相同，獨立程式）
├── lib/
│   ├── ere.sh                # YC 規格附錄 A 的錨定 ERE（原樣抽出）
│   ├── common.sh             # 設定載入 (apply_defaults) / SendGrid 寄信 / DRY_RUN_DUMP
│   ├── resume-lib.sh         # log/.output/ns_state 讀取共用函式（RECENT、心跳、批次、存活、停機原因…）
│   ├── ns_state.awk          # 階段狀態機 (§5)
│   ├── batches.awk           # L27/L28/L29 批次彙總 (§6.5)
│   ├── delta.awk             # Δ 類指標 (applyStall / backlogGrowing / captureIdle / retry3…)
│   └── out_scan.awk          # .output 掃描（啟動/致命/未知/OUT_TAIL）
├── config/opapp.conf.example # 設定範本（新舊鍵見 §6.7）
├── crontab.example
├── test/gen-replay.sh        # 合成可重播 log/.output/FullCheck 產生器（含 --canary 金絲雀階段）
└── README.md
```

## 三個資料來源（不再打任何 HTTP 端點）

| 來源 | 讀什麼 | 用途 |
|---|---|---|
| `<INSTALL_DIR>/logs/nimo-shake.log`（含輪替檔） | 附錄 A 錨定 ERE 命中的行 | 階段、全量進度、增量健康、心跳、重試、完整性錯誤 |
| `<INSTALL_DIR>/nimo-shake.linux.output` | 白名單行 | 啟動次數、致命退出代碼、log 寫入失敗、重複啟動 |
| pid 檔 + `/proc/<pid>/exe` | 程序存活 | 區分存活 / 計畫內停機 / 崩潰 |

## 階段狀態機（state/ns_state，只由 alert 寫）

`STARTING → PREPARING (L19) → SCANNING (L20) → CATCH-UP (23 個 L26) → LIVE (L30)`，另有 `BLOCKED` (L43/L41)；
程序不在時報表顯示 `STOPPED/<PLANNED|FATAL|BLOCKED|CRASH>`（每輪由 .output 與 log 尾巴重算）。
LIVE 中重啟不會再印 L30，靠 `live_runid` 還原；重跑同一段落結果相同（集合式 fin_tables / seg_done）。

## 告警條件（42 條，§6.3）

- **EVENT**（alert 依新段落計數；保留期 `EVENT_HOLD_SEC` 內再出現不重寄）：MIGRATION_BLOCKED、FATAL_EXIT、LOG_WRITE_FAILED、ERROR_DETECTED、WRONG_PATH、SHARD_TRIMMED、BLOCKED_AUTORESUME、OWNER_HOST、NEW_RUN、RULES_CHANGED、UNKNOWN_WARN、OUTPUT_UNKNOWN、WEAK_CONCERN、NEW_SOURCE_TABLES、LOG_GAP、DUPLICATE_START、LIVE_REACHED(info)
- **STATE**（monitor 判定，有解除門檻／遲滯）：PROCESS_DOWN、FULL_SYNC_INCOMPLETE、STOP_LONG、STOP_TOO_LONG、PLANNED_STOP(info)、HEARTBEAT_LOST、HEARTBEAT_LOST_LONG、LOG_MISSING、RETRY_BUDGET_LOW、BOOTSTRAP_STUCK、FULL_STALL、APPLY_STALL、APPLY_LAG、APPLY_LAG_HIGH、BACKLOG_GROWING、STREAM_RETRY、STREAM_HEALTH_UNAVAILABLE、THROTTLE、CONN_ERROR、SPOOL_GC_FAIL、BUFFER_WAIT、DISCOVERY_WAIT、CAST_ISSUE、LOG_TZ_UNEXPECTED、CAPTURE_IDLE
- 嚴重度只用 high / medium / info；「緊急」寫在 TITLE 字首 `[CRITICAL] `，主旨同步加字首。

## 資安（§8，交付前 YC 會審查）

1. 不讀、不解析、不保存含 ` configuration: ` 的行（含 AWS 金鑰與 Mongo 密碼明文）。每條讀 log 的管線先 `grep -avF ' configuration: '`，或第一個比對式就是附錄 A 的錨定 ERE、之後只用 `-o` 取固定欄位。
2. 所有輸出（信件、`--json`、`--summary`、`--status`、report.txt、`state/*`、alert.log、cron.log）只放數字、代碼、表名、欄位路徑、時間；不放原始 log 行、`reason=`/`err` 文字、主鍵、資料值、連線字串。
3. FullCheck 信只放表名、筆數、欄位路徑、分類；不放 pk / sk / source_value / actual_value。
4. 原始段落只放在變數裡用 `printf '%s\n' "$X" | awk/grep` 處理；全部腳本（含看門狗與測試）不用 here-string / here-doc、不寫暫存檔；`tac` 直接讀檔；時間用 gawk `mktime`/`strftime`，不用 `date -d`；全部 `LC_ALL=C grep -a`，比對前 `tr -d '\000'`。
6. 「本輪無法判定」不等於「已解除」：最新一批過期、批次不足、時區異常、沒有可判的 L23 時，已成立的 STATE 條件維持上一輪判定（DETAIL 標明原因），不會誤寄 🟢。
7. `--status` 不建 `state/`、不寫 alert.log；狀態機與條件檔都在暫存副本上運算。
5. `DRY_RUN_DUMP=1`：DRY_RUN 時把信件主旨/內文/HTML 寫到 `state/dryrun/`（0600），供金絲雀測試 `grep -rai canary`。

## 快速開始

```bash
cp config/opapp.conf.example OPAPP/opapp.conf && chmod 600 OPAPP/opapp.conf   # 填 INSTALL_DIR、SENDGRID_API_KEY、HOST_ROLE、RULES_SHA256
sudo bash nimoshake-alert.sh OPAPP/opapp.conf          # 首次: 重播 log 建 ns_state (DRY_RUN=1，不寄)
sudo bash nimoshake-alert.sh --status OPAPP/opapp.conf # 看引擎會怎麼判 (不動狀態檔)
sudo bash nimoshake-monitor.sh OPAPP/opapp.conf        # 持續刷新報表
```

需要 **gawk**（`mktime`/`strftime`/`ARGIND`）、GNU grep、tac。正式機 awk 是否為 gawk 請用 `awk --version` 確認（附錄 C 待驗項）。

## 重播 / 金絲雀測試

```bash
D=/tmp/replay; NOW=$(date +%s)
bash test/gen-replay.sh $D/nimo --now $NOW                 # 第一階段: 完整一輪 (啟動→SCANNING→CATCH-UP→LIVE 到 now)
# conf: INSTALL_DIR=$D/nimo、FULLCHECK_DIR=$D/nimo/fullcheck、DRY_RUN=1、DRY_RUN_DUMP=1
NS_NOW=$NOW NS_TEST_ALIVE=1 bash nimoshake-alert.sh $D/opapp.conf      # 首次: 建基準，ns_state phase=LIVE、fin_count=23
bash test/gen-replay.sh $D/nimo --now $NOW --canary        # 第二階段: 追加金絲雀行 + .output panic + FullCheck 輸出
NS_NOW=$NOW NS_TEST_ALIVE=0 bash nimoshake-alert.sh $D/opapp.conf      # 應產生 MIGRATION_BLOCKED/FATAL_EXIT/… 與 FullCheck 信
grep -rai canary $D/state/   # 必須 0 筆
```

`bash test/run-replay-tests.sh <工作目錄>` 跑 8 個情境（47 項）；`bash test/run-condition-tests.sh <工作目錄>` 逐條件驗證觸發／解除／維持。
`NS_NOW`（固定「現在」）與 `NS_TEST_ALIVE`（存活覆寫）只供重播測試，正式機不要設。

## 重算 TABLE_TOTALS（重搬一輪之後）

```bash
. lib/ere.sh
LC_ALL=C grep -aE "$E_L26" <log> | LC_ALL=C grep -aF "runId=<本輪 runId> " \
  | LC_ALL=C grep -aoE 'table=[^ ]+|committedItems=[0-9]+' | paste -d: - - \
  | LC_ALL=C sed 's/table=//; s/committedItems=//' | paste -sd, -
```
