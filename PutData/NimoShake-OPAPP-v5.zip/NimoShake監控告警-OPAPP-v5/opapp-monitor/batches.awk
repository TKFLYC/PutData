# =============================================================================
# batches.awk — 把 L27 (resume streams) / L28 (checkpoint IO) / L29 (health unavailable)
#               彙總成「一批一列」(YC 規格 §6.5，原樣採用，另加 tables 欄位名註解)
# 輸入: RECENT 中 E_BATCH 篩過的行，順序「新到舊」
# 輸出: 每批 1 列 (新到舊)，欄位:
#   1 ts(epoch)  2 tables  3 open  4 spool  5 gapEvents  6 captured  7 applied
#   8 maxLagSec  9 maxLagTable  10 retryBusy  11 reads  12 writes
# 「一批」= 以 L28 結尾的一組 L27；遇到 L29 就結束目前這批並丟掉更舊的殘行。
# 同一批同一張表重複出現只算第 1 行。最舊一批若被時間窗切掉一半 (表數較少) 就不輸出。
# 需要 gawk (mktime)；呼叫時請加 TZ=UTC LC_ALL=C
# 只輸出數字與表名，不輸出原始行。
# =============================================================================
function dur(s,  t,n,u,g){g=1;if(s~/^-/){g=-1;s=substr(s,2)};t=0;while(match(s,/^[0-9.]+(h|ms|us|µs|ns|m|s)/)){n=substr(s,1,RLENGTH);u=n;sub(/^[0-9.]+/,"",u);n+=0;t+=(u=="h")?n*3600:(u=="m")?n*60:(u=="s")?n:(u=="ms")?n/1e3:(u=="ns")?n/1e9:n/1e6;s=substr(s,RLENGTH+1)};return g*t}
function ep(line,  d){d=substr(line,2,19); gsub(/[\/:]/," ",d); return mktime(d)}
function emit(){ if(inb && n>0) { if(n>maxn) maxn=n; printf "%d %d %d %d %d %d %d %.1f %s %d %d %d\n",ts,n,open,spool,gap,cap,app,maxlag,(maxt==""?"-":maxt),retry,rd,wr }; inb=0 }
/ resume checkpoint IO interval=/ { emit(); inb=1; ts=ep($0); n=open=spool=gap=cap=app=retry=0; maxlag=0; maxt=""; delete seen
  match($0,/reads=[0-9]+/); rd=substr($0,RSTART+6,RLENGTH-6); match($0,/writes=[0-9]+/); wr=substr($0,RSTART+7,RLENGTH-7); next }
/ stream health unavailable / { emit(); next }
inb { delete f; for(i=5;i<=NF;i++){k=$i;sub(/=.*/,"",k);v=$i;sub(/^[^=]*=/,"",v);f[k]=v}
  if (seen[f["table"]]++) next
  n++; open+=f["open"]; spool+=f["spool"]; gap+=f["gapEvents"]; cap+=f["captured"]; app+=f["applied"]
  a=dur(f["oldestUnappliedAge"]); if(a>maxlag){maxlag=a; maxt=f["table"]}
  if(f["retryStatus"]!="idle") retry++ }
END { if (n >= maxn) emit() }
