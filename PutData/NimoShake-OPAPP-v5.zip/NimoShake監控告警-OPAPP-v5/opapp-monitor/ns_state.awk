# =============================================================================
# ns_state.awk — 階段判定狀態機 (YC 規格 §5.2 / §5.3 / §5.4)
# -----------------------------------------------------------------------------
# 用法 (只由 nimoshake-alert.sh 呼叫；monitor 只讀輸出檔):
#   printf '%s\n' "$NEW_SEG" | TZ=UTC LC_ALL=C gawk -v now=$NOW -v alive=0|1 -v stop_ts=<epoch> \
#       -v total_tables=23 -f ns_state.awk <舊 ns_state 檔或 /dev/null> -
# 輸入 1 (ARGV[1]): 舊 ns_state (key<TAB>value，一行一鍵；不存在給 /dev/null)
# 輸入 2 (stdin) : 新段落 (已過濾 configuration 行、已 tr -d '\000'、只含有前綴行)
# 輸出: 新 ns_state (key<TAB>value)，只含數字、表名、代碼、時間 (epoch)。
#
# 鍵 (§5.2):
#   runid live_runid live_ts phase phase_since run_phase run_tables fin_tables seg_done
#   start_ts resume_state absent_runs stopped_since
# 內部輔助鍵 (同檔保存，供下一輪判定):
#   run_table_set   L19 看過的表名集合 (run_tables = 其大小；用集合是為了重讀同段落結果相同)
#   seen_l19 seen_l20 seen_l21  本次啟動內是否已看過 L19/L20/L21
#   last_l18_ts     最新一行 L18 的時間        saw_l27  本次啟動後是否出現過 L27
#   fin_count seg_count  集合大小 (方便 shell 直接讀)
#
# 規則重點:
#   - 階段轉換只依行內容；fin_tables/seg_done/run_table_set 用集合 → 重讀同一段結果相同 (§5.0 #5)
#   - L26 的 runId 必須等於目前 runid 才收 (fin_tables 只收本輪)
#   - 備援: phase 停在 STARTING 超過 900 秒、最新 L18 已超過 120 秒 (或本次啟動沒有 L18)、
#     期間有 L27 且沒有 L20 → 視同 L21 (bootstrap 已結束但沒看到轉換器載入行)
#   - 存活檢查結果不寫回 phase；只更新 absent_runs / stopped_since
# =============================================================================
function ep(line,  d) { d = substr(line, 2, 19); gsub(/[\/:]/, " ", d); return mktime(d) }
function has(set, k) { return (("," set ",") ~ ("," k ",")) }
function add(set, k) { if (k == "") return set; if (has(set, k)) return set; return (set == "" ? k : set "," k) }
function size(set,  n, a) { if (set == "") return 0; n = split(set, a, ","); return n }
function kv(line, key,  r) { if (match(line, " " key "=[^ ]+")) { r = substr(line, RSTART + length(key) + 2, RLENGTH - length(key) - 2); return r } return "" }
function setphase(p, ts) { if (S["phase"] != p) { S["phase"] = p; S["phase_since"] = ts }; if (p != "STARTING") S["run_phase"] = p }
function msg(line) { return substr(line, index(line, "] [") + 2) }   # 去掉時間前綴，從 "[INFO] ..." 開始比對用

BEGIN { FS = "\t"; total_tables += 0 }

# ---- 第 1 個輸入: 舊 ns_state (用 ARGIND 區分，/dev/null 時 FNR==NR 會誤判) ----
ARGIND == 1 { if (NF >= 1) S[$1] = $2; next }

# ---- 第 2 個輸入: 新段落 (每行一筆 log；只用 match/substr，不依賴 FS) ----
{
  line = $0
  m = msg(line)            # "[INFO] resume health runId=..." 這一段
  ts = ep(line)
  rid = ""
  if (match(line, / runId=[0-9a-f]{32}/)) rid = substr(line, RSTART + 7, RLENGTH - 7)

  # L04 第一行 = 啟動標記
  if (m ~ /^\[INFO\] schema=v2 semantics=/) {
    setphase("STARTING", ts); S["start_ts"] = ts
    S["seen_l19"] = 0; S["seen_l20"] = 0; S["seen_l21"] = 0; S["saw_l27"] = 0; S["last_l18_ts"] = ""
    next
  }
  # L19 bootstrap table= → 新的一輪
  if (m ~ /^\[INFO\] bootstrap table=/) {
    if (S["seen_l19"] != 1) {
      setphase("PREPARING", ts); S["run_phase"] = "PREPARING"; S["seen_l19"] = 1
      S["run_table_set"] = ""; S["live_runid"] = ""; S["live_ts"] = ""; S["fin_tables"] = ""; S["seg_done"] = ""
    }
    S["run_table_set"] = add(S["run_table_set"], kv(line, "table"))
    next
  }
  # L18 capture bootstrap waiting
  if (m ~ /^\[WARN\] capture bootstrap waiting runId=/) { if (rid != "") S["runid"] = rid; S["last_l18_ts"] = ts; next }
  # L14 第二行 BLOCKED reason= ... resumeState=X
  if (m ~ /^\[WARN\] BLOCKED reason=/) { if (match(line, / resumeState=[A-Z_]+/)) S["resume_state"] = substr(line, RSTART + 13, RLENGTH - 13); next }
  # L20 進入 SCANNING
  if (m ~ /^\[INFO\] resume effective scan page limit=/) { setphase("SCANNING", ts); S["seen_l20"] = 1; next }
  # L22 / L23 / L24
  if (m ~ /^\[INFO\] resume (table start|health|first durable batch) runId=/) { if (rid != "") S["runid"] = rid; next }
  # L25 segment
  if (m ~ /^\[INFO\] resume segment runId=/) {
    if (rid != "") S["runid"] = rid
    if (line ~ / done=true /) { seg = kv(line, "segment"); sub(/\/.*/, "", seg); S["seg_done"] = add(S["seg_done"], kv(line, "table") ":" seg) }
    next
  }
  # L26 table finish
  if (m ~ /^\[INFO\] resume table finish runId=/) {
    # 先比對再更新: runId 與目前 runid 不同 (且 runid 已知) 的 L26 不收進 fin_tables、也不改 runid
    if (S["runid"] == "" || rid == S["runid"]) {
      if (rid != "") S["runid"] = rid
      S["fin_tables"] = add(S["fin_tables"], kv(line, "table"))
      rt = size(S["run_table_set"]); if (rt == 0) rt = total_tables
      if (rt > 0 && size(S["fin_tables"]) >= rt) setphase("CATCH-UP", ts)
    }
    next
  }
  # L21 轉換器載入: 在 STARTING 時 = apply 已啟動
  if (m ~ /^\[INFO\] MTypeCastConverter loaded/) {
    S["seen_l21"] = 1
    if (S["phase"] == "STARTING") { if (S["runid"] != "" && S["runid"] == S["live_runid"]) setphase("LIVE", ts); else setphase("CATCH-UP", ts) }
    next
  }
  # L30 進入 LIVE
  if (m ~ /^\[INFO\] resume LIVE runId=/) { if (rid != "") S["runid"] = rid; setphase("LIVE", ts); S["live_runid"] = S["runid"]; S["live_ts"] = ts; next }
  # L43 / L41 BLOCKED
  if (m ~ /^\[EROR\] (migration BLOCKED|BLOCKED [^ ]+ runId=)/) { if (rid != "") S["runid"] = rid; setphase("BLOCKED", ts); next }
  # L27 (記錄「本次啟動後有 L27」，供備援規則)
  if (m ~ /^\[INFO\] resume streams table=/) { S["saw_l27"] = 1; next }
  # 其他行不改階段
}

END {
  # 備援: STARTING 太久、bootstrap 已結束、有 L27 且沒有 L20 → 視同 L21
  if (S["phase"] == "STARTING" && S["phase_since"] != "" && now - S["phase_since"] > 900 && S["saw_l27"] == 1 && S["seen_l20"] != 1 \
      && (S["last_l18_ts"] == "" || now - S["last_l18_ts"] > 120)) {
    if (S["runid"] != "" && S["runid"] == S["live_runid"]) setphase("LIVE", now); else setphase("CATCH-UP", now)
  }
  # 存活檢查 → absent_runs / stopped_since
  if (alive == 1) { S["absent_runs"] = 0; S["stopped_since"] = "" }
  else {
    S["absent_runs"] = S["absent_runs"] + 1
    if (S["absent_runs"] == 1) S["stopped_since"] = stop_ts
  }
  S["run_tables"] = size(S["run_table_set"])
  S["fin_count"] = size(S["fin_tables"]); S["seg_count"] = size(S["seg_done"])
  if (S["phase"] == "") S["phase"] = "UNKNOWN"
  n = asorti(S, keys)
  for (i = 1; i <= n; i++) printf "%s\t%s\n", keys[i], S[keys[i]]
}
