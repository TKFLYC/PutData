# =============================================================================
# out_scan.awk — 掃描 nimo-shake.linux.output (YC 規格 §6.4 (3)，原樣採用)
# 輸入: 整份 .output 的「完整行」(head -c OUT_DONE)；-v from=<上次 offset>
# ERE 由 ENVIRON 讀 (E_O_START / E_O_STOP / E_O_FATAL / E_O_WHITE / E_F_LOGWRITE)，
#   不用 -v 傳: gawk 會改掉 \[ 等跳脫。
# 輸出一行:
#   starts     新段落中的啟動行數 (max process:)
#   fatal      新段落中的致命行數
#   logwrite   新段落中的 FileLogWriter( 行數 (log 寫不進去)
#   unknown    新段落中非白名單且非崩潰附屬行、非空行 的行數
#   tail_lines 最後一個 max process: 之後的行數 (OUT_TAIL；每輪整份重算，停機原因用)
#   tail_fatal OUT_TAIL 中的致命行數
#   tail_last  OUT_TAIL 最後一行是 stop(stopped by signal) / other / -
# 只輸出計數與代碼，不輸出原始行。
# =============================================================================
{ s = pos; pos += length($0) + 1; new = (s >= from) }
$0 == "" { next }
$0 ~ ENVIRON["E_O_START"] { if (new) starts++; crash = 0; tn = 0; tf = 0; tlast = "-"; next }
{ tn++; tlast = ($0 ~ ENVIRON["E_O_STOP"]) ? "stop" : "other" }
$0 ~ ENVIRON["E_O_FATAL"]    { crash = 1; tf++; if (new) fatal++; next }
$0 ~ ENVIRON["E_F_LOGWRITE"] { if (new) logw++; next }
new && !crash && $0 !~ ENVIRON["E_O_WHITE"] { unk++ }
END { printf "starts=%d fatal=%d logwrite=%d unknown=%d tail_lines=%d tail_fatal=%d tail_last=%s\n", starts, fatal, logw, unk, tn, tf, (tlast == "" ? "-" : tlast) }
