#!/bin/bash
# =============================================================================
# nimoshake-alert.sh  v5.0 (OPAPP 1.0.16c 可續傳版專用) — NimoShake 監控告警引擎 (SendGrid)
# -----------------------------------------------------------------------------
# 設計給「每分鐘一次 cron」使用，重點在「不亂寄、不重複寄、不漏寄」:
#   1. 狀態機 (本程式是 state/ 的唯一寫入者):
#        - 階段狀態機 (YC 規格 §5): 依新段落的 log 行更新 state/ns_state
#          (STARTING/PREPARING/SCANNING/CATCH-UP/LIVE/BLOCKED + absent_runs/stopped_since)
#        - 條件狀態機: 新增(NEW 🔴) / 未解除(FIRING 🟠) / 已解除(RESOLVED 🟢)
#   2. 新段落: log 以 inode+offset 跨輪替讀取、只讀到最後一個完整行 (§6.4 (1))；
#      .output 另有自己的 offset 與首次基準 (§6.4 (3))
#   3. EVENT 條件由本程式依新段落計數產生 (§6.2)，有保留期 EVENT_HOLD_SEC；
#      STATE 條件由 nimoshake-monitor.sh --conditions 判定，有遲滯 (解除門檻)
#   4. 批次寄信、冷卻、單次上限、嚴重度門檻、DRY_RUN=1 預設、寄失敗補送
#   5. FullCheck 結束通知 (專版 run-manifest.json)；信件只放表名/筆數/欄位路徑/分類，
#      不放主鍵與資料值 (§8.1 #3)
#   6. 資安 (§8): 不讀 configuration 行；所有輸出 (信件/alert.log/狀態檔/stdout) 只放
#      數字與代碼；原始段落只在變數裡用 printf | awk/grep 處理，不落暫存檔、不用 here-string
#
# 用法:
#   ./nimoshake-alert.sh <opapp.conf>
#   ./nimoshake-alert.sh --send   <opapp.conf>  # 覆寫成真的寄 (DRY_RUN=0)
#   ./nimoshake-alert.sh --dry    <opapp.conf>  # 強制 dry-run
#   ./nimoshake-alert.sh --status <opapp.conf>  # 只印目前狀態，不動狀態檔、不寄信
# 升級自 v4.3 (§1.3 #11): 停 cron → 清 state/.log_offset .log_inode .output_offset .api_snapshot cond/*
#   (或整個 state/ 換新) → DRY_RUN=1 跑 1 次 (首次重播 log 建 ns_state，不發 EVENT 信) →
#   確認 ns_state 的 phase / runid → 恢復 cron
# =============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/lib/common.sh" ]; then LIBD="$SCRIPT_DIR/lib"; else LIBD="$SCRIPT_DIR"; fi
# shellcheck source=lib/common.sh
. "$LIBD/common.sh"
# shellcheck source=lib/resume-lib.sh
. "$LIBD/resume-lib.sh"
MONITOR="$SCRIPT_DIR/nimoshake-monitor.sh"

FORCE=""; STATUS_ONLY=0; CONF=""
while [ $# -gt 0 ]; do
  case "$1" in
    --send)   FORCE="send" ;;
    --dry)    FORCE="dry" ;;
    --status) STATUS_ONLY=1 ;;
    -h|--help) grep -E '^#( |$)' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    -*) echo "未知參數: $1" >&2; exit 2 ;;
    *)  CONF="$1" ;;
  esac
  shift
done
load_config "$CONF" || exit 1
[ "$FORCE" = "send" ] && DRY_RUN=0
[ "$FORCE" = "dry" ]  && DRY_RUN=1

COND_DIR="$STATE_DIR/cond"
NS_STATE_FILE="$STATE_DIR/ns_state"
LOG_OFF_FILE="$STATE_DIR/.log_offset"; LOG_INO_FILE="$STATE_DIR/.log_inode"; OUT_OFF_FILE="$STATE_DIR/.output_offset"
LASTMAIL_FILE="$STATE_DIR/.last_mail"

# --status 承諾「不動狀態檔」: 不建目錄、不寫 alert.log；狀態機與條件檔都在暫存副本上運算，離開時清掉
if [ "$STATUS_ONLY" -eq 1 ]; then
  TMP_ST=$(mktemp -d); chmod 700 "$TMP_ST"
  mkdir -p "$TMP_ST/cond"; [ -d "$COND_DIR" ] && cp -a "$COND_DIR/." "$TMP_ST/cond/" 2>/dev/null
  [ -f "$NS_STATE_FILE" ] && cp -a "$NS_STATE_FILE" "$TMP_ST/ns_state"
  COND_DIR="$TMP_ST/cond"; NS_STATE_FILE="$TMP_ST/ns_state"
  NS_NO_FILE_LOG=1   # log_line 只印 stderr
  trap 'rm -rf "$TMP_ST"' EXIT
else
  mkdir -p "$COND_DIR" 2>/dev/null || true
  chmod 700 "$STATE_DIR" 2>/dev/null || true
fi
NOW=$(now_epoch)
sev_rank() { case "$1" in high) echo 4;; medium) echo 3;; low) echo 2;; info) echo 1;; *) echo 0;; esac; }
MIN_RANK=$(sev_rank "$ALERT_MIN_SEVERITY")
write_atomic() { # file content  (先寫 tmp 再 mv；0600)
  ( umask 077; printf '%s\n' "$2" > "$1.tmp" ) && mv -f "$1.tmp" "$1"
}

# =============================================================================
# (1) log 新段落: 跨輪替讀取，只讀到最後一個完整行 (§6.4 (1))
# =============================================================================
FREEZE=0; LOG_GAP=0; FIRST_RUN=0; NEW_SEG=""; NEW_OFFSET=""; NEW_INO=""; LOG_SIZE=0; LOG_PLEN=0
REPLAY_FILES=""   # 首次執行要重播的檔案清單 (舊到新，最後是目前檔)
if [ ! -r "$LOG_FILE" ]; then
  FREEZE=1
  log_line "WARN: [$ENV_NAME] LOG_FILE 讀不到 ($LOG_FILE)，本輪凍結既有告警、只處理 .output"
else
  LOG_DIR=$(dirname "$LOG_FILE"); NEW_INO=$(stat -c %i "$LOG_FILE"); LOG_SIZE=$(stat -c %s "$LOG_FILE")
  PREV_INO=$(cat "$LOG_INO_FILE" 2>/dev/null | tr -dc '0-9'); PREV_OFFSET=$(cat "$LOG_OFF_FILE" 2>/dev/null | tr -dc '0-9')
  if [ ! -f "$NS_STATE_FILE" ] || [ -z "$PREV_INO" ] || [ -z "$PREV_OFFSET" ]; then
    FIRST_RUN=1; NEW_OFFSET=$(done_bytes "$LOG_FILE" 0 "$LOG_SIZE")
    # 首次: 依 ls -1tr 的時間序重播全部 log 檔 (含輪替檔) 重建 ns_state，不發 EVENT 信
    REPLAY_FILES=$(ls -1tr "$LOG_DIR"/nimo-shake.log.* 2>/dev/null | LC_ALL=C grep -av "^$LOG_FILE$"; printf '%s\n' "$LOG_FILE")
    log_line "INFO: [$ENV_NAME] 首次執行 (或 state/ 已清): 重播 $(printf '%s\n' "$REPLAY_FILES" | grep -c .) 個 log 檔重建 ns_state，offset=$NEW_OFFSET；本次不對歷史事件發信"
  elif [ "$NEW_INO" = "$PREV_INO" ]; then
    [ "$LOG_SIZE" -lt "$PREV_OFFSET" ] && PREV_OFFSET=0
    N=$(done_bytes "$LOG_FILE" "$PREV_OFFSET" "$LOG_SIZE")
    [ "$N" -gt 0 ] && NEW_SEG=$(seg "$LOG_FILE" "$PREV_OFFSET" "$N"); NEW_OFFSET=$((PREV_OFFSET + N))
  else   # 輪替過: 先讀舊檔 (以 inode 找) 的尾巴，再讀之後的輪替檔，最後從目前檔 0 讀起
    OLD=$(find "$LOG_DIR" -maxdepth 1 -name 'nimo-shake.log.*' -inum "$PREV_INO" 2>/dev/null | head -1)
    if [ -n "$OLD" ]; then
      NEW_SEG=$( seg "$OLD" "$PREV_OFFSET" $(( $(stat -c %s "$OLD") - PREV_OFFSET ))
                 for f in $(ls -1tr "$LOG_DIR"/nimo-shake.log.* | LC_ALL=C "$GAWK" -v o="$OLD" 'f; $0 == o {f = 1}'); do
                   seg "$f" 0 "$(stat -c %s "$f")"; done )
      log_line "INFO: [$ENV_NAME] log 已輪替 (inode $PREV_INO → $NEW_INO)，已補讀舊檔尾巴"
    else
      LOG_GAP=1
      log_line "WARN: [$ENV_NAME] log 已輪替但找不到上次讀的 inode $PREV_INO (logs/ 被清?)，中間事件可能漏看 (LOG_GAP)"
    fi
    N=$(done_bytes "$LOG_FILE" 0 "$LOG_SIZE")
    NEW_SEG=$(printf '%s\n%s' "$NEW_SEG" "$(seg "$LOG_FILE" 0 "$N")" | LC_ALL=C grep -aE "$P"); NEW_OFFSET=$N
  fi
  LOG_PLEN=$((LOG_SIZE - NEW_OFFSET))
fi
seg_count() { [ -z "$NEW_SEG" ] && { echo 0; return; }; printf '%s\n' "$NEW_SEG" | LC_ALL=C grep -acE "$1"; }

# =============================================================================
# (2) .output 新段落 (§6.4 (3)): 首次只建基準、只讀完整行、崩潰附屬行不算未知
# =============================================================================
if [ -f "$OUT_OFF_FILE" ]; then PREV_OUT_OFFSET=$(cat "$OUT_OFF_FILE" | tr -dc '0-9'); OUT_FIRST=0; else PREV_OUT_OFFSET=""; OUT_FIRST=1; fi
compute_out_scan 0 >/dev/null   # 先取 OUT_DONE
[ -z "$PREV_OUT_OFFSET" ] && PREV_OUT_OFFSET=$OUT_DONE
compute_out_scan "$PREV_OUT_OFFSET"
FATAL_LINE=""
if [ "$OUT_DONE" -gt "$PREV_OUT_OFFSET" ] && [ "$(oget fatal)" -gt 0 ]; then
  FATAL_LINE=$(head -c "$OUT_DONE" "$OUTPUT_FILE" | tail -c +$((PREV_OUT_OFFSET+1)) | tr -d '\000' | LC_ALL=C grep -aE "$E_O_FATAL" | tail -1)
fi

# =============================================================================
# (3) 存活 + 停機起算時間 (log 最後一行的前綴時間 與 .output mtime 取較晚者)
# =============================================================================
ALIVE_PID=$(alive_pid); ALIVE=0; [ -n "$ALIVE_PID" ] && ALIVE=1
STOP_TS=""
if [ "$ALIVE" -eq 0 ]; then
  _lt=""; [ "$FREEZE" -eq 0 ] && _lt=$(tac "$LOG_FILE" | tr -d '\000' | LC_ALL=C grep -avF ' configuration: ' | LC_ALL=C grep -m1 -aE "$P" | cut -c2-20 | tr -d '\n')
  _le=$(prefix_epoch "$_lt"); _om=0; [ -n "$OUTPUT_FILE" ] && [ -f "$OUTPUT_FILE" ] && _om=$(file_mtime "$OUTPUT_FILE")
  STOP_TS="${_le:-0}"; [ "$_om" -gt "$STOP_TS" ] && STOP_TS="$_om"; [ "$STOP_TS" -eq 0 ] && STOP_TS="$NOW"
fi

# =============================================================================
# (4) 階段狀態機 → ns_state (先寫 tmp 再 mv；--status 時寫的是暫存副本)
# =============================================================================
OLD_STATE="$NS_STATE_FILE"; [ -f "$OLD_STATE" ] || OLD_STATE=/dev/null
if [ "$FIRST_RUN" -eq 1 ]; then
  NEW_STATE=$( while IFS= read -r f; do [ -r "$f" ] && seg "$f" 0 "$(stat -c %s "$f")"; done < <(printf '%s\n' "$REPLAY_FILES") \
    | TZ=UTC LC_ALL=C "$GAWK" -v now="$NOW" -v alive="$ALIVE" -v stop_ts="${STOP_TS:-$NOW}" -v total_tables="$TOTAL_TABLES" -f "$AWK_NSSTATE" /dev/null - )
else
  NEW_STATE=$( printf '%s\n' "$NEW_SEG" | LC_ALL=C grep -aE "$P" \
    | TZ=UTC LC_ALL=C "$GAWK" -v now="$NOW" -v alive="$ALIVE" -v stop_ts="${STOP_TS:-$NOW}" -v total_tables="$TOTAL_TABLES" -f "$AWK_NSSTATE" "$OLD_STATE" - )
fi
[ -n "$NEW_STATE" ] && write_atomic "$NS_STATE_FILE" "$NEW_STATE"
PHASE=$(ns_get phase); RUNID=$(ns_get runid); ABSENT_RUNS=$(ns_get absent_runs); : "${ABSENT_RUNS:=0}"

# =============================================================================
# (5) STATE 條件 (monitor --conditions，只讀 ns_state 與 cond/)
# =============================================================================
CONDITIONS=$(NS_STATE_FILE="$NS_STATE_FILE" NS_COND_DIR="$COND_DIR" NS_NOW="$NOW" STATE_DIR="$STATE_DIR" \
             bash "$MONITOR" --conditions "$CONF" 2>/dev/null) || true
if [ -z "$CONDITIONS" ]; then
  CONDITIONS="STATE|high|LOG_MISSING|1|log 檔不存在或不可讀|monitor 無法讀取 LOG_FILE，監控暫時失效，請確認路徑與排程是否用 root 執行。"
  FREEZE=1
fi
printf '%s' "$CONDITIONS" | grep -q '|LOG_MISSING|' && FREEZE=1

# =============================================================================
# (6) EVENT 條件 (§6.4 (2)(5))：依新段落計數；首次執行全部 0
# =============================================================================
declare -A EVENT_NEWCOUNT EV_SEV EV_TITLE EV_DETAIL
EV_SEV=([MIGRATION_BLOCKED]=high [FATAL_EXIT]=high [LOG_WRITE_FAILED]=high [ERROR_DETECTED]=high [WRONG_PATH]=high
  [SHARD_TRIMMED]=medium [BLOCKED_AUTORESUME]=medium [OWNER_HOST]=medium [NEW_RUN]=medium [RULES_CHANGED]=medium
  [UNKNOWN_WARN]=medium [OUTPUT_UNKNOWN]=medium [WEAK_CONCERN]=medium [NEW_SOURCE_TABLES]=medium [LOG_GAP]=medium
  [DUPLICATE_START]=medium [LIVE_REACHED]=info)
EV_TITLE=([MIGRATION_BLOCKED]="[CRITICAL] 完整性檢查失敗，migration BLOCKED (程式退出)" [FATAL_EXIT]="[CRITICAL] 程式致命退出"
  [LOG_WRITE_FAILED]="[CRITICAL] log 寫不進去 (程式還在但已停擺)" [ERROR_DETECTED]="出現 EROR/CRIT 錯誤行" [WRONG_PATH]="conf 走到舊路徑 (無法續傳)"
  [SHARD_TRIMMED]="[WARN] stream 資料已被修剪，已自動恢復" [BLOCKED_AUTORESUME]="[WARN] 從上次 BLOCKED 自動續傳中" [OWNER_HOST]="上次執行的主機不是這台"
  [NEW_RUN]="[WARN] 開了新的一輪 (全部表會重搬)" [RULES_CHANGED]="型別規則檔與部署時不同" [UNKNOWN_WARN]="[WARN] 出現未列入規格的 WARN 行"
  [OUTPUT_UNKNOWN]=".output 出現未列入規格的行" [WEAK_CONCERN]="目的端寫入保證不是 majority+journal" [NEW_SOURCE_TABLES]="來源新增了表 (本輪不會同步)"
  [LOG_GAP]="[WARN] 上次讀到一半的 log 檔不見了" [DUPLICATE_START]="[WARN] 有人重複啟動 (原程序仍在)" [LIVE_REACHED]="已進入即時同步 (LIVE)")
if [ "$FIRST_RUN" -eq 0 ] && [ "$FREEZE" -eq 0 ]; then
  EVENT_NEWCOUNT[MIGRATION_BLOCKED]=$(seg_count "$E_BLK")
  EVENT_NEWCOUNT[WRONG_PATH]=$(seg_count "$E_L10")
  EVENT_NEWCOUNT[SHARD_TRIMMED]=$(seg_count "$E_L36")
  EVENT_NEWCOUNT[BLOCKED_AUTORESUME]=$(seg_count "$E_AUTORESUME")
  EVENT_NEWCOUNT[OWNER_HOST]=$(seg_count "$E_L13")
  EVENT_NEWCOUNT[NEW_RUN]=$(seg_count "$E_NEWRUN")
  EVENT_NEWCOUNT[LIVE_REACHED]=$(seg_count "$E_L30")
  EVENT_NEWCOUNT[WEAK_CONCERN]=$(seg_count "$E_L08")
  EVENT_NEWCOUNT[NEW_SOURCE_TABLES]=$(seg_count "$E_L11")
  EVENT_NEWCOUNT[ERROR_DETECTED]=$( [ -z "$NEW_SEG" ] && echo 0 || printf '%s\n' "$NEW_SEG" | LC_ALL=C grep -aE "$E_ERR" | LC_ALL=C grep -avcE "$E_BLK")
  EVENT_NEWCOUNT[UNKNOWN_WARN]=$( [ -z "$NEW_SEG" ] && echo 0 || printf '%s\n' "$NEW_SEG" | LC_ALL=C grep -aE "${P}\[WARN\]" | LC_ALL=C grep -avcE "$E_WARNKNOWN")
  if [ -n "$RULES_SHA256" ]; then
    EVENT_NEWCOUNT[RULES_CHANGED]=$( [ -z "$NEW_SEG" ] && echo 0 || printf '%s\n' "$NEW_SEG" | LC_ALL=C grep -aE "$E_START" | LC_ALL=C grep -aoE 'rules_sha256=[0-9a-f]{64}' | LC_ALL=C grep -avcF "rules_sha256=$RULES_SHA256")
  else EVENT_NEWCOUNT[RULES_CHANGED]=0; fi
  EVENT_NEWCOUNT[LOG_GAP]=$LOG_GAP
  # MIGRATION_BLOCKED 的 DETAIL: 只取第 1 個 table= 與 E_REASON 代碼
  if [ "${EVENT_NEWCOUNT[MIGRATION_BLOCKED]}" -gt 0 ]; then
    BLK_LINE=$(printf '%s\n' "$NEW_SEG" | LC_ALL=C grep -aE "$E_BLK" | head -1)
    BLK_TABLE=$(printf '%s\n' "$BLK_LINE" | LC_ALL=C grep -aoE 'table=[A-Za-z0-9_.-]+' | head -1)
    BLK_CODE=$(printf '%s\n' "$BLK_LINE" | LC_ALL=C grep -aoE "$E_REASON" | head -1 | cut -c8-)
    case " $FATAL_CODES " in *" ${BLK_CODE:-#} "*) ;; *) BLK_CODE=OTHER ;; esac
    EV_DETAIL[MIGRATION_BLOCKED]="${BLK_TABLE:-table=?} code=${BLK_CODE}，共 ${EVENT_NEWCOUNT[MIGRATION_BLOCKED]} 行。"
  fi
  [ "${EVENT_NEWCOUNT[LOG_GAP]}" -gt 0 ] && EV_DETAIL[LOG_GAP]="找不到上次記錄的 inode；目前檔已從 0 讀起。"
  [ "${EVENT_NEWCOUNT[ERROR_DETECTED]}" -gt 0 ] && EV_DETAIL[ERROR_DETECTED]="新段落 ${EVENT_NEWCOUNT[ERROR_DETECTED]} 行 (不含 migration BLOCKED)。"
  [ "${EVENT_NEWCOUNT[UNKNOWN_WARN]}" -gt 0 ] && EV_DETAIL[UNKNOWN_WARN]="新段落 ${EVENT_NEWCOUNT[UNKNOWN_WARN]} 行。"
  [ "${EVENT_NEWCOUNT[NEW_RUN]}" -gt 0 ] && EV_DETAIL[NEW_RUN]="bootstrap table 行 ${EVENT_NEWCOUNT[NEW_RUN]} 筆；runId ${RUNID:0:8}。"
  [ "${EVENT_NEWCOUNT[LIVE_REACHED]}" -gt 0 ] && EV_DETAIL[LIVE_REACHED]="runId ${RUNID:0:8}。"
  [ "${EVENT_NEWCOUNT[SHARD_TRIMMED]}" -gt 0 ] && EV_DETAIL[SHARD_TRIMMED]="新段落 ${EVENT_NEWCOUNT[SHARD_TRIMMED]} 個 shard。"
  if [ "${EVENT_NEWCOUNT[BLOCKED_AUTORESUME]}" -gt 0 ]; then
    _rs=$(ns_get resume_state); EV_DETAIL[BLOCKED_AUTORESUME]="新段落 ${EVENT_NEWCOUNT[BLOCKED_AUTORESUME]} 行${_rs:+；還原狀態 ${_rs}}。"
  fi
fi
# .output 類 (FREEZE 時也要處理；首次建基準時 PREV_OUT_OFFSET=OUT_DONE → 全部 0)
EVENT_NEWCOUNT[FATAL_EXIT]=$(oget fatal); EVENT_NEWCOUNT[LOG_WRITE_FAILED]=$(oget logwrite)
EVENT_NEWCOUNT[OUTPUT_UNKNOWN]=$(oget unknown); EVENT_NEWCOUNT[DUPLICATE_START]=0
if [ "$(oget fatal)" -gt 0 ] && [ "$(oget tail_fatal)" -gt 0 ] && [ "$ALIVE" -eq 1 ]; then
  EVENT_NEWCOUNT[DUPLICATE_START]=1; EVENT_NEWCOUNT[FATAL_EXIT]=0
  EV_DETAIL[DUPLICATE_START]="致命行代碼 $(fatal_code "$FATAL_LINE")；原程序 PID ${ALIVE_PID} 仍在。"
fi
[ "${EVENT_NEWCOUNT[FATAL_EXIT]}" -gt 0 ] && { EVENT_NEWCOUNT[OUTPUT_UNKNOWN]=0; EV_DETAIL[FATAL_EXIT]="代碼 $(fatal_code "$FATAL_LINE")；本輪新增 ${EVENT_NEWCOUNT[FATAL_EXIT]} 行致命行。"; }
[ "${EVENT_NEWCOUNT[OUTPUT_UNKNOWN]}" -gt 0 ] && EV_DETAIL[OUTPUT_UNKNOWN]=".output 新段落 ${EVENT_NEWCOUNT[OUTPUT_UNKNOWN]} 行非白名單。"
[ "${EVENT_NEWCOUNT[LOG_WRITE_FAILED]}" -gt 0 ] && EV_DETAIL[LOG_WRITE_FAILED]="FileLogWriter 行 ${EVENT_NEWCOUNT[LOG_WRITE_FAILED]} 筆。"
for id in "${!EVENT_NEWCOUNT[@]}"; do
  [ "${EVENT_NEWCOUNT[$id]:-0}" -gt 0 ] || continue
  CONDITIONS+=$'\n'"EVENT|${EV_SEV[$id]}|$id|${EVENT_NEWCOUNT[$id]}|${EV_TITLE[$id]}|${EV_DETAIL[$id]:-}"
done

# =============================================================================
# 條件狀態檔 (tab 分隔)；EVENT 多一個 last_seen (保留期用)
# =============================================================================
state_get() { local f="$COND_DIR/$1"; [ -f "$f" ] || return 1
  LC_ALL=C "$GAWK" -F '\t' -v k="$2" '$1==k{ sub(/^[^\t]*\t/,""); print; f=1; exit } END{ exit(f?0:1) }' "$f"; }
state_write() { # ID type sev first_seen last_sent count title last_seen
  local f="$COND_DIR/$1"
  ( umask 077; { printf 'type\t%s\n' "$2"; printf 'severity\t%s\n' "$3"; printf 'first_seen\t%s\n' "$4"; printf 'last_sent\t%s\n' "$5"
      printf 'count\t%s\n' "$6"; printf 'title\t%s\n' "$7"; printf 'last_seen\t%s\n' "${8:-$NOW}"; } > "$f.tmp" ) && mv -f "$f.tmp" "$f"
}

# ---- 處置文字 (§6.6；只引用代碼，不要求貼原始內容) --------------------------------
action_for() {
  case "$1" in
    MIGRATION_BLOCKED) echo "完整性檢查失敗，程式已停止，目標庫資料沒有被清除。請重跑 sudo ./start.sh 一次，程式會自動還原後重試。若再次出現 BLOCKED，不要自行設定 force_restart，請通知我方並提供時間點。要在 23 小時內處理。" ;;
    FATAL_EXIT) echo "程式已退出，原因代碼見本信。只看代碼: sudo grep -aoE '^(sync failed: [A-Z_]*|panic: |fatal error: |SIG[A-Z]+:|Configure file|current required configuration version|illegal value|write pid failed)' nimo-shake.linux.output | tail -3 (不要 tail 整個檔，內容含設定值)。依代碼處理: FINGERPRINT_MISMATCH=conf 或規則檔被改過，改回後重跑 start.sh；MIGRATION_ALREADY_RUNNING=已有程序在跑，用 pgrep -af nimo-shake.linux 確認；RETRY_BUDGET_EXHAUSTED=確認 AWS 或 Atlas 恢復後重跑 start.sh；STREAM_GAP=通知我方；CONF_ERROR=conf 有誤，通知我方；TARGET_*、*PRIMARY*、INVALID_*、UNSUPPORTED_SCHEMA、CHECKPOINT_INCOMPLETE、LEGACY_CHECKPOINT_UNSAFE、FULL_PAGE_MEMORY_LIMIT=不要重跑，通知我方；CRASH、OTHER=重跑 start.sh 一次 (會從 checkpoint 續傳)。同一個代碼連續 2 次 FATAL_EXIT 就停止重跑，通知我方。" ;;
    LOG_WRITE_FAILED) echo "log 寫不進去，程式還在但已停擺 (寫檔執行緒不會自己恢復)。先 df -h /home 清出空間，再 sudo ./stop.sh、sudo ./start.sh。" ;;
    DUPLICATE_START) echo "有人重複啟動。原程序仍在跑，但 log 可能已被輪替: 用 ls -l logs/ 看 .1 是否仍在變大。若是，執行 sudo ./stop.sh (pid 檔可能已被刪，那就 sudo kill <pgrep -f nimo-shake.linux 找到的 pid>)，再 sudo ./start.sh。" ;;
    PROCESS_DOWN) echo "程式不在。執行 dmesg -T | grep -i -E 'killed process|out of memory' 查是否被 OOM 或 kill -9。重跑 sudo ./start.sh 會從 checkpoint 續傳，不會清空目標庫。停機不要超過 23 小時。" ;;
    FULL_SYNC_INCOMPLETE) echo "全量掃描中途停止。重跑 sudo ./start.sh 會從各 segment 已落盤的頁接續，已完成的表不會重做，不會清空目標庫。" ;;
    STOP_LONG|STOP_TOO_LONG) echo "程式已停止超過 12／20 小時。停機超過 23 小時會因為無法證明增量沒漏而 STREAM_GAP，只能開新的一輪重搬。請盡快重跑 sudo ./start.sh。" ;;
    PLANNED_STOP) echo "(info，只記錄) 計畫內停機。" ;;
    HEARTBEAT_LOST|HEARTBEAT_LOST_LONG) echo "程式還在，但心跳行停了。先 df -h /home；再用 ls -l logs/ 看 .1 是否仍在變大 (是的話表示有人重複啟動、log 被輪替，照 DUPLICATE_START 處理)；再看 sudo grep -c '^FileLogWriter(' nimo-shake.linux.output。磁碟正常時看 top -p <pid> 的 CPU。必要時 sudo ./stop.sh 後 sudo ./start.sh。" ;;
    LOG_MISSING) echo "確認 conf 的 LOG_FILE 路徑，以及排程是否用 root 執行。這段期間監控是失效的。" ;;
    LOG_GAP) echo "上次讀到一半的 log 檔不見了 (被刪，或 logs/ 被清)，中間的事件可能漏看。請確認是誰清的，並通知我方。" ;;
    LOG_TZ_UNEXPECTED) echo "log 時間不是 UTC，時間類條件已停用。確認主機或啟動環境的 TZ 是否被改過，改回 UTC 後重啟 NimoShake。" ;;
    ERROR_DETECTED) echo "出現錯誤行。請通知我方，由我方在主機上查看內容。" ;;
    WRONG_PATH) echo "conf 的 target.type 和 checkpoint.type 都必須是 mongodb，否則不能續傳。請停機改回後重跑 start.sh，並通知我方。" ;;
    RETRY_BUDGET_LOW) echo "某個操作的重試預算快用完了，用完程式會退出。依 operation 檢查: aws.*、capture.* 看 AWS；target.*、mongo.connect 看 Atlas；resume.*、shard.*、spool.* 看 checkpoint 庫 (同一個 Atlas)。" ;;
    BOOTSTRAP_STUCK) echo "啟動時建立增量起點超過 20 分鐘。正式機正常約 5 分鐘 (10-05 實測 5m10s)。請收集時間點通知我方，不要設定 force_restart。" ;;
    FULL_STALL) echo "某張表 10 分鐘沒有新頁落盤。查 AWS (Scan 限流) 與 Atlas 負載；同時看有沒有 RETRY_BUDGET_LOW、THROTTLE。" ;;
    APPLY_STALL) echo "有待套用的事件，但 10 分鐘沒有寫入。查 Atlas 是否可寫、負載是否過高。" ;;
    APPLY_LAG|APPLY_LAG_HIGH) echo "增量延遲超過門檻。查 Atlas 負載與 THROTTLE、CONN_ERROR；確認來源是否有大量寫入 (看報表的活躍表 Top 3)。" ;;
    BACKLOG_GROWING) echo "積壓持續增加，寫入跟不上讀取。處理方式同 APPLY_LAG。" ;;
    CAPTURE_IDLE) echo "增量抓取 30 分鐘沒有任何新事件。若來源這段時間確實有寫入，表示 capture 停住了，請通知我方。不處理的話，約 24 小時後會出現 SHARD_TRIMMED 或 STREAM_GAP。" ;;
    STREAM_RETRY) echo "有操作持續重試中，可能是全量 Scan、目標寫入或 checkpoint 庫。看同時段 retry 行的 operation 與 code (報表的「重試」列)。" ;;
    STREAM_HEALTH_UNAVAILABLE) echo "增量健康統計查不到，通常是 checkpoint 庫慢或連不上；程式本身仍在跑。查 Atlas。" ;;
    THROTTLE) echo "aws.Scan: 全量讀取被限流，調低 conf 的 qps.full 或提高來源 RCU。capture.*: Streams 讀取被限流，和 qps.full 無關，請通知我方。" ;;
    CONN_ERROR) echo "依 operation 檢查網路、防火牆、DNS。代碼是 Mongo 主節點切換 (10107、11602 等) 時通常是 Atlas 維護，之後沒有再出現就不用處理。" ;;
    SHARD_TRIMMED) echo "capture 落後到接近 stream 的 24 小時保留期，已自動恢復。請確認最近是否有長時間停機，並通知我方。" ;;
    BLOCKED_AUTORESUME) echo "程式正從上次的 BLOCKED 自動續傳，不用處理。之後若出現 MIGRATION_BLOCKED，表示問題仍在。" ;;
    OWNER_HOST) echo "上次執行的主機不是這台。確認沒有兩台同時在跑。" ;;
    NEW_RUN) echo "開了新的一輪，全部表會重搬一次。若不是預期中的操作，請立即通知我方。" ;;
    SPOOL_GC_FAIL) echo "暫存事件清不掉，checkpoint 庫會持續變大。查 Atlas。" ;;
    BUFFER_WAIT|DISCOVERY_WAIT) echo "內部等待持續超過門檻，通常是寫入端慢。查 Atlas 負載。" ;;
    RULES_CHANGED) echo "本次啟動的型別規則和部署時不同。確認是否有人改過 type_rules_opapp.json，並通知我方。" ;;
    UNKNOWN_WARN|OUTPUT_UNKNOWN) echo "出現規格沒有列出的訊息。請通知我方，由我方在主機上查看內容。" ;;
    LIVE_REACHED) echo "(info，只記錄) 已進入即時同步。" ;;
    CAST_ISSUE) echo "有新的型別轉換失敗 (原值已保留寫入，不影響同步)。請將 collection、field、reason 代碼轉給我方。" ;;
    WEAK_CONCERN) echo "目的端連線字串的寫入保證不是 majority+journal。請通知我方。" ;;
    NEW_SOURCE_TABLES) echo "來源新增了表，本輪不會同步。請通知我方。" ;;
    *) echo "執行 --status 查看目前所有條件，依代碼處理。" ;;
  esac
}

# ---- HTML 信件輔助 ------------------------------------------------------------
sev_color() { case "$1" in high) echo '#d93025';; medium) echo '#e37400';; *) echo '#5f6368';; esac; }
html_escape() { printf '%s' "$1" | sed 's/&/\&amp;/g; s/</\&lt;/g; s/>/\&gt;/g'; }
html_card() { # 顏色 標題 狀況 處理
  local c="$1" t s a; t=$(html_escape "$2"); s=$(html_escape "$3"); a=$(html_escape "$4")
  printf '<div style="border-left:4px solid %s;background:#f8f9fa;padding:10px 14px;margin:0 0 10px;border-radius:0 6px 6px 0">' "$c"
  printf '<div style="font-weight:bold;color:%s">%s</div>' "$c" "$t"
  [ -n "$s" ] && printf '<div style="color:#3c4043;margin-top:4px">狀況: %s</div>' "$s"
  [ -n "$a" ] && printf '<div style="color:#202124;margin-top:6px;padding:8px 10px;background:#fff;border:1px solid #e0e0e0;border-radius:4px">👉 <b>處理:</b> %s</div>' "$a"
  printf '</div>'
}

# =============================================================================
# (7) 條件狀態機: 新增 / 未解除 (REALERT) / 已解除；EVENT 保留期；STATE 遲滯由 monitor 做
# =============================================================================
NEW_LIST=""; NEW_HTML=""; FIRING_LIST=""; FIRING_HTML=""; RESOLVED_LIST=""; RESOLVED_HTML=""
NEW_IDS=""; FIRING_DUE_IDS=""; RESOLVED_IDS=""
declare -A ACTIVE_IDS
process_condition() { # TYPE SEV ID COUNT TITLE DETAIL
  local type="$1" sev="$2" id="$3" cnt="$4" title="$5" detail="$6"
  [ "$id" = "ALL_CLEAR" ] && return
  ACTIVE_IDS[$id]=1
  local rank; rank=$(sev_rank "$sev"); local below=0; [ "$rank" -lt "$MIN_RANK" ] && below=1
  local prev_first prev_last
  if prev_first=$(state_get "$id" first_seen 2>/dev/null); then
    prev_last=$(state_get "$id" last_sent 2>/dev/null); : "${prev_last:=0}"
    state_write "$id" "$type" "$sev" "$prev_first" "$prev_last" "$cnt" "$title" "$NOW"
    if [ "$below" -eq 0 ] && { [ "${prev_last:-0}" -eq 0 ] || { [ "${REALERT_INTERVAL:-0}" -gt 0 ] && [ $((NOW - prev_last)) -ge "$REALERT_INTERVAL" ]; }; }; then
      local dur; dur=$((NOW - prev_first))
      FIRING_LIST+="■ [$sev] $title (已持續 $((dur/3600))h$(((dur%3600)/60))m)"$'\n'"   狀況: $detail"$'\n'"   👉 處理: $(action_for "$id")"$'\n\n'
      FIRING_HTML+=$(html_card "$(sev_color "$sev")" "[$sev] $title（已持續 $((dur/3600))h$(((dur%3600)/60))m）" "$detail" "$(action_for "$id")")
      FIRING_DUE_IDS+=" $id"
    fi
  else
    if [ "$below" -eq 0 ]; then
      state_write "$id" "$type" "$sev" "$NOW" "0" "$cnt" "$title" "$NOW"
      NEW_LIST+="■ [$sev] $title"$'\n'"   狀況: $detail"$'\n'"   👉 處理: $(action_for "$id")"$'\n\n'
      NEW_HTML+=$(html_card "$(sev_color "$sev")" "[$sev] $title" "$detail" "$(action_for "$id")")
      NEW_IDS+=" $id"
    else
      state_write "$id" "$type" "$sev" "$NOW" "$NOW" "$cnt" "$title" "$NOW"
      log_line "INFO: 新增條件 $id ($sev) 低於寄信門檻($ALERT_MIN_SEVERITY)，僅記錄"
    fi
  fi
}
while IFS='|' read -r type sev id cnt title detail; do
  [ -z "$id" ] && continue
  process_condition "$type" "$sev" "$id" "${cnt:-1}" "$title" "$detail"
done < <(printf '%s\n' "$CONDITIONS")

# ---- 已解除 / 保留期到期 ----
if [ -d "$COND_DIR" ]; then
  for f in "$COND_DIR"/*; do
    [ -e "$f" ] || continue
    id=$(basename "$f"); [ "${id%.tmp}" != "$id" ] && continue
    [ -n "${ACTIVE_IDS[$id]:-}" ] && continue
    stype=$(state_get "$id" type 2>/dev/null); : "${stype:=STATE}"
    # FREEZE (log 遺失) 期間凍結 log 類條件；.output 類 EVENT 不受影響
    if [ "$FREEZE" -eq 1 ]; then case "$id" in FATAL_EXIT|OUTPUT_UNKNOWN|LOG_WRITE_FAILED|DUPLICATE_START) ;; *) continue ;; esac; fi
    ssev=$(state_get "$id" severity 2>/dev/null); : "${ssev:=medium}"
    stitle=$(state_get "$id" title 2>/dev/null); : "${stitle:=$id}"
    sfirst=$(state_get "$id" first_seen 2>/dev/null); : "${sfirst:=$NOW}"
    slast=$(state_get "$id" last_sent 2>/dev/null); : "${slast:=0}"
    sseen=$(state_get "$id" last_seen 2>/dev/null); : "${sseen:=$sfirst}"
    if [ "$stype" = "EVENT" ]; then
      if [ "$slast" -eq 0 ] && [ "$(sev_rank "$ssev")" -ge "$MIN_RANK" ]; then
        scnt=$(state_get "$id" count 2>/dev/null); : "${scnt:=1}"
        NEW_LIST+="■ [$ssev] $stitle (先前通知未送出，本封為補送；累計 $scnt 筆)"$'\n'"   👉 處理: $(action_for "$id")"$'\n\n'
        NEW_HTML+=$(html_card "$(sev_color "$ssev")" "[$ssev] $stitle（先前通知未送出，本封為補送；累計 $scnt 筆）" "" "$(action_for "$id")")
        NEW_IDS+=" $id"
      elif [ $((NOW - sseen)) -ge "$EVENT_HOLD_SEC" ]; then
        log_line "INFO: 事件 $id 保留期 ${EVENT_HOLD_SEC}s 已過，清除"
        rm -f "$f" 2>/dev/null || true
      fi
      continue
    fi
    if [ "${NOTIFY_RESOLVED:-1}" = "1" ] && [ "$(sev_rank "$ssev")" -ge "$MIN_RANK" ]; then
      dur=$((NOW - sfirst))
      RESOLVED_LIST+="■ [$ssev] $stitle (曾持續 $((dur/60)) 分鐘，已自動恢復，無需處理)"$'\n'
      RESOLVED_HTML+=$(html_card "#188038" "[$ssev] $stitle（曾持續 $((dur/60)) 分鐘，已自動恢復，無需處理）" "" "")
      RESOLVED_IDS+=" $id"
    else
      log_line "INFO: 條件 $id 已不活躍，靜默清除 (type=$stype)"
      rm -f "$f" 2>/dev/null || true
    fi
  done
fi

# =============================================================================
# (8) FullCheck 結束通知 (專版 run-manifest.json；信件不放主鍵與資料值)
# =============================================================================
FC_SEEN_FILE="$STATE_DIR/.fullcheck_seen"; FC_RUN_FILE="$STATE_DIR/.fullcheck_running"
FC_IDS=(); FC_SUBJECTS=(); FC_BODIES=(); FC_HTMLS=()
FC_FAIL_SUBJECT=""; FC_FAIL_BODY=""; FC_FAIL_HTML=""
fc_field_num() { printf '%s' "$1" | LC_ALL=C sed -n 's/.*"'"$2"'"[[:space:]]*:[[:space:]]*\(-\{0,1\}[0-9][0-9]*\).*/\1/p' | head -1; }
fc_field_str() { printf '%s' "$1" | LC_ALL=C sed -n 's/.*"'"$2"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1; }
fc_manifest_str() { LC_ALL=C grep -ao '"'"$2"'"[[:space:]]*:[[:space:]]*"[^"]*"' "$1" 2>/dev/null | tail -1 | sed 's/.*"\([^"]*\)"$/\1/'; }
iso_epoch() { # "2026-10-05T10:00:00Z" 或 "2026-10-05 10:00:00" -> epoch (格式不符印空；不用 date -d)
  printf '%s\n' "${1:-}" | LC_ALL=C grep -aoE '^[0-9]{4}-[0-9]{2}-[0-9]{2}[T ][0-9]{2}:[0-9]{2}:[0-9]{2}' \
    | TZ=UTC "$GAWK" '{ d=$0; gsub(/[-T:]/," ",d); print mktime(d) }'
}
fc_build_mail() { # manifest 指紋
  local mf="$1" fid="$2" dir outcome ms me dur="-" host subj s1 s2
  dir=$(cd "$(dirname "$mf")" 2>/dev/null && pwd) || dir=$(dirname "$mf")
  outcome=$(fc_manifest_str "$mf" outcome | tr -dc 'A-Z_'); : "${outcome:=UNKNOWN}"
  ms=$(fc_manifest_str "$mf" started_at | tr -dc '0-9TZ:. -'); me=$(fc_manifest_str "$mf" finished_at | tr -dc '0-9TZ:. -')
  s1=$(iso_epoch "$ms"); s2=$(iso_epoch "$me")
  if [ -n "$s1" ] && [ -n "$s2" ]; then dur=$(human_secs $((s2 - s1))); fi
  local summaries; summaries=$(LC_ALL=C grep -rhsa '"type":"summary"' "$dir" 2>/dev/null || true)
  local n_table=0 t_ck=0 t_ps=0 t_fl=0 t_ex=0 t_er=0 t_tg=0 rows_txt="" rows_html="" line tb oc ck ps fl ex er tg hl td
  td='padding:6px 10px;border:1px solid #e0e0e0'
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    tb=$(fc_field_str "$line" table | tr -dc 'A-Za-z0-9_.-'); oc=$(fc_field_str "$line" outcome | tr -dc 'A-Z_')
    ck=$(fc_field_num "$line" checked); ps=$(fc_field_num "$line" passed); fl=$(fc_field_num "$line" failed)
    ex=$(fc_field_num "$line" exceptions); er=$(fc_field_num "$line" execution_errors); tg=$(fc_field_num "$line" target_only)
    : "${ck:=0}" "${ps:=0}" "${fl:=0}" "${ex:=0}" "${er:=0}" "${tg:=0}"
    n_table=$((n_table+1)); t_ck=$((t_ck+ck)); t_ps=$((t_ps+ps)); t_fl=$((t_fl+fl)); t_ex=$((t_ex+ex)); t_er=$((t_er+er)); t_tg=$((t_tg+tg))
    rows_txt+=$(printf '  %-28s %11s %11s %7s %5s %5s %5s  %s' "$tb" "$ck" "$ps" "$fl" "$ex" "$er" "$tg" "${oc:-?}")$'\n'
    hl=""; { [ "$fl" -gt 0 ] || [ "$er" -gt 0 ]; } && hl=' style="background:#fdf6f6"'
    rows_html+='<tr'"$hl"'><td style="'"$td"';font-weight:bold">'"$(html_escape "$tb")"'</td><td style="'"$td"';text-align:right">'"$ck"'</td><td style="'"$td"';text-align:right">'"$ps"'</td><td style="'"$td"';text-align:right">'"$fl"'</td><td style="'"$td"';text-align:right">'"$ex"'</td><td style="'"$td"';text-align:right">'"$er"'</td><td style="'"$td"';text-align:right">'"$tg"'</td><td style="'"$td"';white-space:nowrap">'"$(html_escape "${oc:-?}")"'</td></tr>'
  done < <(printf '%s\n' "$summaries")
  # 異常分布: 只統計 表 × 欄位路徑 × 分類 的筆數 (§8.2: 不放 pk/sk/source_value/actual_value)
  local exc_top=""
  if [ "$t_ex" -gt 0 ] || [ "$t_fl" -gt 0 ]; then
    exc_top=$(cd "$dir" 2>/dev/null && LC_ALL=C grep -sHaE '"severity":"(EXCEPTION|DIFF)"' -- * 2>/dev/null \
      | LC_ALL=C "$GAWK" '{ t=$0; sub(/:.*/,"",t); p=""; c=""; if (match($0,/"path":"[^"]*"/)) p=substr($0,RSTART+8,RLENGTH-9); if (match($0,/"classification":"[A-Z_]*"/)) c=substr($0,RSTART+18,RLENGTH-19); if (c=="" && $0 ~ /"severity":"DIFF"/) c="DIFF"; k[t "  " p "  " (c==""?"-":c)]++ } END { for (x in k) printf "%6d 筆  %s\n", k[x], x }' \
      | sort -rn | head -10)
  fi
  local icon color head
  case "$outcome" in
    PASS) icon="🟢"; color="#188038"; head="FullCheck 完成 — PASS" ;;
    PASS_WITH_EXCEPTIONS) icon="🟠"; color="#f9ab00"; head="FullCheck 完成 — PASS_WITH_EXCEPTIONS (${t_ex} 筆 exception)" ;;
    *) icon="🔴"; color="#d93025"; head="FullCheck 完成 — $outcome (failed=$t_fl)" ;;
  esac
  host=$(hostname 2>/dev/null || echo "?"); subj="$ENV_NAME"; [ -n "${HOST_ROLE:-}" ] && subj="$ENV_NAME·$HOST_ROLE"
  local body
  body="nimo-full-check 全量複核已結束，結果如下:

結果   : $outcome
開始   : ${ms:-?} (UTC)
結束   : ${me:-?} (UTC)
耗時   : $dur
輸出   : $dir

各 Table 統計 (共 $n_table 個):
$(printf '  %-28s %11s %11s %7s %5s %5s %5s  %s' table checked passed failed exc err tgt outcome)
$rows_txt  合計: checked=$t_ck passed=$t_ps failed=$t_fl exceptions=$t_ex exec_err=$t_er target_only=$t_tg

欄位說明:
  checked=檢核筆數  passed=通過筆數
  failed=不符筆數 (來源與目標不一致，須補搬後重新驗證)
  exc=來源型別例外 (來源資料原生型別問題，非搬遷錯誤；逐筆確認後列例外清單結案)
  err=執行錯誤 (讀取/連線等程式面錯誤)  tgt=目標端多出筆數 (來源不存在)
"
  [ -n "$exc_top" ] && body+="
異常分布 (表 / 欄位路徑 / 分類，依筆數 Top 10；主鍵與資料值依資安要求不列入信件，請登主機看輸出資料夾):
$exc_top
"
  body+="
---
環境: $subj  主機: $host
時間: $(date '+%F %T %Z')
(本信由 nimoshake-alert.sh 偵測到 FullCheck 結束自動發送)"
  local html
  html='<div style="font-family:-apple-system,'"'Microsoft JhengHei','PingFang TC'"',Arial,sans-serif;font-size:14px;color:#202124;max-width:900px">'
  html+='<div style="border-left:4px solid '"$color"';padding:10px 14px;background:#f8f9fa;margin-bottom:14px;border-radius:0 6px 6px 0"><b style="color:'"$color"'">'"$(html_escape "$icon $head")"'</b><br><span style="color:#5f6368">耗時: '"$(html_escape "$dur")"'</span></div>'
  html+='<table cellspacing="0" cellpadding="0" style="border-collapse:collapse;font-size:13px;margin-bottom:14px"><tr><td style="padding:4px 12px 4px 0;color:#5f6368;white-space:nowrap">開始</td><td>'"$(html_escape "${ms:-?}")"' (UTC)</td></tr><tr><td style="padding:4px 12px 4px 0;color:#5f6368">結束</td><td>'"$(html_escape "${me:-?}")"' (UTC)</td></tr><tr><td style="padding:4px 12px 4px 0;color:#5f6368">輸出</td><td><code style="word-break:break-all">'"$(html_escape "$dir")"'</code></td></tr></table>'
  if [ "$n_table" -gt 0 ]; then
    html+='<div style="font-weight:bold;margin-bottom:6px">各 Table 統計（共 '"$n_table"' 個）</div><table cellspacing="0" cellpadding="0" style="border-collapse:collapse;width:100%;font-size:13px"><tr style="background:#f1f3f4">'
    local h; for h in table checked passed failed exceptions exec_err target_only outcome; do html+='<th style="'"$td"';text-align:left;white-space:nowrap">'"$h"'</th>'; done
    html+='</tr>'"$rows_html"'<tr style="background:#f8f9fa;font-weight:bold"><td style="'"$td"'">合計</td><td style="'"$td"';text-align:right">'"$t_ck"'</td><td style="'"$td"';text-align:right">'"$t_ps"'</td><td style="'"$td"';text-align:right">'"$t_fl"'</td><td style="'"$td"';text-align:right">'"$t_ex"'</td><td style="'"$td"';text-align:right">'"$t_er"'</td><td style="'"$td"';text-align:right">'"$t_tg"'</td><td style="'"$td"'">'"$(html_escape "$outcome")"'</td></tr></table>'
    html+='<div style="color:#5f6368;font-size:12px;margin-top:6px;line-height:1.7"><b>欄位說明</b>：checked＝檢核筆數／passed＝通過筆數／<b style="color:#d93025">failed＝不符筆數</b>（須補搬後重新驗證）／<b style="color:#e37400">exceptions＝來源型別例外</b>（來源資料原生型別問題，非搬遷錯誤）／exec_err＝執行錯誤／target_only＝目標端多出筆數</div>'
  fi
  [ -n "$exc_top" ] && html+='<div style="font-weight:bold;margin:14px 0 6px">異常分布（表 / 欄位路徑 / 分類，Top 10）</div><pre style="background:#f8f9fa;border:1px solid #e0e0e0;padding:10px;font-size:12px;overflow-x:auto;margin:0">'"$(html_escape "$exc_top")"'</pre><div style="color:#5f6368;font-size:12px;margin-top:4px">主鍵與資料值依資安要求不列入信件；完整清單請登主機看輸出資料夾各 table 檔。</div>'
  html+='<div style="color:#80868b;font-size:12px;border-top:1px solid #e0e0e0;margin-top:18px;padding-top:10px;line-height:1.7">環境: <b>'"$(html_escape "$subj")"'</b>　主機: '"$(html_escape "$host")"'　時間: '"$(date '+%F %T %Z')"'<br>（本信由 nimoshake-alert.sh 偵測到 FullCheck 結束自動發送）</div></div>'
  FC_IDS+=("$fid"); FC_SUBJECTS+=("【StarCo $subj】$icon $head"); FC_BODIES+=("$body"); FC_HTMLS+=("$html")
}
fc_build_fail_mail() { # first_seen epoch
  local fs="$1" host subj dur; host=$(hostname 2>/dev/null || echo "?"); subj="$ENV_NAME"; [ -n "${HOST_ROLE:-}" ] && subj="$ENV_NAME·$HOST_ROLE"
  dur=$(human_secs $((NOW - fs)))
  FC_FAIL_SUBJECT="【StarCo $subj】🔴 FullCheck 異常結束 (未產出結果)"
  FC_FAIL_BODY="偵測到 nimo-full-check 程序已消失，但輸出資料夾沒有出現新的 run-manifest.json (正常跑完一定會寫入結果檔) → 本次複核未完成。

首次偵測執行中: $(fmt_epoch "$fs")
已執行約      : $dur
監看目錄      : $FULLCHECK_DIR

可能原因: 手動中止 (Ctrl+C / kill)、記憶體不足被 OOM killer 終止、來源/目標連線中斷、磁碟空間不足。
👉 處理:
  1. 查執行終端機 / nohup 輸出的最後訊息 (只看代碼，不要把內容貼出來)
  2. dmesg -T | grep -i -E 'killed process|out of memory'
  3. df -h /home
  4. 排除原因後直接重下原本的 fullcheck 指令即可

---
環境: $subj  主機: $host
時間: $(date '+%F %T %Z')
(本信由 nimoshake-alert.sh 偵測到 FullCheck 異常結束自動發送)"
  FC_FAIL_HTML='<div style="font-family:-apple-system,'"'Microsoft JhengHei','PingFang TC'"',Arial,sans-serif;font-size:14px;color:#202124;max-width:860px">'
  FC_FAIL_HTML+=$(html_card "#d93025" "[high] FullCheck 異常結束（未產出結果，已執行約 $dur）" "nimo-full-check 程序已消失，但輸出資料夾沒有新的 run-manifest.json → 本次複核未完成。可能原因: 手動中止 / OOM / 連線中斷 / 磁碟滿。" "1) 查執行終端機或 nohup 輸出的最後訊息 (只看代碼)  2) dmesg -T | grep -i -E 'killed process|out of memory'  3) df -h /home  4) 排除後直接重下原本的 fullcheck 指令")
  FC_FAIL_HTML+='<div style="color:#80868b;font-size:12px;border-top:1px solid #e0e0e0;margin-top:18px;padding-top:10px;line-height:1.7">監看目錄: <code style="word-break:break-all">'"$(html_escape "$FULLCHECK_DIR")"'</code><br>環境: <b>'"$(html_escape "$subj")"'</b>　主機: '"$(html_escape "$host")"'　時間: '"$(date '+%F %T %Z')"'</div></div>'
}
if [ -n "${FULLCHECK_DIR:-}" ]; then
  FC_PROC_ALIVE=0
  if [ -n "${NS_TEST_FC_ALIVE:-}" ]; then FC_PROC_ALIVE="$NS_TEST_FC_ALIVE"
  elif command -v pgrep >/dev/null 2>&1; then pgrep -f "$FULLCHECK_PROC_PATTERN" >/dev/null 2>&1 && FC_PROC_ALIVE=1; fi
  FC_BASELINE=0; [ -f "$FC_SEEN_FILE" ] || FC_BASELINE=1
  for fc_root in $(printf '%s' "$FULLCHECK_DIR" | tr ',;' ' '); do
    [ -z "$fc_root" ] && continue
    [ -d "$fc_root" ] || { log_line "WARN: [$ENV_NAME] FULLCHECK_DIR 不存在: $fc_root"; continue; }
    for fc_mf in "$fc_root"/run-manifest.json "$fc_root"/*/run-manifest.json; do
      [ -f "$fc_mf" ] || continue
      fc_fin=$(fc_manifest_str "$fc_mf" finished_at | tr -dc '0-9TZ:. -')
      if [ -n "$fc_fin" ]; then fc_fid="$fc_fin|$(fc_manifest_str "$fc_mf" outcome | tr -dc 'A-Z_')"
      else fc_fid=$(md5sum "$fc_mf" 2>/dev/null | cut -d' ' -f1); : "${fc_fid:=$fc_mf}"; fi
      LC_ALL=C grep -qxF "$fc_fid" "$FC_SEEN_FILE" 2>/dev/null && continue
      if [ "$FC_BASELINE" -eq 1 ]; then [ "$STATUS_ONLY" -eq 0 ] && printf '%s\n' "$fc_fid" >> "$FC_SEEN_FILE" 2>/dev/null; continue; fi
      fc_build_mail "$fc_mf" "$fc_fid"
    done
  done
  if [ "$FC_BASELINE" -eq 1 ] && [ "$STATUS_ONLY" -eq 0 ]; then ( umask 077; touch "$FC_SEEN_FILE" ) 2>/dev/null || true; log_line "INFO: [$ENV_NAME] FullCheck 通知首次啟用，既有結果記為基準，不補寄歷史"; fi
  # 執行中 / 異常結束狀態機
  if [ "$FC_PROC_ALIVE" -eq 1 ]; then
    if [ ! -f "$FC_RUN_FILE" ] || LC_ALL=C grep -q '^gone_since' "$FC_RUN_FILE" 2>/dev/null; then
      [ "$STATUS_ONLY" -eq 0 ] && { write_atomic "$FC_RUN_FILE" "first_seen	$NOW"; log_line "INFO: [$ENV_NAME] 偵測到 nimo-full-check 執行中，開始追蹤"; }
    fi
  elif [ -f "$FC_RUN_FILE" ]; then
    if [ "${#FC_IDS[@]}" -gt 0 ]; then [ "$STATUS_ONLY" -eq 0 ] && rm -f "$FC_RUN_FILE" 2>/dev/null
    else
      fc_gone=$(LC_ALL=C "$GAWK" -F '\t' '$1=="gone_since"{print $2}' "$FC_RUN_FILE" 2>/dev/null)
      if [ -z "$fc_gone" ]; then [ "$STATUS_ONLY" -eq 0 ] && printf 'gone_since\t%s\n' "$NOW" >> "$FC_RUN_FILE" 2>/dev/null   # 寬限一輪
      else fc_first=$(LC_ALL=C "$GAWK" -F '\t' '$1=="first_seen"{print $2}' "$FC_RUN_FILE" 2>/dev/null); fc_build_fail_mail "${fc_first:-$NOW}"; fi
    fi
  fi
fi

# =============================================================================
# (9) offset / inode (tmp+mv)；FREEZE 時不動 log offset
# =============================================================================
if [ "$STATUS_ONLY" -eq 0 ]; then
  if [ "$FREEZE" -eq 0 ] && [ -n "$NEW_OFFSET" ]; then write_atomic "$LOG_OFF_FILE" "$NEW_OFFSET"; write_atomic "$LOG_INO_FILE" "$NEW_INO"; fi
  write_atomic "$OUT_OFF_FILE" "$OUT_DONE"
  rm -f "$STATE_DIR/.api_snapshot" 2>/dev/null || true   # v4.3 遺留，1.0.16c 無 API
fi

# =============================================================================
# --status: 只印，不寄，不動狀態
# =============================================================================
if [ "$STATUS_ONLY" -eq 1 ]; then
  echo "===== [$ENV_NAME] 目前狀態 ($(date '+%F %T')) ====="
  echo "LOG: $LOG_FILE  size=$LOG_SIZE  inode=$NEW_INO  offset=${NEW_OFFSET:-?}  (上次 offset=${PREV_OFFSET:-?} inode=${PREV_INO:-?})  首次=$FIRST_RUN 凍結=$FREEZE"
  echo ".output: size=$OUT_SIZE done=$OUT_DONE (上次 offset=$PREV_OUT_OFFSET)  scan: $OUT_SCAN"
  echo "程序: alive=$ALIVE pid=${ALIVE_PID:-}  ns_state: phase=$PHASE runid=${RUNID:0:8} absent_runs=$ABSENT_RUNS"
  echo "DRY_RUN=$DRY_RUN  DRY_RUN_DUMP=$DRY_RUN_DUMP  ALERT_MIN_SEVERITY=$ALERT_MIN_SEVERITY  REALERT=${REALERT_INTERVAL}s  EVENT_HOLD=${EVENT_HOLD_SEC}s"
  echo "--- ns_state ---"; cat "$NS_STATE_FILE" 2>/dev/null | LC_ALL=C grep -avE '^(fin_tables|seg_done|run_table_set)	' | paste -sd' ' -
  echo "--- 目前條件 ---"; printf '%s\n' "$CONDITIONS"
  echo "--- 新增 ---"; printf '%s' "${NEW_LIST:-  (無)
}"
  echo "--- 到期提醒 ---"; printf '%s' "${FIRING_LIST:-  (無)
}"
  echo "--- 已解除 ---"; printf '%s' "${RESOLVED_LIST:-  (無)
}"
  if [ -n "${FULLCHECK_DIR:-}" ]; then
    echo "--- FullCheck ---"
    [ "${FC_PROC_ALIVE:-0}" -eq 1 ] && echo "  執行中 (程序存在，結束後 1 分鐘內通知結果)"
    [ -n "$FC_FAIL_SUBJECT" ] && echo "  疑似異常結束，待寄: $FC_FAIL_SUBJECT"
    if [ "${#FC_SUBJECTS[@]}" -gt 0 ]; then printf '  待通知: %s\n' "${FC_SUBJECTS[@]}"; elif [ "${FC_PROC_ALIVE:-0}" -eq 0 ] && [ -z "$FC_FAIL_SUBJECT" ]; then echo "  (無待通知結果)"; fi
  fi
  exit 0
fi

# =============================================================================
# (10) 寄信 (批次，含冷卻與上限；[CRITICAL] 卡片時主旨加字首)
# =============================================================================
MAILS_SENT=0; LAST_MAIL=0
[ -f "$LASTMAIL_FILE" ] && LAST_MAIL=$(cat "$LASTMAIL_FILE" 2>/dev/null | tr -dc '0-9'); : "${LAST_MAIL:=0}"
can_send() {
  [ "$MAILS_SENT" -ge "$MAX_MAILS_PER_RUN" ] && { log_line "INFO: 達單次寄信上限 $MAX_MAILS_PER_RUN，略過"; return 1; }
  if [ "$DRY_RUN" != "1" ] && [ $((NOW - LAST_MAIL)) -lt "$GLOBAL_COOLDOWN" ]; then log_line "INFO: 冷卻中 (距上封 $((NOW - LAST_MAIL))s < ${GLOBAL_COOLDOWN}s)，本封延到下次"; return 1; fi
  return 0
}
after_send() { MAILS_SENT=$((MAILS_SENT + 1)); LAST_MAIL=$(date +%s); write_atomic "$LASTMAIL_FILE" "$LAST_MAIL"; }
mark_sent() { local id pf pt ps pc ptl pls
  for id in "$@"; do [ -f "$COND_DIR/$id" ] || continue
    pf=$(state_get "$id" first_seen); pt=$(state_get "$id" type); ps=$(state_get "$id" severity); pc=$(state_get "$id" count); ptl=$(state_get "$id" title); pls=$(state_get "$id" last_seen)
    state_write "$id" "${pt:-STATE}" "${ps:-medium}" "${pf:-$NOW}" "$NOW" "${pc:-1}" "${ptl:-$id}" "${pls:-$NOW}"; done; }

# ---- 系統狀態判讀 (monitor --summary，只在有信要寄時產生) ----
SNAPSHOT=""; SNAPSHOT_HTML=""
if [ -n "$NEW_LIST$FIRING_LIST" ] && [ "$FREEZE" -eq 0 ]; then
  SUMMARY=$(NS_STATE_FILE="$NS_STATE_FILE" NS_COND_DIR="$COND_DIR" NS_NOW="$NOW" STATE_DIR="$STATE_DIR" bash "$MONITOR" --summary "$CONF" 2>/dev/null)
  if [ -n "$SUMMARY" ]; then
    SNAPSHOT=$'\n【系統狀態判讀】\n'
    SNAPSHOT_HTML='<div style="margin-top:16px"><div style="font-weight:bold;margin-bottom:6px">系統狀態判讀</div><table cellspacing="0" cellpadding="0" style="border-collapse:collapse;width:100%;font-size:13px">'
    while IFS='|' read -r st dim desc; do
      [ -z "$dim" ] && continue
      case "$st" in
        ok)  SNAPSHOT+="  ✓ 正常  $dim: $desc"$'\n'; SNAPSHOT_HTML+='<tr><td style="padding:6px 10px;border:1px solid #e0e0e0;white-space:nowrap;color:#188038;font-weight:bold">✓ 正常</td><td style="padding:6px 10px;border:1px solid #e0e0e0;white-space:nowrap;font-weight:bold">'"$(html_escape "$dim")"'</td><td style="padding:6px 10px;border:1px solid #e0e0e0;color:#3c4043">'"$(html_escape "$desc")"'</td></tr>' ;;
        bad) SNAPSHOT+="  ✗ 異常  $dim: $desc"$'\n'; SNAPSHOT_HTML+='<tr style="background:#fdf6f6"><td style="padding:6px 10px;border:1px solid #e0e0e0;white-space:nowrap;color:#d93025;font-weight:bold">✗ 異常</td><td style="padding:6px 10px;border:1px solid #e0e0e0;white-space:nowrap;font-weight:bold">'"$(html_escape "$dim")"'</td><td style="padding:6px 10px;border:1px solid #e0e0e0;color:#3c4043">'"$(html_escape "$desc")"'</td></tr>' ;;
        *)   SNAPSHOT+="  ・參考  $dim: $desc"$'\n'; SNAPSHOT_HTML+='<tr><td style="padding:6px 10px;border:1px solid #e0e0e0;white-space:nowrap;color:#5f6368">・參考</td><td style="padding:6px 10px;border:1px solid #e0e0e0;white-space:nowrap;font-weight:bold">'"$(html_escape "$dim")"'</td><td style="padding:6px 10px;border:1px solid #e0e0e0;color:#3c4043">'"$(html_escape "$desc")"'</td></tr>' ;;
      esac
    done < <(printf '%s\n' "$SUMMARY")
    SNAPSHOT_HTML+='</table></div>'
  fi
fi
HOST=$(hostname 2>/dev/null || echo "?")
if [ "${REALERT_INTERVAL:-0}" -eq 0 ]; then REALERT_DESC="不重複提醒"
elif [ "$REALERT_INTERVAL" -ge 3600 ]; then REALERT_DESC="每 $((REALERT_INTERVAL/3600)) 小時提醒一次直到解除"
else REALERT_DESC="每 $((REALERT_INTERVAL/60)) 分鐘提醒一次直到解除"; fi
SUBJ="$ENV_NAME"; [ -n "${HOST_ROLE:-}" ] && SUBJ="$ENV_NAME·$HOST_ROLE"
CONF_ABS="$(cd "$(dirname "$CONF")" 2>/dev/null && pwd)/$(basename "$CONF")"
CMD_STATUS="sudo bash $SCRIPT_DIR/nimoshake-alert.sh --status $CONF_ABS"
CMD_REPORT="sudo bash $SCRIPT_DIR/nimoshake-monitor.sh --human $CONF_ABS"
FOOT=$'\n---\n環境: '"$SUBJ"$'  主機: '"$HOST"$'\nNimoShake: '"$INSTALL_DIR"$'  階段: '"${PHASE:-?}"$'  runId: '"${RUNID:0:8}"$'\n時間: '"$(date '+%F %T %Z')"$'\n\n【快速指令】(登入主機後可直接複製執行)\n  查目前所有告警狀態:  '"$CMD_STATUS"$'\n  看完整監控報表:      '"$CMD_REPORT"$'\n\n【信件說明】🔴新增=剛發生 / 🟠持續='"$REALERT_DESC"$' / 🟢已解除=已恢復無需處理\n同一問題只通知一次不重複轟炸；事件型異常只在新增時通知 (保留 '"$((EVENT_HOLD_SEC/60))"$' 分鐘內再出現不重寄)。\n(本信由 nimoshake-alert.sh v5.0 自動發送；信件只含數字與代碼，不含 log 原文)'
FOOT_HTML='<div style="color:#80868b;font-size:12px;border-top:1px solid #e0e0e0;margin-top:18px;padding-top:10px;line-height:1.7">環境: <b>'"$(html_escape "$SUBJ")"'</b>　主機: '"$(html_escape "$HOST")"'　時間: '"$(date '+%F %T %Z')"'<br>NimoShake: <code>'"$(html_escape "$INSTALL_DIR")"'</code>　階段: '"$(html_escape "${PHASE:-?}")"'　runId: '"${RUNID:0:8}"'<br><br><b>快速指令</b>（登入主機後可直接複製執行）<br>查目前所有告警狀態: <code style="word-break:break-all">'"$(html_escape "$CMD_STATUS")"'</code><br>看完整監控報表: <code style="word-break:break-all">'"$(html_escape "$CMD_REPORT")"'</code><br><br>🔴新增=剛發生／🟠持續='"$REALERT_DESC"'／🟢已解除=已恢復無需處理<br>同一問題只通知一次不重複轟炸；事件型異常只在新增時通知。（本信由 nimoshake-alert.sh v5.0 自動發送；信件只含數字與代碼，不含 log 原文）</div>'
html_mail() { local snap=""; [ "${3:-0}" = "1" ] && snap="$SNAPSHOT_HTML"
  printf '<div style="font-family:-apple-system,%s,Arial,sans-serif;font-size:14px;color:#202124;max-width:860px"><div style="margin:0 0 12px;color:#3c4043">%s</div>%s%s%s</div>' "'Microsoft JhengHei','PingFang TC'" "$(html_escape "$1")" "$2" "$snap" "$FOOT_HTML"; }
crit_prefix() { printf '%s' "$1" | LC_ALL=C grep -qF '[CRITICAL]' && printf '[CRITICAL] '; }

if [ -n "$NEW_LIST" ] && can_send; then
  n=$(printf '%s' "$NEW_LIST" | grep -c '^■')
  if sendgrid_send "$(crit_prefix "$NEW_LIST")【StarCo $SUBJ】🔴 新增 $n 項告警" "偵測到新的異常狀況:"$'\n\n'"$NEW_LIST$SNAPSHOT$FOOT" "$(html_mail "偵測到新的異常狀況，每項附處理方式：" "$NEW_HTML" 1)"; then
    after_send; mark_sent $NEW_IDS; fi
fi
if [ -n "$RESOLVED_LIST" ] && can_send; then
  n=$(printf '%s' "$RESOLVED_LIST" | grep -c '^■')
  if sendgrid_send "【StarCo $SUBJ】🟢 已解除 $n 項" "以下狀況已恢復正常:"$'\n\n'"$RESOLVED_LIST$FOOT" "$(html_mail "以下狀況已恢復正常：" "$RESOLVED_HTML" 0)"; then
    after_send; for id in $RESOLVED_IDS; do rm -f "$COND_DIR/$id" 2>/dev/null || true; done; fi
fi
if [ -n "$FIRING_LIST" ] && can_send; then
  n=$(printf '%s' "$FIRING_LIST" | grep -c '^■')
  if sendgrid_send "$(crit_prefix "$FIRING_LIST")【StarCo $SUBJ】🟠 持續未解除 $n 項 (提醒)" "以下狀況仍未解除:"$'\n\n'"$FIRING_LIST$SNAPSHOT$FOOT" "$(html_mail "以下狀況仍未解除，請儘速處理：" "$FIRING_HTML" 1)"; then
    after_send; mark_sent $FIRING_DUE_IDS; fi
fi
fc_i=0
while [ "$fc_i" -lt "${#FC_IDS[@]}" ]; do
  if can_send && sendgrid_send "${FC_SUBJECTS[$fc_i]}" "${FC_BODIES[$fc_i]}" "${FC_HTMLS[$fc_i]}"; then after_send; printf '%s\n' "${FC_IDS[$fc_i]}" >> "$FC_SEEN_FILE" 2>/dev/null || true; fi
  fc_i=$((fc_i + 1))
done
if [ -n "$FC_FAIL_SUBJECT" ] && can_send; then
  if sendgrid_send "$FC_FAIL_SUBJECT" "$FC_FAIL_BODY" "$FC_FAIL_HTML"; then after_send; rm -f "$FC_RUN_FILE" 2>/dev/null || true; fi
fi
if [ "$MAILS_SENT" -eq 0 ]; then log_line "OK: [$ENV_NAME] 本次無需寄信 (dry_run=$DRY_RUN phase=${PHASE:-?} alive=$ALIVE)"
else log_line "DONE: [$ENV_NAME] 本次寄出/處理 $MAILS_SENT 封 (dry_run=$DRY_RUN)"; fi
date +%s > "$STATE_DIR/.heartbeat" 2>/dev/null || true
exit 0
