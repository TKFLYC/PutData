#!/bin/bash
# =============================================================================
# lib/resume-lib.sh (OPAPP 1.0.16c 專用, v5.0) — log / .output / 狀態檔 讀取共用函式
# -----------------------------------------------------------------------------
# 由 nimoshake-monitor.sh 與 nimoshake-alert.sh 共同 source。所有讀 log 的管線都符合
# YC 規格 §8.1 #1: (a) 比對前先 grep -avF ' configuration: '，或 (b) 第一個比對式是
# 附錄 A 的錨定 ERE、之後只用 -o 取固定欄位。原始段落只放在變數裡，用
# printf '%s\n' "$X" | ... 處理，不用 here-string / here-doc，不寫暫存檔。
# 時間換算一律 gawk mktime (TZ=UTC)，不用 date -d (出錯會把參數回顯到 stderr)。
# =============================================================================
# shellcheck disable=SC2034

RESUME_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=ere.sh
. "$RESUME_LIB_DIR/ere.sh"
AWK_BATCHES="$RESUME_LIB_DIR/batches.awk"
AWK_DELTA="$RESUME_LIB_DIR/delta.awk"
AWK_OUTSCAN="$RESUME_LIB_DIR/out_scan.awk"
AWK_NSSTATE="$RESUME_LIB_DIR/ns_state.awk"

# gawk 確認 (mktime/strftime/RT/ARGIND 都是 gawk 才有)
GAWK=""
for _g in gawk awk; do
  if command -v "$_g" >/dev/null 2>&1 && "$_g" --version 2>/dev/null | head -1 | grep -q 'GNU Awk'; then GAWK="$_g"; break; fi
done
[ -z "$GAWK" ] && { echo "[FATAL] 需要 gawk (GNU Awk)；請先安裝: yum install gawk / apt install gawk" >&2; exit 3; }

# ---- 時間 ----------------------------------------------------------------------
now_epoch() { if [ -n "${NS_NOW:-}" ]; then printf '%s' "$NS_NOW"; else date +%s; fi }   # NS_NOW: 重播測試用，固定「現在」
fmt_epoch() { # epoch -> "YYYY/MM/DD HH:MM:SS UTC"；空值印 "-"
  local e; e=$(printf '%s' "${1:-}" | tr -dc '0-9'); [ -z "$e" ] && { printf -- '-'; return; }
  TZ=UTC "$GAWK" -v e="$e" 'BEGIN{ print strftime("%Y/%m/%d %H:%M:%S UTC", e, 1) }'
}
fmt_hms() { # epoch -> "HH:MM:SS" (UTC)
  local e; e=$(printf '%s' "${1:-}" | tr -dc '0-9'); [ -z "$e" ] && { printf -- '-'; return; }
  TZ=UTC "$GAWK" -v e="$e" 'BEGIN{ print strftime("%H:%M:%S", e, 1) }'
}
human_secs() { # 秒 -> 人類可讀
  local s="${1:-0}"; s=$(printf '%s' "$s" | tr -dc '0-9'); : "${s:=0}"
  if   [ "$s" -lt 60 ];   then echo "${s}秒"
  elif [ "$s" -lt 3600 ]; then echo "$((s/60))分$((s%60))秒"
  elif [ "$s" -lt 86400 ]; then echo "$((s/3600))時$(((s%3600)/60))分"
  else echo "$((s/86400))天$(((s%86400)/3600))時"; fi
}
prefix_epoch() { # "YYYY/MM/DD HH:MM:SS" (19 字) -> epoch；格式不符印空
  printf '%s\n' "${1:-}" | LC_ALL=C grep -aoE '^[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}' \
    | TZ=UTC "$GAWK" '{ d=$0; gsub(/[\/:]/," ",d); print mktime(d) }'
}
file_mtime() { stat -c %Y "$1" 2>/dev/null || echo 0; }

# ---- 存活 (YC 規格 §6.5 alive_pid；/proc/<pid>/exe 指向安裝目錄的執行檔才算) -------
# NS_TEST_ALIVE=0|1: 重播測試用覆寫 (沒有 Linux /proc 的環境)；正式機不要設
alive_pid() {
  if [ -n "${NS_TEST_ALIVE:-}" ]; then [ "$NS_TEST_ALIVE" = "1" ] && echo 99999; return; fi
  local f p exe="$INSTALL_DIR/nimo-shake.linux"
  for f in "$INSTALL_DIR/nimo-shake.pid" "$INSTALL_DIR"/*.pid; do
    [ -f "$f" ] || continue; p=$(tr -dc '0-9' < "$f")
    [ -n "$p" ] && case "$(readlink "/proc/$p/exe" 2>/dev/null)" in "$exe"*) echo "$p"; return;; esac
  done
  for p in /proc/[0-9]*; do case "$(readlink "$p/exe" 2>/dev/null)" in "$exe"*) echo "${p#/proc/}"; return;; esac; done
}
pid_files_present() { # 任一 pid 檔存在 -> 0
  local f; for f in "$INSTALL_DIR/nimo-shake.pid" "$INSTALL_DIR"/*.pid; do [ -f "$f" ] && return 0; done; return 1
}

# ---- log 檔尾半行長度 (offset 只推進到最後一個完整行；tac 的第一行要去掉這段) ----------
tail_partial_len() { # file -> 檔尾沒有換行結尾的位元組數 (最多看最後 1MB)
  [ -r "$1" ] || { echo 0; return; }
  tail -c 1048576 "$1" 2>/dev/null | LC_ALL=C "$GAWK" 'BEGIN{RS="\n"} {l=length($0); r=RT} END{ print (r=="" ? l+0 : 0) }'
}
done_bytes() { # file offset size -> 從 offset 起算、完整行的位元組數
  tail -c +$(($2+1)) "$1" | head -c $(($3-$2)) | LC_ALL=C "$GAWK" 'BEGIN{RS="\n"} RT!=""{n+=length($0)+1} END{print n+0}'
}
seg() { # file offset len -> 印出該段的「有前綴行」(去 NUL、去 configuration 行)
  tail -c +$(($2+1)) "$1" | head -c "$3" | tr -d '\000' | LC_ALL=C grep -avF ' configuration: ' | LC_ALL=C grep -aE "$P"
}

# ---- 最近 RECENT_SEC 秒的行 (每輪只讀一次；新到舊；tac 直接讀檔不接管線) -----------------
# 填 RECENT (變數)；LOG_PLEN 可由呼叫端先算 (alert)，否則用 tail_partial_len
load_recent() { # [plen]
  local plen="${1:-}"; [ -z "$plen" ] && plen=$(tail_partial_len "$LOG_FILE")
  RECENT=""
  [ -r "$LOG_FILE" ] || return 1
  RECENT=$(tac "$LOG_FILE" | LC_ALL=C "$GAWK" -v p="$plen" 'NR==1&&p>0{$0=substr($0,p+1)} 1' | tr -d '\000' \
    | LC_ALL=C grep -avF ' configuration: ' | LC_ALL=C grep -aE "$P" \
    | TZ=UTC LC_ALL=C "$GAWK" -v now="$NOW" -v w="$RECENT_SEC" '{d=substr($0,2,19); gsub(/[\/:]/," ",d); if (now-mktime(d)>w) exit; print}')
  return 0
}
recent_window() { # 秒 -> 印出 RECENT 中最近 N 秒的行 (新到舊)
  [ -z "$RECENT" ] && return 0
  printf '%s\n' "$RECENT" | TZ=UTC LC_ALL=C "$GAWK" -v now="$NOW" -v w="$1" \
    '{d=substr($0,2,19); gsub(/[\/:]/," ",d); if (now-mktime(d)>w) exit; print}'
}
win_count() { # ERE 秒 -> 最近 N 秒內命中的行數
  local n; n=$(recent_window "$2" | LC_ALL=C grep -acE "$1"); echo "${n:-0}"
}
recent_count() { # ERE -> RECENT 全部 (RECENT_SEC 內) 命中的行數
  [ -z "$RECENT" ] && { echo 0; return; }
  local n; n=$(printf '%s\n' "$RECENT" | LC_ALL=C grep -acE "$1"); echo "${n:-0}"
}
line_epoch() { # 一行 -> epoch (只取前綴時間欄)
  printf '%s\n' "$1" | cut -c2-20 | TZ=UTC LC_ALL=C "$GAWK" '{ d=$0; gsub(/[\/:]/," ",d); print mktime(d) }'
}

# ---- 心跳 / 時區 (§6.5) ---------------------------------------------------------
compute_hb() { # 填 HB_AGE (空=1 小時內沒有心跳) 與 HB_LAST3 (最近 3 行心跳的類型 L28/L29)
  HB_AGE=""; HB_LAST3=""
  [ -z "$RECENT" ] && return 0
  HB_AGE=$(printf '%s\n' "$RECENT" | LC_ALL=C grep -m1 -aE "$E_HB" \
    | TZ=UTC LC_ALL=C "$GAWK" -v now="$NOW" '{d=substr($0,2,19); gsub(/[\/:]/," ",d); print now-mktime(d)}')
  HB_LAST3=$(printf '%s\n' "$RECENT" | LC_ALL=C grep -aE "$E_HB" | head -3 \
    | LC_ALL=C "$GAWK" '{ print ($0 ~ / stream health unavailable /) ? "L29" : "L28" }' | paste -sd, -)
}
compute_tz() { # 填 TZ_BAD (RECENT 中前綴不是 UTC 的行數)
  TZ_BAD=0
  [ -z "$RECENT" ] && return 0
  TZ_BAD=$(printf '%s\n' "$RECENT" | LC_ALL=C grep -aE "$P" | LC_ALL=C grep -avcE "$E_UTC"); : "${TZ_BAD:=0}"
}

# ---- 批次彙總 (§6.5) ------------------------------------------------------------
compute_batches() { # 填 BATCHES (多列) 與 DELTA (一列 key=value)；dget key 取值
  BATCHES=""; DELTA="batches=0"
  [ -z "$RECENT" ] && return 0
  BATCHES=$(printf '%s\n' "$RECENT" | LC_ALL=C grep -aE "$E_BATCH" | TZ=UTC LC_ALL=C "$GAWK" -f "$AWK_BATCHES")
  DELTA=$(printf '%s\n' "$BATCHES" | LC_ALL=C "$GAWK" -v now="$NOW" -v stall="$STALL_SEC" -v idle="$CAPTURE_IDLE_SEC" -f "$AWK_DELTA")
}
dget() { printf '%s\n' "$DELTA" | LC_ALL=C grep -aoE "(^| )$1=[^ ]+" | head -1 | cut -d= -f2; }

# ---- .output 掃描 (§6.4 (3)) ----------------------------------------------------
# 用法: compute_out_scan <from_offset>  → 填 OUT_SIZE OUT_DONE OUT_SCAN；oget key 取值
compute_out_scan() {
  local from="${1:-0}"
  OUT_SIZE=0; OUT_DONE=0
  OUT_SCAN="starts=0 fatal=0 logwrite=0 unknown=0 tail_lines=0 tail_fatal=0 tail_last=-"
  [ -n "$OUTPUT_FILE" ] && [ -r "$OUTPUT_FILE" ] && OUT_SIZE=$(wc -c < "$OUTPUT_FILE" | tr -d ' ')
  [ "$OUT_SIZE" -gt 0 ] && OUT_DONE=$(done_bytes "$OUTPUT_FILE" 0 "$OUT_SIZE")
  [ "$OUT_DONE" -lt "$from" ] && from=0
  [ "$OUT_DONE" -gt 0 ] && OUT_SCAN=$(head -c "$OUT_DONE" "$OUTPUT_FILE" | tr -d '\000' | LC_ALL=C "$GAWK" -v from="$from" -f "$AWK_OUTSCAN")
  return 0
}
oget() { printf '%s\n' "$OUT_SCAN" | LC_ALL=C grep -aoE "(^| )$1=[^ ]+" | head -1 | cut -d= -f2; }
out_starts_total() { # .output 累計啟動次數 (L01 行數)
  local n=0; [ -n "$OUTPUT_FILE" ] && [ -r "$OUTPUT_FILE" ] && n=$(tr -d '\000' < "$OUTPUT_FILE" | LC_ALL=C grep -acE "$E_O_START"); echo "${n:-0}"
}

# ---- 致命退出分類代碼 (§6.4 (4))：只印代碼，不印整行 -------------------------------
fatal_code() { # $1=致命行 -> 代碼
  local c op
  c=$(printf '%s\n' "$1" | LC_ALL=C grep -aoE "$E_F_CODE" | head -1 | cut -c14-)
  if [ -n "$c" ]; then case " $FATAL_CODES " in *" $c "*) echo "$c"; return;; esac; fi
  if printf '%s\n' "$1" | LC_ALL=C grep -qaE "$E_F_BUDGET"; then
    op=$(printf '%s\n' "$1" | LC_ALL=C grep -aoE '(aws|capture|target|mongo|resume|shard|spool)\.[A-Za-z._]+: retry budget exhausted' | head -1 | cut -d: -f1)
    echo "RETRY_BUDGET_EXHAUSTED ${op:-unknown}"; return
  fi
  printf '%s\n' "$1" | LC_ALL=C grep -qaE "$E_F_PIDLOCK" && { echo MIGRATION_ALREADY_RUNNING; return; }
  printf '%s\n' "$1" | LC_ALL=C grep -qaE "$E_F_CRASH"   && { echo CRASH; return; }
  printf '%s\n' "$1" | LC_ALL=C grep -qaE "$E_F_CONF"    && { echo CONF_ERROR; return; }
  echo OTHER
}

# ---- ns_state 讀取 (monitor 只讀；alert 寫) ----------------------------------------
ns_get() { # key -> 值 (沒有印空)
  [ -n "${NS_STATE_FILE:-}" ] && [ -f "$NS_STATE_FILE" ] || return 0
  LC_ALL=C "$GAWK" -F '\t' -v k="$1" '$1==k { print $2; exit }' "$NS_STATE_FILE"
}

# ---- conf 白名單鍵 (§8.2 #2：只讀 E_CONF_WL 命中的鍵) ----------------------------------
conf_wl() { # 印出 "key=value" 多行 (去空白)；conf 不可讀印空
  [ -n "$NIMO_CONF" ] && [ -r "$NIMO_CONF" ] || return 0
  LC_ALL=C grep -aE "$E_CONF_WL" "$NIMO_CONF" | LC_ALL=C sed -E 's/[[:space:]]*=[[:space:]]*/=/; s/[[:space:]]+$//'
}
conf_wl_get() { conf_wl | LC_ALL=C grep -aE "^$1=" | head -1 | cut -d= -f2-; }

# ---- 停機原因 (§6.5；程序不在時每輪由檔案重算) ----------------------------------------
# 需要: RECENT、OUT_SCAN、NS_STATE_FILE。印出 BLOCKED / FATAL / PLANNED / CRASH
stop_reason() {
  local tail_fatal tail_last tail_lines blk=0
  if [ "$(ns_get phase)" = "BLOCKED" ]; then blk=1
  elif [ -n "$RECENT" ]; then
    # LOG_TAIL = 目前檔最後一個 E_START 之後的內容 (RECENT 新到舊，讀到 E_START 就停)
    blk=$(printf '%s\n' "$RECENT" | LC_ALL=C "$GAWK" -v s="$E_START" -v b="$E_BLK" '$0 ~ s {exit} $0 ~ b {n++} END{print n+0}')
  fi
  [ "${blk:-0}" -gt 0 ] && { echo BLOCKED; return; }
  tail_fatal=$(oget tail_fatal); tail_last=$(oget tail_last); tail_lines=$(oget tail_lines)
  [ "${tail_fatal:-0}" -gt 0 ] && { echo FATAL; return; }
  [ "$tail_last" = "stop" ] && { echo PLANNED; return; }
  if ! pid_files_present && [ "${tail_lines:-0}" -eq 0 ]; then echo PLANNED; return; fi
  echo CRASH
}

# ---- Go duration -> 秒 (§6.5 dur()；"850ms"=0.85、"1h4m59.19s"=3899.19) --------------
AWK_DUR_FN='function dur(s,  t,n,u,g){g=1;if(s~/^-/){g=-1;s=substr(s,2)};t=0;while(match(s,/^[0-9.]+(h|ms|us|µs|ns|m|s)/)){n=substr(s,1,RLENGTH);u=n;sub(/^[0-9.]+/,"",u);n+=0;t+=(u=="h")?n*3600:(u=="m")?n*60:(u=="s")?n:(u=="ms")?n/1e3:(u=="ns")?n/1e9:n/1e6;s=substr(s,RLENGTH+1)};return g*t}'
dur_secs() { printf '%s\n' "${1:-0}" | LC_ALL=C "$GAWK" "$AWK_DUR_FN"'{ printf "%.1f\n", dur($0) }'; }

# ---- 系統資源 ----------------------------------------------------------------------
sys_cores() { { command -v nproc >/dev/null 2>&1 && nproc; } 2>/dev/null || echo "-"; }
sys_load1() { [ -r /proc/loadavg ] && cut -d' ' -f1 /proc/loadavg 2>/dev/null || echo ""; }
sys_mem_pct() { [ -r /proc/meminfo ] && LC_ALL=C "$GAWK" '/MemTotal/{t=$2}/MemAvailable/{a=$2}/MemFree/{f=$2}/^Buffers/{b=$2}/^Cached/{c=$2} END{if(a=="")a=f+b+c; if(t>0) printf "%d", (t-a)*100/t}' /proc/meminfo 2>/dev/null; }
sys_mem_desc() { [ -r /proc/meminfo ] && LC_ALL=C "$GAWK" '/MemTotal/{t=$2}/MemAvailable/{a=$2}/MemFree/{f=$2}/^Buffers/{b=$2}/^Cached/{c=$2} END{ if(a=="")a=f+b+c; if(t>0) printf "總 %dMB / 可用 %dMB / 使用率 %.0f%%", t/1024, a/1024, (t-a)*100/t }' /proc/meminfo 2>/dev/null || echo "-"; }
sys_disk_pct() { df -P "${INSTALL_DIR:-/}" 2>/dev/null | LC_ALL=C "$GAWK" 'NR==2{gsub("%","",$5); print $5}'; }
sys_disk_desc() { df -h "${INSTALL_DIR:-/}" 2>/dev/null | LC_ALL=C "$GAWK" 'NR==2{printf "%s 已用 (%s/%s)", $5,$3,$2}'; }
