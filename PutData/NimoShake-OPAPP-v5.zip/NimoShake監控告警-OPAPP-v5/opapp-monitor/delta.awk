# =============================================================================
# delta.awk — 由 batches.awk 的輸出 (新到舊) 算 Δ 類指標 (YC 規格 §6.5)
# 參數: -v now=<epoch> -v stall=<秒,預設 600> -v idle=<秒,CAPTURE_IDLE_SEC>
# 輸出一行 key=value:
#   batches        時間窗內批次數
#   ageSec         最新一批距今秒數 (> 90 視為過期，本輪不判 APPLY_STALL/APPLY_LAG*/BACKLOG_GROWING/CAPTURE_IDLE)
#   lagSec         最新一批 maxLagSec     lagTable 最新一批 maxLagTable
#   gapEvents      最新一批 ΣgapEvents    spool    最新一批 Σspool
#   open eof applyDone 最新一批 (eof/applyDone 由 batches.awk 未輸出 → 這裡只有 open)
#   captured applied 最新一批累計
#   applyStall     1=ΣgapEvents>0 且 Σapplied 在 stall 秒內沒增加；na=批次不足
#   applyPerSec capturePerSec  最新一批對 stall 秒前那批的速率；na=批次不足
#   backlogGrowing 1=最近 5 批 ΣgapEvents 每批都比前一批大且最新 ≥ 1000
#   backlogAnyGrow 1=最近 5 批有任一批比前一批大 (BACKLOG_GROWING 的解除門檻用：0 才解除)
#   captureIdle    1=Σcaptured 與 idle 秒前那批相同；na=批次不足
#   retry3         1=最近 3 批 retryBusy 都 > 0
#   retryNone3     1=最近 3 批 retryBusy 都 = 0 (STREAM_RETRY 解除門檻用)
#   reads writes   最新一批 L28 的 reads/writes
# 相對 YC 原稿的增補: lagTable/spool/open/captured/applied/reads/writes/backlogAnyGrow/retryNone3
# (報表顯示與解除門檻需要)，計算邏輯不變。
# =============================================================================
NR == 1 { t1 = $1; o1 = $3; s1 = $4; g1 = $5; c1 = $6; a1 = $7; lag = $8; lagt = $9; rd = $11; wr = $12
          grow = 1; anygrow = 0; pg = $5; r3 = ($10 > 0); rn3 = ($10 == 0) }
NR >= 2 && NR <= 5 { if (!($5 < pg)) grow = 0; if ($5 < pg) anygrow = 1; pg = $5 }
NR >= 2 && NR <= 3 { if ($10 == 0) r3 = 0; if ($10 > 0) rn3 = 0 }
NR >= 2 && sa == "" && t1 - $1 >= stall { d = t1 - $1; da = a1 - $7; dc = c1 - $6
  if (da < 0 || dc < 0) { da = 0; dc = 0 }          # 新的一輪，計數重來
  sa = (g1 > 0 && da == 0); ar = da / d; cr = dc / d }
NR >= 2 && ci == "" && t1 - $1 >= idle { ci = (c1 == $6) }
END { if (NR == 0) { print "batches=0"; exit }
  printf "batches=%d ageSec=%d lagSec=%.1f lagTable=%s gapEvents=%d spool=%d open=%d captured=%d applied=%d applyStall=%s applyPerSec=%s capturePerSec=%s backlogGrowing=%d backlogAnyGrow=%d captureIdle=%s retry3=%d retryNone3=%d reads=%d writes=%d\n",
    NR, now - t1, lag, lagt, g1, s1, o1, c1, a1, (sa == "" ? "na" : sa), (sa == "" ? "na" : sprintf("%.1f", ar)), (sa == "" ? "na" : sprintf("%.1f", cr)),
    (NR >= 5 && grow && g1 >= 1000), (NR >= 5 ? anygrow : 0), (ci == "" ? "na" : ci), (NR >= 3 && r3), (NR >= 3 && rn3), rd, wr }
