#!/bin/bash
# =============================================================================
# test/run-condition-tests.sh — 逐條告警條件的「觸發 / 解除 / 維持」測試 (補 run-replay-tests.sh 沒蓋到的 ID)
# 用法: bash test/run-condition-tests.sh [工作目錄]   (預設 /tmp/nsr-cond；會先清掉)
# 做法: 每個案例造一份極小的 log / .output / ns_state / cond，用固定的 NS_NOW 跑
#       nimoshake-monitor.sh --conditions (STATE) 或 nimoshake-alert.sh (EVENT)，檢查條件 ID 有/無。
# =============================================================================
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
W="${1:-/tmp/nsr-cond}"; rm -rf "$W"; mkdir -p "$W"
NOW=$(date +%s); export NS_NOW=$NOW
RID=7ef5a8464664c6f678622189b1b2db61
PASS=0; FAIL=0
ok(){ echo "  PASS: $*"; PASS=$((PASS+1)); }; bad(){ echo "  FAIL: $*"; FAIL=$((FAIL+1)); }
ts(){ TZ=UTC gawk -v e="$1" 'BEGIN{ print "[" strftime("%Y/%m/%d %H:%M:%S UTC", e, 1) "]" }'; }
TABLES="t01 t02 t03"
# ---- 案例環境 ----
C=""   # 目前案例目錄
mk(){ C="$W/$1"; mkdir -p "$C/nimo/logs" "$C/mon/state/cond"; : > "$C/nimo/logs/nimo-shake.log"; : > "$C/nimo/nimo-shake.linux.output"
  printf '%s\n' 'sync_mode = all' 'full.read.concurrency = 8' > "$C/nimo/nimo-shake.conf"; printf '1\n' > "$C/nimo/nimo-shake.pid"
  printf '%s\n' 'ENV_NAME="OPAPP"' "INSTALL_DIR=\"$C/nimo\"" 'MAIL_FROM="a@b"' 'MAIL_TO="c@d"' 'DRY_RUN=1' 'DRY_RUN_DUMP=1' 'TOTAL_TABLES=3' \
    'RULES_SHA256="d1a0498d4022cf1c60e3b807e6c95abc275bce815c47cc4a574f822ca1ce2156"' 'TABLE_TOTALS="t01:1000,t02:1000,t03:1000"' > "$C/mon/opapp.conf"
  echo "== $1"; }
L(){ echo "$(ts $((NOW + $1))) [$2] $3" >> "$C/nimo/logs/nimo-shake.log"; }          # L <offset秒> <LEVEL> <msg>
O(){ printf '%s\n' "$1" >> "$C/nimo/nimo-shake.linux.output"; }
ns(){ while [ $# -gt 0 ]; do printf '%s\t%s\n' "$1" "$2" >> "$C/mon/state/ns_state"; shift 2; done; }
cond(){ printf 'type\tSTATE\nseverity\t%s\nfirst_seen\t%s\nlast_sent\t%s\ncount\t1\ntitle\t%s\nlast_seen\t%s\n' "${2:-high}" "$NOW" "$NOW" "${3:-$1}" "$NOW" > "$C/mon/state/cond/$1"; }   # cond ID [sev] [title]
batch(){ # batch <offset> <gap> <captured> <applied> [retryStatus] [lag]
  local t; for t in $TABLES; do L "$1" INFO "resume streams table=$t open=4 EOF=10 applyDone=10 spool=$2 oldestUnappliedAge=${6:-0s} captured=$3 applied=$4 gapEvents=$2 retryStatus=${5:-idle}"; done
  L "$1" INFO "resume checkpoint IO interval=30s reads=10 writes=1"; }
hb(){ local o=$1; while [ "$o" -le -30 ]; do batch "$o" 0 100 100; o=$((o+30)); done; }   # 從 offset 起每 30 秒一批到 now-30
conds(){ NS_STATE_FILE="$C/mon/state/ns_state" NS_COND_DIR="$C/mon/state/cond" NS_TEST_ALIVE="${ALIVE:-1}" bash "$HERE/nimoshake-monitor.sh" --conditions "$C/mon/opapp.conf" 2>/dev/null; }
has(){ printf '%s' "$1" | grep -q "|$2|"; }
expect(){ # expect "<conds>" ID yes|no [desc]
  if [ "$3" = yes ]; then has "$1" "$2" && ok "$2 成立 ${4:-}" || bad "$2 應成立但沒有 ${4:-}"
  else has "$1" "$2" && bad "$2 不應成立 ${4:-}" || ok "$2 不成立 ${4:-}"; fi; }
alert(){ NS_TEST_ALIVE="${ALIVE:-1}" bash "$HERE/nimoshake-alert.sh" "$C/mon/opapp.conf" >/dev/null 2>&1; }
cf(){ [ -f "$C/mon/state/cond/$1" ]; }

# ======================= STATE 條件 (monitor --conditions) =======================
mk HEARTBEAT; ns phase LIVE start_ts $((NOW-2000)) live_ts $((NOW-2000)) runid $RID absent_runs 0
batch -300 0 100 100; R=$(conds); expect "$R" HEARTBEAT_LOST yes "(心跳 300 秒)"; expect "$R" HEARTBEAT_LOST_LONG no
mk HEARTBEAT_LONG; ns phase LIVE start_ts $((NOW-2000)) live_ts $((NOW-2000)) absent_runs 0
batch -700 0 100 100; R=$(conds); expect "$R" HEARTBEAT_LOST yes; expect "$R" HEARTBEAT_LOST_LONG yes "(700 秒)"
mk HEARTBEAT_GRACE; ns phase STARTING start_ts $((NOW-100)) absent_runs 0
R=$(conds); expect "$R" HEARTBEAT_LOST no "(啟動 100 秒內寬限)"
mk HEARTBEAT_NONE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0
R=$(conds); expect "$R" HEARTBEAT_LOST_LONG yes "(1 小時內無心跳 → 當 RECENT_SEC)"

mk STOP_LONG; ALIVE=0; ns phase LIVE run_phase LIVE absent_runs 3 stopped_since $((NOW-50000)); O "max process: 256"; O "stopped by signal"; rm -f "$C/nimo/nimo-shake.pid"
R=$(conds); expect "$R" PLANNED_STOP yes; expect "$R" STOP_LONG yes "(13.9 小時)"; expect "$R" STOP_TOO_LONG no; expect "$R" PROCESS_DOWN no
mk STOP_TOO_LONG; ALIVE=0; ns phase LIVE run_phase LIVE absent_runs 3 stopped_since $((NOW-80000)); O "max process: 256"; O "sync failed: STREAM_GAP: x"
R=$(conds); expect "$R" STOP_TOO_LONG yes; expect "$R" PROCESS_DOWN yes "(FATAL)"
mk FULL_SYNC_INCOMPLETE; ALIVE=0; ns phase SCANNING run_phase SCANNING absent_runs 2 stopped_since $((NOW-100)) fin_tables t01 fin_count 1 run_tables 3; O "max process: 256"; O "sync failed: FINGERPRINT_MISMATCH: x"
R=$(conds); expect "$R" FULL_SYNC_INCOMPLETE yes; expect "$R" PROCESS_DOWN no "(互斥)"
mk CRASH_REASON; ALIVE=0; ns phase LIVE run_phase LIVE absent_runs 2 stopped_since $((NOW-100)); O "max process: 256"
R=$(conds); expect "$R" PROCESS_DOWN yes "(pid 檔在、無致命行 → CRASH)"; printf '%s' "$R" | grep -q "CRASH" && ok "停機原因 CRASH" || bad "停機原因應為 CRASH"
mk ABSENT1; ALIVE=0; ns phase LIVE run_phase LIVE absent_runs 1 stopped_since $((NOW-100)); O "max process: 256"
R=$(conds); expect "$R" PROCESS_DOWN no "(absent_runs=1 不判)"
ALIVE=1

mk BOOTSTRAP_STUCK; ns phase PREPARING start_ts $((NOW-1300)) absent_runs 0
L -60 WARN "capture bootstrap waiting runId=$RID ready=777/779 waited=21m10s; waiting"; R=$(conds); expect "$R" BOOTSTRAP_STUCK yes
mk BOOTSTRAP_OK; ns phase PREPARING start_ts $((NOW-400)) absent_runs 0
L -60 WARN "capture bootstrap waiting runId=$RID ready=500/779 waited=5m10s; waiting"; R=$(conds); expect "$R" BOOTSTRAP_STUCK no
mk BOOTSTRAP_RELEASE; ns phase SCANNING start_ts $((NOW-3000)) absent_runs 0; cond BOOTSTRAP_STUCK
L -300 WARN "capture bootstrap waiting runId=$RID ready=777/779 waited=21m10s; waiting"; hb -600; R=$(conds); expect "$R" BOOTSTRAP_STUCK no "(120 秒內無 L18 → 解除)"

mk FULL_STALL; ns phase SCANNING start_ts $((NOW-3000)) absent_runs 0 run_tables 3
L -700 INFO "resume health runId=$RID table=t01 elapsed=10m0s committedPages=100 committedItems=100000 committedDocs=100000 physicalWriteAttempts=1000"
L -30 INFO "resume health runId=$RID table=t01 elapsed=20m0s committedPages=100 committedItems=100000 committedDocs=100000 physicalWriteAttempts=1000"; hb -700
R=$(conds); expect "$R" FULL_STALL yes
mk FULL_STALL_PROGRESS; ns phase SCANNING start_ts $((NOW-3000)) absent_runs 0 run_tables 3; cond FULL_STALL
L -700 INFO "resume health runId=$RID table=t01 elapsed=10m0s committedPages=100 committedItems=100000 committedDocs=100000 physicalWriteAttempts=1000"
L -30 INFO "resume health runId=$RID table=t01 elapsed=20m0s committedPages=101 committedItems=101000 committedDocs=101000 physicalWriteAttempts=1010"; hb -700
R=$(conds); expect "$R" FULL_STALL no "(頁數增加 → 解除)"
mk FULL_STALL_HOLD; ns phase SCANNING start_ts $((NOW-3000)) absent_runs 0 run_tables 3; cond FULL_STALL high "全量掃描停滯 (600 秒沒有新頁落盤): t01"; hb -700
R=$(conds); expect "$R" FULL_STALL yes "(t01 沒有可判的 L23、也沒完成 → 維持)"
mk FULL_STALL_HOLD_OLDFMT; ns phase SCANNING start_ts $((NOW-3000)) absent_runs 0 run_tables 3; cond FULL_STALL; hb -700
R=$(conds); expect "$R" FULL_STALL yes "(舊格式條件檔無表名、無可判 L23 → 維持)"
mk FULL_STALL_FIN_ONLY; ns phase SCANNING start_ts $((NOW-3000)) absent_runs 0 run_tables 3 fin_tables t01; cond FULL_STALL high "全量掃描停滯 (600 秒沒有新頁落盤): t01"; hb -700
R=$(conds); expect "$R" FULL_STALL no "(停滯的 t01 已出現 L26、沒有其他 L23 → 解除)"
mk FULL_STALL_MIXED; ns phase SCANNING start_ts $((NOW-3000)) absent_runs 0 run_tables 3 fin_tables t01; cond FULL_STALL high "全量掃描停滯 (600 秒沒有新頁落盤): t01,t02"; hb -700
R=$(conds); expect "$R" FULL_STALL yes "(t01 完成但 t02 無資料 → 只為 t02 維持)"; printf '%s' "$R" | grep -q ': t02|' && ok "TITLE 只剩 t02" || bad "TITLE 應只剩 t02"
mk FULL_STALL_FIN; ns phase SCANNING start_ts $((NOW-3000)) absent_runs 0 run_tables 3 fin_tables t01; cond FULL_STALL high "全量掃描停滯 (600 秒沒有新頁落盤): t01"
L -700 INFO "resume health runId=$RID table=t02 elapsed=10m0s committedPages=4 committedItems=4000 committedDocs=4000 physicalWriteAttempts=40"
L -30 INFO "resume health runId=$RID table=t02 elapsed=20m0s committedPages=5 committedItems=5000 committedDocs=5000 physicalWriteAttempts=50"; hb -700
R=$(conds); expect "$R" FULL_STALL no "(其他表有進展、t01 已完成 → 解除)"

mk APPLY_STALL; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0
o=-700; while [ $o -le -30 ]; do batch $o 50 200 150; o=$((o+30)); done; R=$(conds); expect "$R" APPLY_STALL yes
mk APPLY_STALL_HOLD; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond APPLY_STALL
batch -200 50 200 150; R=$(conds); expect "$R" APPLY_STALL yes "(最新一批過期 200 秒 → 維持，不解除)"
mk APPLY_STALL_STALE_NOCOND; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0
batch -200 50 200 150; R=$(conds); expect "$R" APPLY_STALL no "(過期且先前未成立 → 不新增)"
mk APPLY_STALL_RELEASE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond APPLY_STALL
o=-700; a=150; while [ $o -le -30 ]; do batch $o 50 200 $a; a=$((a+1)); o=$((o+30)); done; R=$(conds); expect "$R" APPLY_STALL no "(applied 增加 → 解除)"

mk APPLY_LAG; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0
batch -30 10 200 190 idle 6m40s; R=$(conds); expect "$R" APPLY_LAG yes "(400 秒)"; expect "$R" APPLY_LAG_HIGH no
mk APPLY_LAG_HIGH; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0
batch -30 10 200 190 idle 33m20s; R=$(conds); expect "$R" APPLY_LAG yes; expect "$R" APPLY_LAG_HIGH yes "(2000 秒)"
mk APPLY_LAG_GRACE; ns phase LIVE start_ts $((NOW-100)) live_ts $((NOW-100)) absent_runs 0
batch -30 10 200 190 idle 33m20s; R=$(conds); expect "$R" APPLY_LAG no "(寬限中)"
mk APPLY_LAG_GRACE_HOLD; ns phase LIVE start_ts $((NOW-100)) live_ts $((NOW-100)) absent_runs 0; cond APPLY_LAG medium
batch -30 10 200 190 idle 33m20s; R=$(conds); expect "$R" APPLY_LAG yes "(寬限中但先前成立 → 維持)"
mk APPLY_LAG_HYST; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond APPLY_LAG medium
batch -30 10 200 190 idle 3m20s; R=$(conds); expect "$R" APPLY_LAG yes "(200 秒 ≥ 解除門檻 150 → 仍成立)"
mk APPLY_LAG_RELEASE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond APPLY_LAG medium
batch -30 10 200 190 idle 100s; R=$(conds); expect "$R" APPLY_LAG no "(100 秒 < 150 → 解除)"

mk BACKLOG_GROWING; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0
g=1000; for o in -150 -120 -90 -60 -30; do batch $o $g 5000 $((5000-g)); g=$((g+100)); done; R=$(conds); expect "$R" BACKLOG_GROWING yes
mk BACKLOG_FLAT; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond BACKLOG_GROWING medium
for o in -150 -120 -90 -60 -30; do batch $o 1400 5000 3600; done; R=$(conds); expect "$R" BACKLOG_GROWING no "(5 批無上升 → 解除)"
mk BACKLOG_HOLD_FEW; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond BACKLOG_GROWING medium
for o in -60 -30; do batch $o 1400 5000 3600; done; R=$(conds); expect "$R" BACKLOG_GROWING yes "(只有 2 批 → 無法判「5 批都沒上升」→ 維持)"
mk BACKLOG_HOLD_STALE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond BACKLOG_GROWING medium
for o in -300 -270 -240 -210 -180; do batch $o 1400 5000 3600; done; R=$(conds); expect "$R" BACKLOG_GROWING yes "(最新一批過期 → 維持)"
mk BACKLOG_STILL; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond BACKLOG_GROWING medium
for o in -150 -120 -90 -60; do batch $o 1400 5000 3600; done; batch -30 1500 5100 3600; R=$(conds); expect "$R" BACKLOG_GROWING yes "(5 批中有 1 批上升 → 仍成立)"

mk CAPTURE_IDLE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0
o=-2000; while [ $o -le -30 ]; do batch $o 0 777 777; o=$((o+30)); done; R=$(conds); expect "$R" CAPTURE_IDLE yes "(captured 2000 秒不變)"
mk CAPTURE_ACTIVE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond CAPTURE_IDLE medium
o=-2000; c=777; while [ $o -le -30 ]; do batch $o 0 $c $c; c=$((c+1)); o=$((o+30)); done; R=$(conds); expect "$R" CAPTURE_IDLE no "(captured 增加 → 解除)"

mk STREAM_RETRY; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0
for o in -90 -60 -30; do batch $o 0 100 100 "capture.records:attempt=3,elapsed=4.1s,code=LimitExceededException"; done; R=$(conds); expect "$R" STREAM_RETRY yes
mk STREAM_RETRY_HOLD; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond STREAM_RETRY medium
batch -30 0 100 100; R=$(conds); expect "$R" STREAM_RETRY yes "(批次不足 3 → 維持)"
mk STREAM_RETRY_RELEASE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond STREAM_RETRY medium
hb -120; R=$(conds); expect "$R" STREAM_RETRY no "(3 批都 idle → 解除)"

mk STREAM_HEALTH; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0
for o in -90 -60 -30; do L $o WARN "stream health unavailable retryStatus=idle: context deadline exceeded"; done; R=$(conds); expect "$R" STREAM_HEALTH_UNAVAILABLE yes
mk STREAM_HEALTH_RELEASE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond STREAM_HEALTH_UNAVAILABLE medium
hb -120; R=$(conds); expect "$R" STREAM_HEALTH_UNAVAILABLE no

mk DISCOVERY_WAIT; ns phase SCANNING start_ts $((NOW-5000)) absent_runs 0
for i in $(seq 1 30); do L $((-i*10)) WARN "discovery/replay vector waiting >10s"; done; hb -400; R=$(conds); expect "$R" DISCOVERY_WAIT yes
mk THROTTLE_HYST; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond THROTTLE medium; hb -120
L -100 WARN "retry operation=aws.Scan class=1 code=ThrottlingException attempt=1 elapsed=1.0s nextDelay=0.5s remaining=29m59s"
R=$(conds); expect "$R" THROTTLE yes "(1 行 < 5 但先前成立 → 仍成立)"; expect "$R" RETRY_BUDGET_LOW no "(remaining 1799 秒)"

mk TZ_BAD; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond HEARTBEAT_LOST high; hb -120
echo "$(TZ=UTC gawk -v e=$((NOW-50)) 'BEGIN{ print "[" strftime("%Y/%m/%d %H:%M:%S", e, 1) " CST]" }') [INFO] resume checkpoint IO interval=30s reads=1 writes=1" >> "$C/nimo/logs/nimo-shake.log"
R=$(conds); expect "$R" LOG_TZ_UNEXPECTED yes; expect "$R" HEARTBEAT_LOST yes "(時區異常期間維持上一輪)"

# ---- 其餘條件的解除 / 遲滯 / 維持 ----
mk HEARTBEAT_RELEASE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond HEARTBEAT_LOST high; cond HEARTBEAT_LOST_LONG high
hb -120; R=$(conds); expect "$R" HEARTBEAT_LOST no "(心跳 30 秒 → 解除)"; expect "$R" HEARTBEAT_LOST_LONG no
mk STOP_RELEASE; ns phase LIVE run_phase LIVE absent_runs 0; cond PROCESS_DOWN high; cond STOP_LONG medium; cond STOP_TOO_LONG high; cond PLANNED_STOP info; hb -120
R=$(conds); for id in PROCESS_DOWN STOP_LONG STOP_TOO_LONG PLANNED_STOP; do expect "$R" $id no "(程序存活 → 解除)"; done
mk FULL_SYNC_RELEASE; ns phase SCANNING run_phase SCANNING absent_runs 0; cond FULL_SYNC_INCOMPLETE high; hb -120
R=$(conds); expect "$R" FULL_SYNC_INCOMPLETE no "(程序存活 → 解除)"
mk DISCOVERY_HYST; ns phase SCANNING start_ts $((NOW-5000)) absent_runs 0; cond DISCOVERY_WAIT medium
for i in 1 2 3; do L $((-i*10)) WARN "discovery/replay vector waiting >10s"; done; hb -400; R=$(conds); expect "$R" DISCOVERY_WAIT yes "(3 行 < 30 但先前成立 → 仍成立)"
mk DISCOVERY_RELEASE; ns phase SCANNING start_ts $((NOW-5000)) absent_runs 0; cond DISCOVERY_WAIT medium; hb -400
R=$(conds); expect "$R" DISCOVERY_WAIT no "(600 秒內 0 行 → 解除)"
mk SPOOL_HYST; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond SPOOL_GC_FAIL medium; hb -120
L -100 WARN "spool GC failed table=t01 shard=s1: err"; R=$(conds); expect "$R" SPOOL_GC_FAIL yes "(1 行 < 3 但先前成立 → 仍成立)"
mk SPOOL_RELEASE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond SPOOL_GC_FAIL medium; hb -120
L -900 WARN "spool GC failed table=t01 shard=s1: err"; R=$(conds); expect "$R" SPOOL_GC_FAIL no "(600 秒內 0 行 → 解除)"
mk BUFFER_HYST; ns phase SCANNING start_ts $((NOW-5000)) absent_runs 0; cond BUFFER_WAIT medium; hb -120
L -100 WARN "buffer reservation waiting lane=full used=1 limit=1 bytes=1 owner=table=t01 segment=3 page=17"; R=$(conds); expect "$R" BUFFER_WAIT yes "(1 行但先前成立 → 仍成立)"
mk BUFFER_RELEASE; ns phase SCANNING start_ts $((NOW-5000)) absent_runs 0; cond BUFFER_WAIT medium; hb -120
R=$(conds); expect "$R" BUFFER_WAIT no "(0 行 → 解除)"
mk CONN_HYST; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond CONN_ERROR medium; hb -120
L -100 WARN "retry operation=target.applyBatch class=1 code=10107 attempt=1 elapsed=1.0s nextDelay=1s remaining=29m59s"; R=$(conds); expect "$R" CONN_ERROR yes "(1 行 < 5 但先前成立 → 仍成立)"
mk CONN_RELEASE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond CONN_ERROR medium; cond THROTTLE medium; cond RETRY_BUDGET_LOW high; hb -120
R=$(conds); expect "$R" CONN_ERROR no "(0 行 → 解除)"; expect "$R" THROTTLE no "(0 行 → 解除)"; expect "$R" RETRY_BUDGET_LOW no "(無 L31 → 解除)"
mk BUDGET_HYST; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond RETRY_BUDGET_LOW high; hb -120
L -100 WARN "retry operation=aws.Scan class=1 code=ThrottlingException attempt=1 elapsed=1.0s nextDelay=0.5s remaining=29m59s"; R=$(conds); expect "$R" RETRY_BUDGET_LOW yes "(remaining 回升但 600 秒內仍有 L31 → 仍成立)"
mk CAST_RELEASE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond CAST_ISSUE medium; hb -120
L -100 WARN "CastDocument: field[expiration_date] castToInt64 failed: collection[inside_link_m] target[long] source_type[S] reason[TYPE_MISMATCH], keeping original"
R=$(conds); expect "$R" CAST_ISSUE no "(只有已知的 inside_link_m → 解除)"
mk TZ_RELEASE; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond LOG_TZ_UNEXPECTED medium; hb -120
R=$(conds); expect "$R" LOG_TZ_UNEXPECTED no "(全部 UTC → 解除)"
mk HEALTH_HOLD; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond STREAM_HEALTH_UNAVAILABLE medium
batch -30 0 100 100; R=$(conds); expect "$R" STREAM_HEALTH_UNAVAILABLE yes "(心跳只有 1 行 → 維持)"
mk HEALTH_STILL; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond STREAM_HEALTH_UNAVAILABLE medium
L -90 WARN "stream health unavailable retryStatus=idle: x"; batch -60 0 100 100; L -30 WARN "stream health unavailable retryStatus=idle: x"; R=$(conds); expect "$R" STREAM_HEALTH_UNAVAILABLE yes "(3 次中仍有 L29 → 仍成立)"
mk IDLE_HOLD; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond CAPTURE_IDLE medium
batch -200 0 777 777; R=$(conds); expect "$R" CAPTURE_IDLE yes "(最新一批過期 → 維持)"
mk IDLE_NA_HOLD; ns phase LIVE start_ts $((NOW-5000)) live_ts $((NOW-5000)) absent_runs 0; cond CAPTURE_IDLE medium
hb -300; R=$(conds); expect "$R" CAPTURE_IDLE yes "(批次只涵蓋 300 秒 < CAPTURE_IDLE_SEC → na → 維持)"
mk LAG_PHASE_LEFT; ns phase SCANNING start_ts $((NOW-100)) absent_runs 0 run_tables 3; cond APPLY_LAG medium; cond APPLY_STALL high; cond BACKLOG_GROWING medium; cond CAPTURE_IDLE medium; hb -120
R=$(conds); for id in APPLY_LAG APPLY_STALL BACKLOG_GROWING CAPTURE_IDLE; do expect "$R" $id no "(新的一輪回到 SCANNING → 增量條件解除)"; done

# ======================= EVENT 條件 (alert 兩輪: 基準 → 追加) =======================
mk EVENTS; ns_unused=1
L -3000 INFO "schema=v2 semantics=collection_scoped config_id=opapp.type-conversion config_version=2026-09-11.1 database=Mobi collections=3 governed_collections=3 preserve_only=0 rules=3 rules_sha256=d1a0498d4022cf1c60e3b807e6c95abc275bce815c47cc4a574f822ca1ce2156"
for t in $TABLES; do L -2990 INFO "bootstrap table=$t open=4 closedAsAncestor=1 closedCaptured=0 invisibleAncestor=4"; done
L -2900 INFO "resume effective scan page limit=1000 (conf=128)"
for t in $TABLES; do L -2800 INFO "resume table finish runId=$RID table=$t elapsed=1m0s committedPages=1 committedItems=1000 committedDocs=1000 physicalWriteAttempts=10"; done
L -2700 INFO "resume LIVE runId=$RID: replay vector reached"; hb -2600; O "max process: 256"
rm -rf "$C/mon/state"; mkdir -p "$C/mon/state"; alert
[ "$(LC_ALL=C gawk -F'\t' '$1=="phase"{print $2}' "$C/mon/state/ns_state")" = LIVE ] && ok "基準 phase=LIVE" || bad "基準 phase 不是 LIVE"
# 追加各種 EVENT 行
L -20 WARN "target/checkpoint combination has no resume capability"
L -20 WARN "資料寫入未達 majority+journal，G4 在目的端 failover 回滾時不成立"
L -20 WARN "resume uses the manifest's fixed source tables; ignoring newly discovered unrelated tables: tX"
L -19 INFO "schema=v2 semantics=collection_scoped config_id=opapp.type-conversion config_version=2026-09-11.1 database=Mobi collections=3 governed_collections=3 preserve_only=0 rules=3 rules_sha256=ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
L -18 EROR "shard BLOCKED persistence failed: CANARY err"
for t in $TABLES; do L -17 INFO "bootstrap table=$t open=4 closedAsAncestor=1 closedCaptured=0 invisibleAncestor=4"; done
L -15 INFO "resume LIVE runId=$RID: replay vector reached"
O 'FileLogWriter("logs/nimo-shake.log"): write logs/nimo-shake.log: no space left on device'
O "some unknown output line CANARY"
hb -60; alert
for id in WRONG_PATH WEAK_CONCERN NEW_SOURCE_TABLES RULES_CHANGED ERROR_DETECTED NEW_RUN LIVE_REACHED LOG_WRITE_FAILED OUTPUT_UNKNOWN; do cf $id && ok "EVENT $id" || bad "EVENT $id 未成立"; done
cf FATAL_EXIT && bad "FATAL_EXIT 不應成立" || ok "FATAL_EXIT 不成立 (FileLogWriter 不是致命)"
[ "$(grep -rai canary "$C/mon/state" | wc -l)" = 0 ] && ok "canary = 0" || bad "canary 外洩"
# 重複啟動: .output 新增 max process + write pid failed，程序仍在
O "max process: 256"; O "write pid failed. Locked by other process"; hb -30; alert
cf DUPLICATE_START && ok "DUPLICATE_START" || bad "DUPLICATE_START 未成立"
cf FATAL_EXIT && bad "DUPLICATE_START 時不應 FATAL_EXIT" || ok "FATAL_EXIT 被 DUPLICATE_START 取代"
# LOG_GAP: 換成新 inode 且舊檔消失
cp "$C/nimo/logs/nimo-shake.log" "$C/nimo/logs/tmp.log"; rm -f "$C/nimo/logs/nimo-shake.log"; mv "$C/nimo/logs/tmp.log" "$C/nimo/logs/nimo-shake.log"
export NS_NOW=$((NOW+60)); hb -30; alert
cf LOG_GAP && ok "LOG_GAP (舊 inode 不見)" || bad "LOG_GAP 未成立"
export NS_NOW=$NOW
# 假 🟢 迴歸: APPLY_STALL 成立後批次過期，不得解除
mk FALSE_GREEN; L -3000 INFO "schema=v2 semantics=collection_scoped config_id=x config_version=1 database=Mobi collections=3 governed_collections=3 preserve_only=0 rules=3 rules_sha256=d1a0498d4022cf1c60e3b807e6c95abc275bce815c47cc4a574f822ca1ce2156"
L -2700 INFO "resume LIVE runId=$RID: replay vector reached"
o=-700; while [ $o -le -30 ]; do batch $o 50 200 150; o=$((o+30)); done
rm -rf "$C/mon/state"; mkdir -p "$C/mon/state"; alert; alert   # 第 1 輪建基準 (首次不發 EVENT 但 STATE 照判)
cf APPLY_STALL && ok "APPLY_STALL 成立" || bad "APPLY_STALL 未成立"
export NS_NOW=$((NOW+300)); alert   # 5 分鐘後沒有新批次 → 過期
cf APPLY_STALL && ok "批次過期後 APPLY_STALL 維持 (無假 🟢)" || bad "批次過期後被誤解除"
LC_ALL=C grep -la "^SUBJECT: .*🟢 已解除" "$C/mon/state/dryrun"/*.txt >/dev/null 2>&1 && bad "寄出了假的 🟢" || ok "沒有 🟢 信"
export NS_NOW=$NOW
# --status 不寫檔
mk STATUS_RO; L -100 INFO "resume checkpoint IO interval=30s reads=1 writes=1"; rm -rf "$C/mon/state"
NS_TEST_ALIVE=1 bash "$HERE/nimoshake-alert.sh" --status "$C/mon/opapp.conf" >/dev/null 2>&1
[ -e "$C/mon/state" ] && bad "--status 建了 state/" || ok "--status 不建 state/、不寫 alert.log"
# L26 runId 不同不收
mk L26_RUNID; printf '%s\n' "$(ts $((NOW-100))) [INFO] resume table start runId=$RID table=t01 state=SCANNING" \
  "$(ts $((NOW-90))) [INFO] resume table finish runId=0000000000000000000000000000beef table=t02 elapsed=1s committedPages=1 committedItems=1 committedDocs=1 physicalWriteAttempts=1" \
  | TZ=UTC gawk -v now=$NOW -v alive=1 -v stop_ts=0 -v total_tables=3 -f "$HERE/lib/ns_state.awk" /dev/null - > "$C/ns"
grep -q "^fin_tables	$" "$C/ns" && grep -q "^runid	$RID" "$C/ns" && ok "L26 runId 不同 → 不收、runid 不變" || { bad "L26 runId 保護無效"; cat "$C/ns"; }

echo; echo "===== 結果: PASS=$PASS FAIL=$FAIL (工作目錄 $W) ====="; [ "$FAIL" -eq 0 ]
