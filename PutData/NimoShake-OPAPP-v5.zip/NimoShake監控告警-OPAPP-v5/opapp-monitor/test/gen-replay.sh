#!/bin/bash
# =============================================================================
# test/gen-replay.sh — 產生「時間遞增、可重播」的合成 1.0.16c log / .output / FullCheck 輸出
# -----------------------------------------------------------------------------
# YC 的遮罩樣本 (02_log樣本_已遮罩) 是分段節錄、時間不遞增，不能直接重播 (規格 §9)。
# 本腳本依規格 §3 的格式字串與樣本的真實行，造出一輪完整的 10-05 情境:
#   啟動 → PREPARING (L19×23, L18) → SCANNING (L20/L22/L23/L24/L25/L26) → CATCH-UP (L21×23)
#   → LIVE (L30) → LIVE 穩態 (L27×23+L28 每 30 秒)，一路到 now-30s。
# 另可用 --canary 追加第二階段 (金絲雀行：configuration/BLOCKED reason/L29/L35/L37/L39/
#   .output panic/FullCheck pk+sk+值)，供 §8.3 金絲雀測試用。
#
# 用法: gen-replay.sh <輸出目錄> [--now <epoch>] [--canary]
#   產生 <dir>/logs/nimo-shake.log、<dir>/nimo-shake.linux.output、<dir>/nimo-shake.conf、
#        <dir>/nimo-shake.pid、<dir>/fullcheck/out_check/{run-manifest.json,<table>}
# 金絲雀字樣一律含 CANARY (大小寫不拘)，監控所有輸出 grep -i canary 必須 0 筆。
# =============================================================================
set -euo pipefail
OUT="${1:?用法: gen-replay.sh <輸出目錄> [--now epoch] [--canary]}"; shift
NOW=$(date +%s); CANARY=0
while [ $# -gt 0 ]; do case "$1" in --now) NOW="$2"; shift;; --canary) CANARY=1;; esac; shift; done
mkdir -p "$OUT/logs" "$OUT/fullcheck/out_check"
LOG="$OUT/logs/nimo-shake.log"; OUTF="$OUT/nimo-shake.linux.output"
RUNID="7ef5a8464664c6f678622189b1b2db61"
TABLES="cmn_activity_m:116 cmn_coupon_m:20899 ec_qrcode_benefits_code:12 ec_qrcode_benefits_codemapping:1342 ec_qrcode_benefits_main:4 egtc_traded_m:0 event_record_main:1097 event_record_traded_m:1279006 external_import_traded_m:26 imm_traded_m:0 inapp_notice_m:1354577 inside_link_m:278334 itc_coupon_m:167675 member_benefits_m:38 mms_coupon_m:47481 mms_event_record:47 my_notice_m:49650238 pos_activity_m:664 pos_coupon_m:16542522 s_feature:291 s_vender_business_config:8 user_account_m:12645649 user_def_payment:2090372"

if [ "$CANARY" -eq 0 ]; then
# ---- 第一階段: 完整一輪 (gawk 一次產生，時間遞增) ----
TZ=UTC gawk -v now="$NOW" -v runid="$RUNID" -v tables="$TABLES" '
function ts(e) { return "[" strftime("%Y/%m/%d %H:%M:%S UTC", e, 1) "]" }
function L(e, lvl, m) { print ts(e) " [" lvl "] " m }
function streams(e, phase,   i, t, cap, app, gap, lag, sp) {
  for (i = 1; i <= nt; i++) { t = name[i]
    if (phase == "scan")      { cap = int(rate[t] * (e - t0)); app = 0; gap = cap; sp = cap; lag = (cap > 0) ? sprintf("%.6fs", (e - t0) * 0.9) : "0s" }
    else if (phase == "catch"){ cap = int(rate[t] * (e - t0)); app = int(cap * (e - tcatch) / (tlive - tcatch)); gap = cap - app; sp = gap; lag = (gap > 0) ? sprintf("%dm%ds", int((tlive - e) * 0.5 / 60), int((tlive - e) * 0.5) % 60) : "0s" }
    else                      { cap = int(rate[t] * (e - t0)); app = cap - (rate[t] > 100 ? int(rate[t] * 1.3) : 0); gap = cap - app; sp = gap + (gap > 0 ? 20 : 0); lag = (gap > 0) ? sprintf("%.6fs", 1.2 + (i % 5) * 0.1) : "0s" }
    L(e, "INFO", "resume streams table=" t " open=" open[t] " EOF=" (600 + i) " applyDone=" (600 + i) " spool=" sp " oldestUnappliedAge=" lag " captured=" cap " applied=" app " gapEvents=" gap " retryStatus=idle")
  }
  L(e, "INFO", "resume checkpoint IO interval=30s reads=" (3000 + (e % 300)) " writes=" (500 + (e % 90)))
}
BEGIN {
  nt = split(tables, arr, " ")
  for (i = 1; i <= nt; i++) { split(arr[i], kv, ":"); name[i] = kv[1]; total[kv[1]] = kv[2] + 0; open[kv[1]] = (kv[2] > 1000000) ? 40 : 4
    rate[kv[1]] = (kv[2] > 10000000) ? 95 : (kv[2] > 1000000) ? 14 : (kv[2] > 100000) ? 1.2 : 0 }
  t0 = now - 6 * 3600                     # 啟動時間 = 6 小時前
  # ---- 啟動 ----
  L(t0, "INFO", "schema=v2 semantics=collection_scoped config_id=opapp.type-conversion config_version=2026-09-11.1 database=Mobi collections=23 governed_collections=20 preserve_only=3 rules=43 rules_sha256=d1a0498d4022cf1c60e3b807e6c95abc275bce815c47cc4a574f822ca1ce2156")
  L(t0, "INFO", "source _id fields=0; convert._id has no effect")
  L(t0, "INFO", "source_id_basis=declared_mapping convert_id=pre")
  print ts(t0) " [WARN] "
  print "   ____  ____  _____  _   _  _____  ____ "; print "  |    \\|    \\|     || \\ | ||     ||    \\"; print "  |  D  |  D  |  _  ||  \\| ||  _  ||  D  |"
  for (i = 1; i <= 8; i++) print "  canary-free banner line " i
  L(t0, "INFO", "Mobi configuration: {\"Id\":\"Mobi\",\"SourceAccessKeyID\":\"AKIACANARY0000000001\",\"SourceSecretAccessKey\":\"CANARYsecret/aws/key+0000000000000000000\",\"TargetAddress\":\"mongodb+srv://canary_user:canary_pw@canary-host.mongodb.net/\",\"SyncMode\":\"all\"}")
  L(t0, "INFO", "New session to mongodb+srv://canary_user:canary_pw@canary-host.mongodb.net/ successfully")
  L(t0 + 3, "INFO", "resume full writer: replacement upsert, unordered, complete primary selector; legacy insert/upsert flags ignored")
  for (i = 1; i <= nt; i++) L(t0 + 5 + int(i / 8), "INFO", "bootstrap table=" name[i] " open=" open[name[i]] " closedAsAncestor=" (250 + i) " closedCaptured=0 invisibleAncestor=" open[name[i]])
  L(t0 + 14, "WARN", "capture bootstrap waiting runId=" runid " ready=0/0 waited=10s; waiting for durable origins and active capture; Scan remains gated")
  for (k = 1; k <= 4; k++) L(t0 + 14 + 60 * k, "WARN", "capture bootstrap waiting runId=" runid " ready=" (590 + 47 * k) "/779 waited=" (1 + k) "m10s; waiting for durable origins and active capture; Scan remains gated")
  # ---- 全量 (SCANNING): 5m43s 後開始，共 2 小時 ----
  tscan = t0 + 343; tcatch = t0 + 2 * 3600; tlive = t0 + 2 * 3600 + 1800
  L(tscan, "INFO", "resume effective scan page limit=1000 (conf=128)")
  # 每表的掃描時長與 finish 時間
  for (i = 1; i <= nt; i++) { t = name[i]; d = (total[t] < 2000) ? 2 : (total[t] < 100000) ? 60 : (total[t] < 3000000) ? 600 : (total[t] < 20000000) ? 4800 : (tcatch - tscan - 10)
    tstart[t] = tscan + (i % 4) * 2; tfin[t] = tstart[t] + d; if (tfin[t] > tcatch - 1) tfin[t] = tcatch - 1 }
  # 事件流: 每 30 秒一批 streams (從 t0+35 起)；掃描中每表每 30 秒 health；segment 行每頁 (只在 user_account_m 示範幾頁)
  e = t0 + 35; nextseg = tscan + 2
  while (e < now - 30) {
    if (e < tcatch) streams(e, "scan"); else if (e < tlive) streams(e, "catch"); else streams(e, "live")
    if (e >= tscan && e < tcatch) {
      for (i = 1; i <= nt; i++) { t = name[i]
        if (e >= tstart[t] && e < tfin[t]) { frac = (e - tstart[t]) / (tfin[t] - tstart[t]); it = int(total[t] * frac); pg = int(it / 1000) + 1
          L(e, "INFO", "resume health runId=" runid " table=" t " elapsed=" sprintf("%dm%d.0s", int((e - tstart[t]) / 60), (e - tstart[t]) % 60) " committedPages=" pg " committedItems=" it " committedDocs=" it " physicalWriteAttempts=" (pg * 10)) } }
      # 幾行 segment (含 keyHash 金絲雀)
      L(e, "INFO", "resume segment runId=" runid " table=user_account_m segment=" (e % 8) "/8 committedPage=" int((e - tscan) / 30 + 1) " committedItems=" ((e - tscan) * 30) " committedDocs=" ((e - tscan) * 30) " done=false keyHash=CANARYkeyhash" (e % 97))
    }
    e += 30
  }
}' > "$LOG.unsorted"
# 表開始/第一頁/完成/轉換器/LIVE 行另外產生後與上面合併排序 (穩定排序：時間 → 行內容)
TZ=UTC gawk -v now="$NOW" -v runid="$RUNID" -v tables="$TABLES" '
function ts(e) { return "[" strftime("%Y/%m/%d %H:%M:%S UTC", e, 1) "]" }
function L(e, lvl, m) { print ts(e) " [" lvl "] " m }
BEGIN { nt = split(tables, arr, " "); t0 = now - 6 * 3600; tscan = t0 + 343; tcatch = t0 + 2 * 3600; tlive = tcatch + 1800
  for (i = 1; i <= nt; i++) { split(arr[i], kv, ":"); t = kv[1]; total = kv[2] + 0
    d = (total < 2000) ? 2 : (total < 100000) ? 60 : (total < 3000000) ? 600 : (total < 20000000) ? 4800 : (tcatch - tscan - 10)
    tstart = tscan + (i % 4) * 2; tfin = tstart + d; if (tfin > tcatch - 1) tfin = tcatch - 1
    L(tstart, "INFO", "resume table start runId=" runid " table=" t " state=SCANNING")
    L(tstart, "INFO", "MTypeCastConverter loaded type_rules snapshot for collection[" t "], rules=1")
    L(tstart + 1, "INFO", "resume first durable batch runId=" runid " table=" t " elapsed=1.2s")
    for (s = 0; s < 8; s++) L(tfin - 1, "INFO", "resume segment runId=" runid " table=" t " segment=" s "/8 committedPage=" int(total / 8000 + 1) " committedItems=" int(total / 8) " committedDocs=" int(total / 8) " done=true keyHash=CANARYkeyhashdone" s)
    L(tfin, "INFO", "resume table finish runId=" runid " table=" t " elapsed=" sprintf("%dm%d.5s", int(d / 60), d % 60) " committedPages=" int(total / 1000 + 8) " committedItems=" total " committedDocs=" total " physicalWriteAttempts=" int(total / 100 + 8))
    L(tcatch, "INFO", "MTypeCastConverter loaded type_rules snapshot for collection[" t "], rules=1") }
  L(tscan + 15, "WARN", "bounded worker queue waiting >10s workers=4 task=14/23")
  L(tscan + 30, "WARN", "CastDocument: field[expiration_date] castToInt64 failed: collection[inside_link_m] target[long] source_type[S] reason[TYPE_MISMATCH], keeping original")
  L(tlive, "INFO", "resume LIVE runId=" runid ": replay vector reached; capture -> spool -> apply continues (not final consistency acceptance)") }' >> "$LOG.unsorted"
# 依前綴時間穩定排序 (歡迎圖接續行沒有前綴，排到最前再搬回 WARN 空行之後)
{ LC_ALL=C grep -aE '^\[[0-9/]{10} [0-9:]{8} UTC\] ' "$LOG.unsorted" | LC_ALL=C sort -s -k1,2; } > "$LOG.sorted"
LC_ALL=C gawk -v banner="$LOG.unsorted" 'BEGIN{ while ((getline l < banner) > 0) if (l !~ /^\[/) b[++nb] = l }
  { print; if ($0 ~ /^\[[^]]*\] \[WARN\] ?$/ && !done) { for (i = 1; i <= nb; i++) print b[i]; done = 1 } }' "$LOG.sorted" > "$LOG"
rm -f "$LOG.unsorted" "$LOG.sorted"
printf 'max process: 256\nsync failed: FINGERPRINT_MISMATCH: id="CANARY_DB" rules_sha256 expected=e3242b3f actual=d1a0498d\nmax process: 256\n' > "$OUTF"
printf '12345\n' > "$OUT/nimo-shake.pid"; printf '12345\n' > "$OUT/Mobi.pid"
printf '%s
' 'conf.version = 3' 'id = Mobi' 'log.file = nimo-shake.log' 'log.level = info' 'log.buffer = true' 'system_profile = 9330' 'full_sync.http_port = 9341' 'incr_sync.http_port = 9340' 'sync_mode = all' 'incr_sync_parallel = true' 'source.access_key_id = AKIACANARY0000000001' 'source.secret_access_key = CANARYsecret/aws/key+0000000000000000000' 'source.session_token =' 'source.region = ap-northeast-1' 'qps.full = 1000' 'qps.full.batch_num = 128' 'target.type = mongodb' 'target.address = mongodb+srv://canary_user:canary_pw@canary-host.mongodb.net/' 'target.mongodb.type = replica' 'target.db.exist = drop' 'full.concurrency = 4' 'full.read.concurrency = 8' 'full.document.concurrency = 8' 'full.document.write.batch = 100' 'full.enable_index.user = true' 'increase.concurrency = 4' 'checkpoint.type = mongodb' 'checkpoint.address = mongodb+srv://canary_user:canary_pw@canary-host.mongodb.net/' 'checkpoint.db =' 'convert._id = pre' 'convert.type = mchange_cast' 'convert.type_rules_path = ./type_rules_opapp.json' > "$OUT/nimo-shake.conf"
echo "第一階段產生完成: $(wc -l < "$LOG") 行 → $LOG"
else
# ---- 第二階段: 金絲雀行 (追加到 log 末端，時間 = now-20 .. now-5) ----
TZ=UTC gawk -v now="$NOW" -v runid="$RUNID" '
function ts(e) { return "[" strftime("%Y/%m/%d %H:%M:%S UTC", e, 1) "]" }
function L(e, lvl, m) { print ts(e) " [" lvl "] " m }
BEGIN { e = now - 25
  L(e, "WARN", "stream health unavailable retryStatus=idle: context deadline exceeded host=canary-host.mongodb.net")
  L(e + 1, "WARN", "spool GC failed table=my_notice_m shard=shardId-CANARY-0001: write concern error CANARY")
  L(e + 1, "WARN", "spool GC failed table=my_notice_m shard=shardId-CANARY-0002: write concern error CANARY")
  L(e + 1, "WARN", "spool GC failed table=my_notice_m shard=shardId-CANARY-0003: write concern error CANARY")
  L(e + 2, "WARN", "flush poll before shard BLOCKED failed table=my_notice_m shard=shardId-CANARY-0001: CANARY err text")
  L(e + 2, "WARN", "retrying prior shard BLOCKED table=my_notice_m shard=shardId-CANARY-0001 reason=CANARY reason text")
  L(e + 3, "WARN", "capture GetRecords trimmed: recovering TRIM_HORIZON table=pos_coupon_m shard=shardId-CANARY-0009")
  for (k = 1; k <= 6; k++) L(e + 3 + k, "WARN", "retry operation=target.applyBatch class=1 code=10107 attempt=" k " elapsed=" k ".2s nextDelay=1s remaining=" (29 - k) "m58.8s")
  for (k = 1; k <= 5; k++) L(e + 4 + k, "WARN", "retry operation=aws.Scan class=1 code=ThrottlingException attempt=" k " elapsed=" k ".0s nextDelay=0.5s remaining=4m" (50 - k) "s")
  L(e + 10, "WARN", "something totally unexpected happened CANARY_UNKNOWN_WARN pk=CANARY_PK")
  L(e + 11, "WARN", "CastDocument: field[seqno] castToInt64 failed: collection[egtc_traded_m] target[long] source_type[S] reason[LEADING_ZERO], keeping original")
  L(e + 12, "WARN", "buffer reservation waiting lane=full used=100 limit=100 bytes=1 owner=table=my_notice_m segment=3 page=17")
  L(e + 12, "WARN", "buffer reservation waiting lane=full used=100 limit=100 bytes=1 owner=table=my_notice_m segment=3 page=17")
  L(e + 12, "WARN", "buffer reservation waiting lane=full used=100 limit=100 bytes=1 owner=table=my_notice_m segment=3 page=17")
  L(e + 14, "EROR", "migration BLOCKED（只限已證明的完整性問題）runId=" runid " table=my_notice_m segment=0 page=0 reason=STREAM_GAP table=my_notice_m stream=arn:aws:dynamodb:ap-northeast-1:000000CANARY:table/my_notice_m/stream/2026 shard=shardId-CANARY-0001: TrimmedDataAccessException: CANARY_PK detail；重跑 start.sh 將自動還原 LIVE 後重試，不會 drop，也不需 force")
  print "\tstatus code: 400, request id: CANARY-REQ-ID"
  L(e + 15, "EROR", "BLOCKED 未能落盤 runId=" runid " error=CANARY error text with _id=CANARY_PK")
  L(e + 16, "INFO", "stopped by signal") }' >> "$LOG"
printf 'max process: 256\nsync failed: FINGERPRINT_MISMATCH: id="CANARY_DB" rules_sha256 expected=e3242b3f actual=d1a0498d\npanic: runtime error: CANARY index out of range [CANARY_PK]\ngoroutine 1 [running]:\nmain.main()\n\t/build/CANARY/main.go:1 +0x1\n[signal SIGSEGV: segmentation violation CANARY]\n\n' >> "$OUTF"
# FullCheck 輸出 (專版): manifest + 一表一檔 JSONL (含 pk/sk/值 金絲雀)
FC="$OUT/fullcheck/out_check"
printf '%s
' '{' '  "tool": "nimo-full-check", "contract": "contract-2026-09-11.1",' '  "started_at": "2026-10-06T01:00:00Z",' '  "tables": [ {"table": "inside_link_m", "outcome": "PASS_WITH_EXCEPTIONS"}, {"table": "cmn_activity_m", "outcome": "PASS"} ],' '  "finished_at": "2026-10-06T03:20:00Z",' '  "outcome": "PASS_WITH_EXCEPTIONS"' '}' > "$FC/run-manifest.json"
printf '%s\n' '{"type":"summary","table":"inside_link_m","checked":278334,"passed":278330,"failed":1,"exceptions":3,"execution_errors":0,"target_only":0,"outcome":"PASS_WITH_EXCEPTIONS"}' \
  '{"type":"record","severity":"EXCEPTION","pk":"CANARY_PK_001","sk":"CANARY_SK_001","path":"expiration_date","classification":"SOURCE_UNCASTABLE","required_type":"long","source_value":"CANARY_SRC_VALUE","actual_value":"CANARY_ACT_VALUE"}' \
  '{"type":"record","severity":"EXCEPTION","pk":"CANARY_PK_002","sk":"CANARY_SK_002","path":"expiration_date","classification":"SOURCE_UNCASTABLE","required_type":"long","source_value":"CANARY_SRC_VALUE2","actual_value":"CANARY_ACT_VALUE2"}' \
  '{"type":"record","severity":"DIFF","pk":"CANARY_PK_003","sk":"CANARY_SK_003","path":"name","source_value":"CANARY_SRC_VALUE3","actual_value":"CANARY_ACT_VALUE3"}' > "$FC/inside_link_m"
printf '%s\n' '{"type":"summary","table":"cmn_activity_m","checked":116,"passed":116,"failed":0,"exceptions":0,"execution_errors":0,"target_only":0,"outcome":"PASS"}' > "$FC/cmn_activity_m"
echo "第二階段 (金絲雀) 已追加: log $(wc -l < "$LOG") 行、.output $(wc -l < "$OUTF") 行、FullCheck $FC"
fi
