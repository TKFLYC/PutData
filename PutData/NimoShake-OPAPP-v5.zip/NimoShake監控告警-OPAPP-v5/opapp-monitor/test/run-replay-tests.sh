#!/bin/bash
# =============================================================================
# test/run-replay-tests.sh — 用合成 log 跑完整情境，驗證 v5 監控 (YC 規格 §8.3 #2/#3 的自測版)
# 用法: bash test/run-replay-tests.sh [工作目錄]   (預設 /tmp/nsr-replay；會先清掉)
# 情境:
#   1 首次執行 (建基準): ns_state phase=LIVE、fin_count=23、seg_count=184、不發 EVENT 信
#   2 穩態: 無信
#   3 金絲雀 + 程序消失: MIGRATION_BLOCKED / FATAL_EXIT / … EVENT；FullCheck 信；所有輸出 grep -i canary = 0
#   4 absent_runs=2: PROCESS_DOWN (停機原因 BLOCKED)
#   5 重啟 (L04 → L14 自動續傳 → L21×23): phase 回 LIVE、PROCESS_DOWN 🟢 解除、BLOCKED_AUTORESUME 走未解除路徑
#   6 log 輪替 (舊檔尾巴有未讀的 L13): inode 偵測、補讀舊檔 → OWNER_HOST
#   7 EVENT 保留期到期: cond/ 下的 EVENT 檔被清除
#   8 LOG_MISSING: log 不可讀 → LOG_MISSING，既有 STATE 不被誤解除
# 每步印 PASS/FAIL，最後總結。只用 NS_NOW / NS_TEST_ALIVE 覆寫時間與存活。
# =============================================================================
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
W="${1:-/tmp/nsr-replay}"; rm -rf "$W"; mkdir -p "$W/mon" "$W/cap"
NOW0=$(date +%s)
PASS=0; FAIL=0
ok()   { echo "  PASS: $*"; PASS=$((PASS+1)); }
bad()  { echo "  FAIL: $*"; FAIL=$((FAIL+1)); }
check(){ if eval "$1"; then ok "$2"; else bad "$2"; fi; }
nsget(){ LC_ALL=C gawk -F'\t' -v k="$1" '$1==k{print $2}' "$W/mon/state/ns_state" 2>/dev/null; }
alert(){ bash "$HERE/nimoshake-alert.sh" "$W/mon/opapp.conf" 2>&1 | tee -a "$W/cap/alert.out"; }
conds(){ bash "$HERE/nimoshake-monitor.sh" --conditions "$W/mon/opapp.conf" 2>/dev/null; }

bash "$HERE/test/gen-replay.sh" "$W/nimo" --now "$NOW0" >/dev/null
printf '%s
' "ENV_NAME=\"OPAPP\"" "HOST_ROLE=\"重播測試\"" "INSTALL_DIR=\"$W/nimo\"" "MAIL_FROM=\"picappservice@pic.net.tw\"" "MAIL_TO=\"tony.zhang@stockfeel.com.tw\"" "DRY_RUN=1" "DRY_RUN_DUMP=1" "RULES_SHA256=\"d1a0498d4022cf1c60e3b807e6c95abc275bce815c47cc4a574f822ca1ce2156\"" "TABLE_TOTALS=\"ec_qrcode_benefits_code:12,cmn_activity_m:116,ec_qrcode_benefits_codemapping:1342,ec_qrcode_benefits_main:4,egtc_traded_m:0,event_record_main:1097,external_import_traded_m:26,imm_traded_m:0,cmn_coupon_m:20899,inside_link_m:278334,member_benefits_m:38,itc_coupon_m:167675,mms_event_record:47,mms_coupon_m:47481,pos_activity_m:664,inapp_notice_m:1354577,s_feature:291,s_vender_business_config:8,event_record_traded_m:1279006,user_def_payment:2090372,user_account_m:12645649,pos_coupon_m:16542522,my_notice_m:49650238\"" "FULLCHECK_DIR=\"$W/nimo/fullcheck\"" > "$W/mon/opapp.conf"
LOG="$W/nimo/logs/nimo-shake.log"
ts() { TZ=UTC gawk -v e="$1" 'BEGIN{ print "[" strftime("%Y/%m/%d %H:%M:%S UTC", e, 1) "]" }'; }

echo "== 1 首次執行"
export NS_NOW=$NOW0 NS_TEST_ALIVE=1
alert >/dev/null
check '[ "$(nsget phase)" = LIVE ]' "phase=LIVE ($(nsget phase))"
check '[ "$(nsget fin_count)" = 23 ]' "fin_count=23 ($(nsget fin_count))"
check '[ "$(nsget seg_count)" = 184 ]' "seg_count=184 ($(nsget seg_count))"
check '[ "$(nsget runid)" = 7ef5a8464664c6f678622189b1b2db61 ]' "runid"
check '[ ! -d "$W/mon/state/dryrun" ]' "首次不發信"
check '[ "$(ls "$W/mon/state/cond" | wc -l)" = 0 ]' "cond/ 為空"

echo "== 2 穩態"
alert >/dev/null
check '[ ! -d "$W/mon/state/dryrun" ]' "穩態不發信"
check 'conds | grep -q "|ALL_CLEAR|"' "ALL_CLEAR"

echo "== 3 金絲雀 + 程序消失"
bash "$HERE/test/gen-replay.sh" "$W/nimo" --now "$NOW0" --canary >/dev/null; rm -f "$W/nimo/nimo-shake.pid"
export NS_TEST_ALIVE=0
alert >/dev/null
for id in MIGRATION_BLOCKED FATAL_EXIT UNKNOWN_WARN SHARD_TRIMMED BLOCKED_AUTORESUME THROTTLE CONN_ERROR RETRY_BUDGET_LOW SPOOL_GC_FAIL BUFFER_WAIT CAST_ISSUE; do
  check '[ -f "$W/mon/state/cond/'"$id"'" ]' "條件 $id 成立"
done
check '[ ! -f "$W/mon/state/cond/ERROR_DETECTED" ]' "ERROR_DETECTED 不成立 (兩行 EROR 都是 BLOCKED)"
check '[ ! -f "$W/mon/state/cond/OUTPUT_UNKNOWN" ]' "OUTPUT_UNKNOWN 被 FATAL_EXIT 抑制"
check '[ "$(nsget phase)" = BLOCKED ]' "phase=BLOCKED"
check 'ls "$W/mon/state/dryrun"/*.txt | wc -l | grep -q 2' "發 2 封 (告警 + FullCheck)"
check 'grep -l "FullCheck 完成" "$W/mon/state/dryrun"/*.txt >/dev/null' "FullCheck 結果信"
check 'grep -q "code=STREAM_GAP" "$W/mon/state/dryrun"/*.txt' "MIGRATION_BLOCKED 只放代碼 STREAM_GAP"
check 'grep -q "^SUBJECT: \[CRITICAL\]" "$W/mon/state/dryrun"/*.txt' "主旨加 [CRITICAL]"
bash "$HERE/nimoshake-monitor.sh" --human "$W/mon/opapp.conf" > "$W/cap/human.txt" 2>&1
bash "$HERE/nimoshake-monitor.sh" --json "$W/mon/opapp.conf" > "$W/cap/json.txt" 2>&1
bash "$HERE/nimoshake-monitor.sh" --summary "$W/mon/opapp.conf" > "$W/cap/summary.txt" 2>&1
bash "$HERE/nimoshake-alert.sh" --status "$W/mon/opapp.conf" > "$W/cap/status.txt" 2>&1
check '[ "$(grep -rai canary "$W/mon/state" "$W/cap" | wc -l)" = 0 ]' "所有輸出 grep -i canary = 0 筆"
check '[ "$(grep -raE "CANARY_PK|canary_pw|AKIACANARY|keyhash|arn:aws" "$W/mon/state" "$W/cap" | wc -l)" = 0 ]' "主鍵/密碼/金鑰/keyHash/ARN = 0 筆"
check 'python -I -c "import json,sys; json.load(open(sys.argv[1],encoding=\"utf-8\"))" "$W/cap/json.txt" 2>/dev/null || python3 -c "import json,sys; json.load(open(sys.argv[1],encoding=\"utf-8\"))" "$W/cap/json.txt"' "--json 是合法 JSON"

echo "== 4 absent_runs=2 → PROCESS_DOWN"
alert >/dev/null
check '[ "$(nsget absent_runs)" = 2 ]' "absent_runs=2"
check '[ -f "$W/mon/state/cond/PROCESS_DOWN" ]' "PROCESS_DOWN 成立"
check 'grep -q "停機原因 BLOCKED" "$W/mon/state/cond/PROCESS_DOWN"' "停機原因 BLOCKED"

echo "== 5 重啟 (自動續傳) → LIVE、PROCESS_DOWN 解除"
T1=$((NOW0 + 60)); RID=7ef5a8464664c6f678622189b1b2db61
{ echo "$(ts $T1) [INFO] schema=v2 semantics=collection_scoped config_id=opapp.type-conversion config_version=2026-09-11.1 database=Mobi collections=23 governed_collections=20 preserve_only=3 rules=43 rules_sha256=d1a0498d4022cf1c60e3b807e6c95abc275bce815c47cc4a574f822ca1ce2156"
  echo "$(ts $T1) [INFO] source _id fields=0; convert._id has no effect"; echo "$(ts $T1) [INFO] source_id_basis=declared_mapping convert_id=pre"
  echo "$(ts $T1) [WARN] "; echo "  banner CANARY"
  echo "$(ts $T1) [INFO] Mobi configuration: {\"SourceSecretAccessKey\":\"CANARYsecret2\",\"TargetAddress\":\"mongodb+srv://canary_user:canary_pw@canary-host/\"}"
  echo "$(ts $T1) [INFO] New session to mongodb+srv://canary_user:canary_pw@canary-host/ successfully"
  echo "$(ts $((T1+3))) [INFO] resume full writer: replacement upsert, unordered, complete primary selector; legacy insert/upsert flags ignored"
  echo "$(ts $((T1+4))) [WARN] ========== 上次完整性檢查將 migration 標成 BLOCKED；本次自動續傳 =========="
  echo "$(ts $((T1+4))) [WARN] BLOCKED reason=STREAM_GAP table=my_notice_m stream=arn:aws:dynamodb:CANARY shard=CANARY occurredAt=2026-10-07T06:12:53Z stage=LIVE table=my_notice_m segment=0 page=0 resumeState=LIVE；不 drop、不需 force，若問題仍在會再次 BLOCKED"
  for t in $(printf '%s' "$(nsget run_table_set)" | tr ',' ' '); do echo "$(ts $((T1+10))) [INFO] MTypeCastConverter loaded type_rules snapshot for collection[$t], rules=1"; done
  for b in 40 70 100; do for t in $(printf '%s' "$(nsget run_table_set)" | tr ',' ' '); do echo "$(ts $((T1+b))) [INFO] resume streams table=$t open=4 EOF=700 applyDone=700 spool=0 oldestUnappliedAge=0s captured=100 applied=100 gapEvents=0 retryStatus=idle"; done
    echo "$(ts $((T1+b))) [INFO] resume checkpoint IO interval=30s reads=100 writes=10"; done
} >> "$LOG"
printf '12345\n' > "$W/nimo/nimo-shake.pid"; printf 'max process: 256\n' >> "$W/nimo/nimo-shake.linux.output"
export NS_NOW=$((T1 + 120)) NS_TEST_ALIVE=1
alert >/dev/null
check '[ "$(nsget phase)" = LIVE ]' "phase 回 LIVE ($(nsget phase))"
check '[ "$(nsget resume_state)" = LIVE ]' "resume_state=LIVE"
check '[ "$(nsget absent_runs)" = 0 ]' "absent_runs 歸 0"
check '[ ! -f "$W/mon/state/cond/PROCESS_DOWN" ]' "PROCESS_DOWN 已清除 (🟢 寄出)"
check 'LC_ALL=C grep -la "^SUBJECT: .*🟢 已解除" "$W/mon/state/dryrun"/*.txt >/dev/null' "有 🟢 已解除信"
check '[ "$(grep -rai canary "$W/mon/state" | wc -l)" = 0 ]' "重啟段落 canary = 0"
check '[ ! -f "$W/mon/state/cond/DUPLICATE_START" ] && [ ! -f "$W/mon/state/cond/FATAL_EXIT.new" ]' "max process 行不算致命"

echo "== 6 log 輪替 (舊檔尾巴有未讀 L13)"
T2=$((NS_NOW + 100))
echo "$(ts $T2) [WARN] resume ownerHost differs; local lock only, no cross-host fencing" >> "$LOG"
mv "$LOG" "$LOG.1"
{ echo "$(ts $((T2+5))) [INFO] schema=v2 semantics=collection_scoped config_id=opapp.type-conversion config_version=2026-09-11.1 database=Mobi collections=23 governed_collections=20 preserve_only=3 rules=43 rules_sha256=d1a0498d4022cf1c60e3b807e6c95abc275bce815c47cc4a574f822ca1ce2156"
  echo "$(ts $((T2+5))) [INFO] source _id fields=0; convert._id has no effect"; echo "$(ts $((T2+5))) [INFO] source_id_basis=declared_mapping convert_id=pre"
  echo "$(ts $((T2+5))) [INFO] Mobi configuration: {\"SourceSecretAccessKey\":\"CANARYsecret3\"}"
  for t in $(printf '%s' "$(nsget run_table_set)" | tr ',' ' '); do echo "$(ts $((T2+20))) [INFO] MTypeCastConverter loaded type_rules snapshot for collection[$t], rules=1"; done
  for t in $(printf '%s' "$(nsget run_table_set)" | tr ',' ' '); do echo "$(ts $((T2+40))) [INFO] resume streams table=$t open=4 EOF=700 applyDone=700 spool=0 oldestUnappliedAge=0s captured=120 applied=120 gapEvents=0 retryStatus=idle"; done
  echo "$(ts $((T2+40))) [INFO] resume checkpoint IO interval=30s reads=100 writes=10"
} > "$LOG"
export NS_NOW=$((T2 + 60))
alert > "$W/cap/rot.out"
check 'grep -q "已輪替" "$W/cap/rot.out"' "偵測到輪替並補讀舊檔"
check '[ -f "$W/mon/state/cond/OWNER_HOST" ]' "舊檔尾巴的 L13 → OWNER_HOST"
check '[ "$(nsget phase)" = LIVE ]' "輪替後 phase 仍 LIVE"
check '[ "$(cat "$W/mon/state/.log_inode")" = "$(stat -c %i "$LOG")" ]' "inode 已更新"

echo "== 7 EVENT 保留期到期"
export NS_NOW=$((NS_NOW + 4000))
# 補一批 L27/L28 讓心跳不中斷 (否則會另外觸發 HEARTBEAT_LOST，不在本步驟驗證範圍)
{ for t in $(printf '%s' "$(nsget run_table_set)" | tr ',' ' '); do echo "$(ts $((NS_NOW-20))) [INFO] resume streams table=$t open=4 EOF=700 applyDone=700 spool=0 oldestUnappliedAge=0s captured=130 applied=130 gapEvents=0 retryStatus=idle"; done
  echo "$(ts $((NS_NOW-20))) [INFO] resume checkpoint IO interval=30s reads=100 writes=10"; } >> "$LOG"
alert >/dev/null
check '[ ! -f "$W/mon/state/cond/MIGRATION_BLOCKED" ]' "MIGRATION_BLOCKED 保留期過後清除"
check '[ ! -f "$W/mon/state/cond/OWNER_HOST" ]' "OWNER_HOST 保留期過後清除"

echo "== 8 LOG_MISSING (log 不可讀) → 凍結"
touch "$W/mon/state/cond/THROTTLE_KEEP_TEST" 2>/dev/null; rm -f "$W/mon/state/cond/THROTTLE_KEEP_TEST"
mv "$LOG" "$LOG.hidden"
alert >/dev/null
check '[ -f "$W/mon/state/cond/LOG_MISSING" ]' "LOG_MISSING 成立"
mv "$LOG.hidden" "$LOG"
alert >/dev/null
check '[ ! -f "$W/mon/state/cond/LOG_MISSING" ]' "log 回來 LOG_MISSING 解除"

echo
echo "===== 結果: PASS=$PASS FAIL=$FAIL  (工作目錄 $W；信件在 $W/mon/state/dryrun) ====="
[ "$FAIL" -eq 0 ]
