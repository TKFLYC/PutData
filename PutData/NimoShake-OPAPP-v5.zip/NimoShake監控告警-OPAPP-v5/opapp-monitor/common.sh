#!/bin/bash
# =============================================================================
# lib/common.sh (OPAPP 1.0.16c 專用, v5.0) — 設定載入 / SendGrid 寄信 / 記錄
#   - 與 MyShip 用的 monitor/lib/common.sh 分開維護 (兩個環境版本不同，分開改)
#   - 新增 DRY_RUN_DUMP: DRY_RUN=1 時把信件主旨/內文/HTML 落到 state/dryrun/ (0600)，
#     供資安審查做金絲雀測試 (YC 規格 §8.3)
#   - 設定預設值集中在 apply_defaults()，monitor 與 alert 共用同一組門檻
# 本檔以 source 方式被 nimoshake-alert.sh / nimoshake-monitor.sh 引用。
# =============================================================================

# ---- 預設值 (不驗證必填，monitor 直接看 log 時也能用) ----------------------
apply_defaults() {
  ENV_NAME="${ENV_NAME:-OPAPP}"
  HOST_ROLE="${HOST_ROLE:-}"
  # NimoShake 安裝目錄: log / .output / pid / conf 都以它為基準 (YC 規格 §6.7)
  INSTALL_DIR="${INSTALL_DIR:-}"
  if [ -n "$INSTALL_DIR" ]; then
    LOG_FILE="${LOG_FILE:-$INSTALL_DIR/logs/nimo-shake.log}"
    OUTPUT_FILE="${OUTPUT_FILE:-$INSTALL_DIR/nimo-shake.linux.output}"
    NIMO_CONF="${NIMO_CONF:-$INSTALL_DIR/nimo-shake.conf}"
  else
    LOG_FILE="${LOG_FILE:-}"
    OUTPUT_FILE="${OUTPUT_FILE:-}"
    NIMO_CONF="${NIMO_CONF:-}"
  fi
  TOTAL_TABLES="${TOTAL_TABLES:-23}"
  RULES_SHA256="${RULES_SHA256:-}"
  TABLE_TOTALS="${TABLE_TOTALS:-}"
  # ---- 門檻 (YC 規格 §6.7 建議值) ----
  HB_HIGH_SEC="${HB_HIGH_SEC:-120}"
  HB_CRIT_SEC="${HB_CRIT_SEC:-600}"
  HB_STARTUP_GRACE_SEC="${HB_STARTUP_GRACE_SEC:-900}"
  LAG_WARN_SEC="${LAG_WARN_SEC:-300}"
  LAG_HIGH_SEC="${LAG_HIGH_SEC:-1800}"
  LAG_GRACE_SEC="${LAG_GRACE_SEC:-1800}"
  WINDOW_SEC="${WINDOW_SEC:-600}"
  THROTTLE_MIN="${THROTTLE_MIN:-5}"
  CONN_MIN="${CONN_MIN:-5}"
  RETRY_REMAINING_MIN_SEC="${RETRY_REMAINING_MIN_SEC:-600}"
  STOP_WARN_SEC="${STOP_WARN_SEC:-43200}"
  STOP_CRIT_SEC="${STOP_CRIT_SEC:-72000}"
  BOOTSTRAP_STUCK_SEC="${BOOTSTRAP_STUCK_SEC:-1200}"
  STALL_SEC="${STALL_SEC:-600}"
  CAPTURE_IDLE_SEC="${CAPTURE_IDLE_SEC:-1800}"
  RECENT_SEC="${RECENT_SEC:-3600}"
  EVENT_HOLD_SEC="${EVENT_HOLD_SEC:-3600}"
  DISK_ALERT_PCT="${DISK_ALERT_PCT:-85}"
  MEM_ALERT_PCT="${MEM_ALERT_PCT:-90}"
  # RECENT_SEC 必須 ≥ 所有時間窗 + 120 (CAPTURE_IDLE_SEC 通常最大)
  local need=$(( CAPTURE_IDLE_SEC + 120 ))
  [ "$RECENT_SEC" -lt "$need" ] && RECENT_SEC="$need"
  [ "$RECENT_SEC" -lt $(( STALL_SEC + 120 )) ] && RECENT_SEC=$(( STALL_SEC + 120 ))
  [ "$RECENT_SEC" -lt 3720 ] && RECENT_SEC=3720   # CAST_ISSUE 用 3600 秒窗
  # ---- 告警行為 ----
  MAIL_FROM_NAME="${MAIL_FROM_NAME:-StarCo Monitor (${ENV_NAME})}"
  REALERT_INTERVAL="${REALERT_INTERVAL:-21600}"
  GLOBAL_COOLDOWN="${GLOBAL_COOLDOWN:-60}"
  MAX_MAILS_PER_RUN="${MAX_MAILS_PER_RUN:-10}"
  NOTIFY_RESOLVED="${NOTIFY_RESOLVED:-1}"
  ALERT_MIN_SEVERITY="${ALERT_MIN_SEVERITY:-medium}"
  DRY_RUN="${DRY_RUN:-1}"
  DRY_RUN_DUMP="${DRY_RUN_DUMP:-0}"
  # ---- FullCheck 結束通知 (專版 run-manifest.json 判別；OPAPP 1.0.16c 包內的 nimo-full-check 即專版) ----
  FULLCHECK_DIR="${FULLCHECK_DIR:-}"
  FULLCHECK_PROC_PATTERN="${FULLCHECK_PROC_PATTERN:-(^|/)nimo-full-check(\.(linux|darwin))?( |$)}"
  return 0
}

# ---- 設定檔載入與驗證 --------------------------------------------------------
# 用法: load_config /path/to/opapp.conf
load_config() {
  local cfg="$1"
  if [ -z "$cfg" ] || [ ! -f "$cfg" ]; then
    echo "[FATAL] 找不到設定檔: ${cfg:-<未指定>}" >&2
    echo "        請複製 config/opapp.conf.example 並填入 INSTALL_DIR 與 SENDGRID_API_KEY。" >&2
    return 1
  fi
  # conf 以 source 方式載入: 只放 KEY=VALUE，不要放指令；檔案權限建議 600
  if grep -qE '^\s*[^#[:space:]=]+=' "$cfg" 2>/dev/null; then
    # shellcheck disable=SC1090
    set -a; . "$cfg"; set +a
  fi
  apply_defaults
  : "${ENV_NAME:?設定檔缺少 ENV_NAME}"
  : "${INSTALL_DIR:?設定檔缺少 INSTALL_DIR (NimoShake 安裝目錄)}"
  : "${LOG_FILE:?設定檔缺少 LOG_FILE}"
  : "${MAIL_TO:?設定檔缺少 MAIL_TO}"
  : "${MAIL_FROM:?設定檔缺少 MAIL_FROM}"
  if [ -z "${SENDGRID_API_KEY:-}" ] && [ -n "${SENDGRID_API_KEY_FILE:-}" ] && [ -f "$SENDGRID_API_KEY_FILE" ]; then
    SENDGRID_API_KEY="$(tr -d ' \r\n' < "$SENDGRID_API_KEY_FILE")"
  fi
  SENDGRID_API_HOST="${SENDGRID_API_HOST:-api.sendgrid.com}"
  SENDGRID_API_PORT="${SENDGRID_API_PORT:-443}"
  STATE_DIR="${STATE_DIR:-$(cd "$(dirname "$cfg")" && pwd)/state}"
  return 0
}

# ---- 記錄檔 ------------------------------------------------------------------
# 注意 (資安): 寫進 alert.log 的只能是數字、代碼、條件 ID、主旨；不得放原始 log 行
log_line() {
  local logdir="${STATE_DIR:-/tmp}"
  if [ "${NS_NO_FILE_LOG:-0}" = "1" ]; then echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >&2; return 0; fi   # --status: 不寫檔
  mkdir -p "$logdir" 2>/dev/null || true
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$logdir/alert.log" >&2
}

# ---- SendGrid 寄信 (API 模式) -----------------------------------------------
# 用法: sendgrid_send "主旨" "純文字內容" ["HTML內容"]
# 回傳: 0 成功 / 非 0 失敗。
# DRY_RUN=1 時只記 log 不寄；DRY_RUN_DUMP=1 時另把信件寫到 state/dryrun/<epoch>-<n>.txt (0600)
DRYRUN_SEQ=0
sendgrid_send() {
  local subject="$1" body="$2" html="${3:-}"

  if [ "${DRY_RUN:-1}" = "1" ]; then
    log_line "DRY_RUN: 略過寄信 -> to=$MAIL_TO subject=[$subject]"
    if [ "${DRY_RUN_DUMP:-0}" = "1" ]; then
      local dd="${STATE_DIR:-/tmp}/dryrun" f
      mkdir -p "$dd" 2>/dev/null && chmod 700 "$dd" 2>/dev/null
      DRYRUN_SEQ=$((DRYRUN_SEQ + 1))
      f="$dd/$(date +%s)-$$-$DRYRUN_SEQ.txt"
      ( umask 077; { printf 'SUBJECT: %s\n\n==== TEXT ====\n%s\n\n==== HTML ====\n%s\n' "$subject" "$body" "$html"; } > "$f" ) 2>/dev/null \
        && log_line "DRY_RUN_DUMP: 信件已寫到 $f"
    fi
    return 0
  fi
  if [ -z "${SENDGRID_API_KEY:-}" ]; then
    log_line "ERROR: 未設定 SENDGRID_API_KEY，無法寄信 (subject=$subject)"
    return 1
  fi
  if ! command -v curl >/dev/null 2>&1; then
    log_line "ERROR: 環境無 curl，無法寄信"
    return 1
  fi

  local esc_sub esc_body esc_from esc_name esc_html content_json http
  esc_sub=$(json_escape "$subject")
  esc_body=$(json_escape "$body")
  esc_from=$(json_escape "$MAIL_FROM")
  esc_name=$(json_escape "$MAIL_FROM_NAME")
  content_json="{\"type\":\"text/plain\",\"value\":\"${esc_body}\"}"
  if [ -n "$html" ]; then
    esc_html=$(json_escape "$html")
    content_json="${content_json},{\"type\":\"text/html\",\"value\":\"${esc_html}\"}"
  fi
  local to_json="" addr
  for addr in $(printf '%s' "$MAIL_TO" | tr ',;' ' '); do
    [ -z "$addr" ] && continue
    to_json+="{\"email\":\"$(json_escape "$addr")\"},"
  done
  to_json="${to_json%,}"
  if [ -z "$to_json" ]; then
    log_line "ERROR: MAIL_TO 為空，無法寄信 (subject=$subject)"
    return 1
  fi
  # payload 走暫存檔 (0600) 而非命令列參數: 避免多位元組字元在 argv 編碼轉換中損毀 (SendGrid 415)
  local tmp_payload="${STATE_DIR:-/tmp}/.sg_payload.$$"
  ( umask 077; printf '{"personalizations":[{"to":[%s]}],"from":{"email":"%s","name":"%s"},"subject":"%s","content":[%s]}' \
      "$to_json" "$esc_from" "$esc_name" "$esc_sub" "$content_json" > "$tmp_payload" )
  http=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 \
    -X POST "https://${SENDGRID_API_HOST}:${SENDGRID_API_PORT}/v3/mail/send" \
    -H "Authorization: Bearer ${SENDGRID_API_KEY}" \
    -H 'Content-Type: application/json' \
    --data-binary @"$tmp_payload" 2>/dev/null)
  rm -f "$tmp_payload" 2>/dev/null || true

  if [ "$http" = "202" ]; then
    log_line "SENT ok (HTTP 202) to=$MAIL_TO subject=[$subject]"
    return 0
  else
    log_line "ERROR: SendGrid 回應 HTTP ${http:-?} to=$MAIL_TO subject=[$subject]"
    return 1
  fi
}

# JSON 字串轉義 (供 payload 用)；含 \r — 防 CRLF 設定值造成 payload 非法 JSON
json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g; s/\r/\\r/g' | LC_ALL=C awk 'BEGIN{ORS=""} {print (NR>1?"\\n":"") $0}'
}
